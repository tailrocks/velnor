plugins { java }
