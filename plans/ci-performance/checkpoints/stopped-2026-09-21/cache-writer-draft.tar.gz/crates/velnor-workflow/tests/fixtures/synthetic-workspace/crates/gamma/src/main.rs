fn main() {
    println!("gamma");
}
