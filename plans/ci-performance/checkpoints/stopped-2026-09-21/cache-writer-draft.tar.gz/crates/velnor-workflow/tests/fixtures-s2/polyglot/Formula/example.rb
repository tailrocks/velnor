class Example < Formula
end
