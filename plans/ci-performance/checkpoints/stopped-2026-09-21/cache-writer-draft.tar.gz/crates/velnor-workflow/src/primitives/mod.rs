//! The declared CI surface: generic render primitives over scan + config.
//!
//! Every CI-side workflow family is emitted by a primitive in this registry. A
//! primitive is named by a `[[declare]]` row in the repository-owned generation
//! config, receives the scanned shape plus the resolved lane, cache, and pin
//! contracts, and contributes one of three things: workflow files, CI graph
//! nodes for the aggregate workflows to compose, or unit contract updates.
//!
//! Nothing in this module may name a repository. Repository knowledge enters
//! only through the scan (`RepositoryShape`) and the repo-owned config, which
//! is what makes one primitive able to render any repository's surface.

mod aggregate;
mod cache;
pub(crate) mod check_profiles;
pub(crate) mod docs_site;
mod ir;
mod lanes;
mod pipeline;
mod plan;
pub(crate) mod prepared_tools;
mod regen;
pub(crate) mod release;
pub(crate) mod renovate;
pub(crate) mod runtime_products;
pub(crate) mod snapshot;
pub(crate) mod watch;

use std::collections::{BTreeMap, BTreeSet};
use std::fmt::Write as _;
use std::path::PathBuf;

use crate::config::RepoGenerationConfig;
use crate::scan::RepositoryShape;
use crate::{
    nested_unit_workflow_file, CachePurpose, CacheSpec, GeneratorError, ProjectConfig, RunnerMode,
    Unit, UnitKind,
};

pub(crate) use ir::{
    checks_env, config_snapshot_identity, default_branch_push_cache_save_expression,
    render_cargo_source_preparation, render_pinned_toolchain_steps,
    render_retained_output_cache_note, render_velnor_runner_identity_step,
    trusted_cache_save_expression, validate_nextest_tools_are_locked, LaneAdmission, WorkflowIr,
    WorkflowKind, GITHUB_WORKFLOW_BYTE_LIMIT,
};

#[cfg(test)]
pub(crate) use ir::jq_read_plan_matrix;

/// Default `timeout-minutes` for a unit verification job.
pub(crate) const DEFAULT_UNIT_TIMEOUT_MINUTES: u32 = 45;

/// A primitive id the registry knows how to build.
pub(crate) const AFFECTED_PLAN: &str = "affected-plan";
pub(crate) const UNIT_AGGREGATION: &str = "unit-aggregation";
pub(crate) const LANE_MATRIX: &str = "lane-matrix";
pub(crate) const CACHE_CONTRACT: &str = "cache-contract";
pub(crate) const WATCH_GRAPH: &str = "watch-graph";
pub(crate) const REGEN_GATE: &str = "regen-gate";
pub(crate) const RUST_CRATE: &str = "rust-crate-pipeline";
pub(crate) const BUN_PACKAGE: &str = "bun-package-pipeline";
pub(crate) const NODE_PACKAGE: &str = "node-package-pipeline";
pub(crate) const GRADLE_PROJECT: &str = "gradle-project-pipeline";
pub(crate) const SWIFT_PACKAGE: &str = "swift-package-pipeline";
pub(crate) const OPENTOFU: &str = "opentofu-pipeline";
pub(crate) const DOCKER_IMAGE: &str = "docker-image-pipeline";
pub(crate) const HOMEBREW_TAP: &str = "homebrew-tap-pipeline";
pub(crate) const DOCS_LINT: &str = "docs-lint-pipeline";
/// The `docs.yml` documentation-site pipeline: build, link checks, spelling,
/// Pages deployment, and post-deployment verification from one `[docs]`
/// consumer contract.
pub(crate) const DOCS_SITE: &str = "docs-site";
/// The `release.yml` publisher: tag-triggered, verify-then-publish.
pub(crate) const RELEASE: &str = "release";
/// The `preview.yml` rolling artifact lane.
pub(crate) const PREVIEW: &str = "preview";
/// The `maintenance.yml` cache-hygiene workflow.
pub(crate) const MAINTENANCE: &str = "maintenance";
/// The release artifact provenance signer.
pub(crate) const RELEASE_SIGNER: &str = "release-signer";
/// The self-hosted Renovate writer workflow.
pub(crate) const RENOVATE: &str = "renovate";
/// The Renovate configuration validation workflow.
pub(crate) const RENOVATE_VALIDATE: &str = "renovate-validate";
/// A scheduled workflow file rendered from composable check profiles.
pub(crate) const SCHEDULED_CHECKS: &str = "scheduled-checks";
/// A reviewed workflow body declared verbatim by the repository.
pub(crate) const STATIC_WORKFLOW: &str = "static-workflow";
/// The owner-only Stage-0 runtime-product producer.
pub(crate) const RUNTIME_PRODUCTS: &str = "runtime-products";
/// A repository's prepared tools: per-unit consumer needs the generator binds
/// to governing lockfiles, recipe, and toolchain, and renders consumer steps
/// for. A unit-contract row: it records needs on the scoped units before any
/// file renders, and renders nothing itself.
pub(crate) const PREPARED_TOOL: &str = "prepared-tool";

/// The Dockerfile stage a mutable mount seed is injected through. The image
/// declares it as an empty `FROM scratch` stage so a build without the
/// `--build-context` override keeps its exact shape, and the host overrides it
/// with the restored seed directory only when one exists.
pub(crate) const MUTABLE_MOUNT_SEED_CONTEXT: &str = "velnor-cache-seed";
/// The Dockerfile target stage that copies the build's mutable cache mounts
/// back out, so a trusted full build can extract the state it produced.
pub(crate) const MUTABLE_MOUNT_EXPORT_TARGET: &str = "velnor-cache-export";
/// The workspace directory the Docker mutable mount seed lives in between the
/// restore and the build, and where the build's export lands afterwards.
pub(crate) const MUTABLE_MOUNT_HOST_DIR: &str = ".velnor-docker-cache";

/// The pinned action references every emitted job uses.
///
/// The table is resolved once per generation so a primitive never spells a
/// commit SHA, and so a later phase can admit reviewed pins from the config
/// without touching a renderer.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct Pins {
    pub(crate) checkout: &'static str,
    pub(crate) cache_restore: &'static str,
    pub(crate) cache_save: &'static str,
    pub(crate) opentofu_setup: &'static str,
    pub(crate) upload_artifact: &'static str,
    pub(crate) download_artifact: &'static str,
    pub(crate) bun: &'static str,
    pub(crate) node: &'static str,
    pub(crate) rust_tool: &'static str,
    pub(crate) mise: &'static str,
    pub(crate) gradle: &'static str,
    pub(crate) sccache: &'static str,
    pub(crate) mr_boxington: &'static str,
    pub(crate) github_runtime: &'static str,
    pub(crate) docker_buildx: &'static str,
}

impl Pins {
    /// The reviewed pin table the generator ships with.
    pub(crate) fn resolved() -> Self {
        Self {
            checkout: crate::ActionPin::Checkout.reference(),
            cache_restore: crate::ActionPin::CacheRestore.reference(),
            cache_save: crate::ActionPin::CacheSave.reference(),
            opentofu_setup: crate::ActionPin::OpenTofuSetup.reference(),
            upload_artifact: crate::ActionPin::UploadArtifact.reference(),
            download_artifact: crate::ActionPin::DownloadArtifact.reference(),
            bun: crate::ActionPin::Bun.reference(),
            node: crate::ActionPin::Node.reference(),
            rust_tool: crate::ActionPin::RustTool.reference(),
            mise: crate::ActionPin::Mise.reference(),
            gradle: crate::ActionPin::Gradle.reference(),
            sccache: crate::ActionPin::Sccache.reference(),
            mr_boxington: crate::ActionPin::MrBoxington.reference(),
            github_runtime: crate::ActionPin::GithubRuntime.reference(),
            docker_buildx: crate::ActionPin::DockerBuildx.reference(),
        }
    }
}

/// One lane job of a nested unit workflow.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct LaneJob {
    pub(crate) lane: RunnerMode,
    /// The hosted lane is the only lane allowed to save a cache entry: entries
    /// are written from trusted events only.
    pub(crate) cache_save: bool,
    /// The Velnor lane carries the generated default-branch trusted-event
    /// gate. Persistent cache writes remain restricted to trusted events.
    pub(crate) trusted: bool,
}

/// Which cache transport a unit job uses.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum CacheBackend {
    /// The detected contract: the shared object cache when the repository's
    /// Rust commands run under it, otherwise the actions cache.
    Detected,
    /// Force the actions cache steps on, whatever the detected contract is.
    Actions,
    /// Force the shared object cache setup on.
    ObjectCache,
}

impl CacheBackend {
    /// Whether the actions cache restore and save steps are emitted for `unit`.
    ///
    /// The detected policy classifies by purpose: Cargo-source and generic
    /// tool caches ride the actions cache even when the unit compiles under
    /// Mr. Boxington — the object transport moves compiler state, not Cargo's
    /// registry archives, extracted sources, or Git dependencies. Raw output
    /// caches are the one suppression: the object transport already carries
    /// workspace state, so a declared output cache needs its justification on
    /// record.
    pub(crate) fn enables_actions_cache(self, ir: &WorkflowIr, unit: &Unit) -> bool {
        match self {
            Self::Detected => {
                // A unit that declares a Docker mutable-mount seed has swapped
                // its retained-output transport for that seed lifecycle: the
                // declared paths are the seed directory and the declared keys
                // are the seed key inputs. Rendering the generic `ci-` cache
                // beside it would restore seed state under the wrong namespace
                // on lanes that never run the build commands.
                if unit
                    .cache
                    .as_ref()
                    .is_some_and(|cache| cache.mutable_mount_seed)
                {
                    return false;
                }
                match unit.cache.as_ref().map(|cache| cache.purpose) {
                    // The Rust-toolchain cache is generator-internal:
                    // `render_pinned_toolchain_steps` emits it directly and never
                    // hangs it off a unit's declared contract, so it cannot arrive
                    // through this match. Docker seeds render their own lifecycle.
                    // Refuse rather than silently enable either non-generic cache.
                    None | Some(CachePurpose::Toolchains | CachePurpose::DockerSeed) => false,
                    Some(CachePurpose::CargoSources | CachePurpose::Generic) => true,
                    Some(CachePurpose::Outputs) => {
                        !ir.uses_mr_boxington(unit)
                            || unit
                                .cache
                                .as_ref()
                                .is_some_and(CacheSpec::justified_output_alongside_mr_boxington)
                    }
                }
            }
            Self::Actions => true,
            Self::ObjectCache => false,
        }
    }
}

/// Reject a raw output cache that would ride alongside the Mr. Boxington
/// object transport without a recorded justification: the two transports move
/// the same workspace state, so keeping both needs a reason on record.
///
/// # Errors
/// Returns a usage error for an unjustified or multi-line justification.
pub(crate) fn validate_cache_transports(ir: &WorkflowIr) -> Result<(), GeneratorError> {
    for unit in &ir.units {
        validate_cache_transports_for_unit(ir, unit)?;
        validate_mutable_mount_seed(unit)?;
    }
    Ok(())
}

/// Validate one unit's cache transport combination.
///
/// # Errors
/// Returns a usage error for an unjustified or multi-line justification.
pub(crate) fn validate_cache_transports_for_unit(
    ir: &WorkflowIr,
    unit: &Unit,
) -> Result<(), GeneratorError> {
    let Some(cache) = &unit.cache else {
        return Ok(());
    };
    if cache.purpose != CachePurpose::Outputs || !ir.uses_mr_boxington(unit) {
        return Ok(());
    }
    if !cache.justified_output_alongside_mr_boxington() {
        return Err(GeneratorError::usage(format!(
            "unit `{}` declares a raw output cache alongside the Mr. Boxington object transport; drop the output cache or set `mbx_output_cache_justification` to record why both transports are kept",
            unit.id
        )));
    }
    if cache
        .mbx_output_cache_justification
        .as_deref()
        .unwrap_or_default()
        .contains(['\n', '\r'])
    {
        return Err(GeneratorError::usage(format!(
            "unit `{}` uses a multi-line `mbx_output_cache_justification`; keep it to one line",
            unit.id
        )));
    }
    Ok(())
}

/// Validate a unit whose cache contract is a Docker image's mutable mount
/// seed. A declared seed that the declared builds never inject is a silent lie
/// about persistence — exactly the cold-build state this contract exists to
/// remove — so the declared commands must prove both directions of the
/// lifecycle: the hosted full build consumes the seed and extracts the updated
/// state, hosted pull-request builds may consume the restored seed, and no
/// untrusted pull-request build extracts anything.
///
/// # Errors
/// Returns a usage error when the seed rides a non-Docker unit, when the
/// hosted full commands never inject the seed or never extract the export, or
/// when a self-hosted command references the seed context or any pull-request
/// command references the export target.
pub(crate) fn validate_mutable_mount_seed(unit: &Unit) -> Result<(), GeneratorError> {
    let Some(cache) = &unit.cache else {
        return Ok(());
    };
    if !cache.mutable_mount_seed {
        return Ok(());
    }
    if unit.kind != UnitKind::Docker {
        return Err(GeneratorError::usage(format!(
            "unit `{}` declares a mutable mount seed, but only a Docker image build owns cache \
             mounts a seed can be injected into",
            unit.id
        )));
    }
    if cache.key_files.is_empty() || cache.paths.is_empty() {
        return Err(GeneratorError::usage(format!(
            "unit `{}` declares a mutable mount seed without both `key_files` and `paths`; the \
             seed cannot be keyed or restored",
            unit.id
        )));
    }
    let injection = format!("--build-context {MUTABLE_MOUNT_SEED_CONTEXT}=");
    let extraction = format!("--target {MUTABLE_MOUNT_EXPORT_TARGET}");
    let github_full = lane_commands(unit.github_full_commands.as_deref(), &unit.full_commands);
    if !github_full
        .iter()
        .any(|command| command.contains(&injection))
    {
        return Err(GeneratorError::usage(format!(
            "unit `{}` declares a mutable mount seed, but no hosted full command injects it with \
             `--build-context {MUTABLE_MOUNT_SEED_CONTEXT}=<dir>`; a seed the build never reads \
             is declared persistence that does not exist",
            unit.id
        )));
    }
    if !github_full
        .iter()
        .any(|command| command.contains(&extraction) && command.contains("--output type=local"))
    {
        return Err(GeneratorError::usage(format!(
            "unit `{}` declares a mutable mount seed, but no hosted full command extracts the \
             updated state with `--target {MUTABLE_MOUNT_EXPORT_TARGET}` and `--output \
             type=local`; without extraction the seed can only ever go cold",
            unit.id
        )));
    }
    for (lane, commands, allow_injection) in [
        (
            "hosted pull-request",
            lane_commands(unit.github_pr_commands.as_deref(), &unit.pr_commands),
            true,
        ),
        (
            "self-hosted",
            lane_commands(unit.velnor_full_commands.as_deref(), &unit.full_commands),
            false,
        ),
        (
            "self-hosted pull-request",
            lane_commands(unit.velnor_pr_commands.as_deref(), &unit.pr_commands),
            false,
        ),
    ] {
        if commands.iter().any(|command| command.contains(&extraction)) {
            return Err(GeneratorError::usage(format!(
                "unit `{}` runs `{lane}` commands that reference the mutable mount seed export \
                 target; extraction is restricted to trusted hosted full builds",
                unit.id
            )));
        }
        if !allow_injection && commands.iter().any(|command| command.contains(&injection)) {
            return Err(GeneratorError::usage(format!(
                "unit `{}` runs `{lane}` commands that reference the mutable mount seed context; \
                 the generator restores and injects the seed on the hosted lane only",
                unit.id
            )));
        }
    }
    Ok(())
}

/// The commands a lane runs: the lane-specific override when declared, the
/// base vector otherwise.
fn lane_commands<'a>(lane_override: Option<&'a [String]>, base: &'a [String]) -> &'a [String] {
    lane_override.unwrap_or(base)
}

/// Everything a declared unit pipeline may tune for one unit's surface.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct UnitContract {
    pub(crate) lanes: Vec<LaneJob>,
    pub(crate) timeout_minutes: u32,
    pub(crate) cache: CacheBackend,
    /// Cache entries are saved on trusted events only, which is a property of
    /// the workflow kind the aggregate owns, never of the unit.
    pub(crate) cache_save: bool,
    /// Whether the unit's cache contract is the mutable mount seed of a Docker
    /// image build: the hosted lane restores it before the build, the build
    /// injects it into the image's cache mounts, and a trusted full build
    /// extracts the updated state for the next builder.
    pub(crate) mutable_mount_seed: bool,
}

/// What one primitive contributed to the declared surface.
#[derive(Default)]
pub(crate) struct Rendered {
    /// Workflow files, keyed by repository-relative path.
    pub(crate) files: BTreeMap<PathBuf, String>,
    /// CI graph nodes the aggregate workflows compose.
    pub(crate) nodes: Vec<GraphNode>,
    /// Unit contract updates, replacing the scanned unit of the same id.
    pub(crate) units: Vec<Unit>,
    /// Per-unit pipeline contracts carried into the shared kind reusable.
    pub(crate) contracts: BTreeMap<String, UnitContract>,
}

/// One node of the generated CI graph.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) enum GraphNode {
    /// The affected-selection plan job an aggregate workflow starts from.
    Plan {
        /// The rendered `plan:` job block.
        job: String,
    },
    /// One verification unit's reusable-workflow caller.
    Unit {
        unit_id: String,
        job_id: String,
        /// The caller job's display name.
        name: String,
        /// The nested workflow file the caller invokes.
        file: String,
    },
}

impl GraphNode {
    /// The rendered `plan:` job block a contributed plan node carries.
    pub(crate) fn plan_job(&self) -> Option<&str> {
        match self {
            Self::Plan { job } => Some(job),
            Self::Unit { .. } => None,
        }
    }

    fn as_unit(&self) -> Option<(&str, &str, &str, &str)> {
        match self {
            Self::Plan { .. } => None,
            Self::Unit {
                unit_id,
                job_id,
                name,
                file,
            } => Some((unit_id, job_id, name, file)),
        }
    }
}

/// Read-only render input for one primitive invocation.
pub(crate) struct RenderCtx<'a> {
    /// The scanned repository root. A primitive may read repository files the
    /// walk observed, and must never execute project code.
    pub(crate) root: &'a std::path::Path,
    /// What the scan proved about the repository.
    pub(crate) shape: &'a RepositoryShape,
    /// The generated project contract the surface is rendered for.
    pub(crate) config: &'a ProjectConfig,
    /// The unit being rendered, for per-unit primitives.
    pub(crate) unit: Option<&'a Unit>,
    /// The units the current declaration applies to, for unit-contract
    /// primitives: the ids the row named, resolved against the scan.
    pub(crate) units: &'a [&'a Unit],
    /// The workflow file the declaration renders into, when the family renders
    /// one.
    pub(crate) file: Option<&'a str>,
    /// The id of the primitive being rendered, for error messages.
    pub(crate) family: &'static str,
    /// The pinned action references every emitted job uses. A primitive that
    /// spells an action reference itself takes it from here, never from a
    /// literal, so the reviewed pin table stays the single source.
    #[expect(dead_code, reason = "primitives render pins through the lane context")]
    pub(crate) pins: &'a Pins,
    /// The resolved lane matrix and the toolchain environment behind it.
    pub(crate) lanes: &'a lanes::ResolvedLanes,
    /// The resolved cache contract.
    pub(crate) cache: &'a cache::ResolvedCache,
    /// The CI graph nodes contributed by the primitives rendered so far.
    pub(crate) nodes: &'a [GraphNode],
    /// Per-unit pipeline contracts resolved by the primitives rendered so far.
    /// The aggregate passes them to the kind-reusable callers so caller
    /// `with:` values and callee step gates derive from one contract.
    pub(crate) contracts: &'a BTreeMap<String, UnitContract>,
}

/// One render primitive of the CI surface.
pub(crate) trait Primitive: Send + Sync {
    /// The name a `[[declare]]` row uses to invoke this primitive.
    fn id(&self) -> &'static str;

    /// The declared arguments this primitive accepts, with their meaning.
    /// Anything not listed here is rejected: a typo'd config must fail closed.
    fn schema(&self) -> &'static [&'static str];

    /// Render this primitive's contribution to the surface.
    ///
    /// # Errors
    /// Returns a usage error naming the offending declared value.
    fn render(&self, ctx: &RenderCtx<'_>, args: &Args<'_>) -> Result<Rendered, GeneratorError>;
}

/// The declared arguments of one `[[declare]]` row.
pub(crate) struct Args<'a>(&'a BTreeMap<String, toml::Value>);

impl Args<'_> {
    /// The known argument names, for an error message.
    pub(crate) fn keys(&self) -> Vec<&str> {
        self.0.keys().map(String::as_str).collect()
    }

    pub(crate) fn strings(&self, key: &str) -> Result<Option<Vec<String>>, GeneratorError> {
        match self.0.get(key) {
            None => Ok(None),
            Some(toml::Value::Array(items)) => {
                let mut values = Vec::new();
                for item in items {
                    match item {
                        toml::Value::String(value) => values.push(value.clone()),
                        other => return Err(unexpected(key, other, "a string")),
                    }
                }
                Ok(Some(values))
            }
            Some(other) => Err(unexpected(key, other, "an array of strings")),
        }
    }

    pub(crate) fn string(&self, key: &str) -> Result<Option<String>, GeneratorError> {
        match self.0.get(key) {
            None => Ok(None),
            Some(toml::Value::String(value)) => Ok(Some(value.clone())),
            Some(other) => Err(unexpected(key, other, "a string")),
        }
    }

    pub(crate) fn integer(&self, key: &str) -> Result<Option<i64>, GeneratorError> {
        match self.0.get(key) {
            None => Ok(None),
            Some(toml::Value::Integer(value)) => Ok(Some(*value)),
            Some(other) => Err(unexpected(key, other, "an integer")),
        }
    }

    /// A boolean flag, false when the row does not declare it.
    pub(crate) fn flag(&self, key: &str) -> Result<bool, GeneratorError> {
        match self.0.get(key) {
            None => Ok(false),
            Some(toml::Value::Boolean(value)) => Ok(*value),
            Some(other) => Err(unexpected(key, other, "a boolean")),
        }
    }

    /// A table of string arrays, the form per-unit additions take.
    pub(crate) fn string_tables(
        &self,
        key: &str,
    ) -> Result<Option<BTreeMap<String, Vec<String>>>, GeneratorError> {
        match self.0.get(key) {
            None => Ok(None),
            Some(toml::Value::Table(table)) => {
                let mut mapped = BTreeMap::new();
                for (name, value) in table {
                    let toml::Value::Array(items) = value else {
                        return Err(unexpected(key, value, "an array of strings"));
                    };
                    let mut paths = Vec::new();
                    for item in items {
                        match item {
                            toml::Value::String(path) => paths.push(path.clone()),
                            other => return Err(unexpected(key, other, "a string")),
                        }
                    }
                    mapped.insert(name.clone(), paths);
                }
                Ok(Some(mapped))
            }
            Some(other) => Err(unexpected(key, other, "a table")),
        }
    }

    /// A table of string arrays indexed by unit id, validated against the scan.
    pub(crate) fn unit_strings(
        &self,
        ctx: &RenderCtx<'_>,
        key: &str,
    ) -> Result<Option<BTreeMap<String, Vec<String>>>, GeneratorError> {
        let tables = self.string_tables(key)?;
        if let Some(tables) = &tables {
            for unit in tables.keys() {
                if !ctx.shape.unit_ids().any(|candidate| candidate == unit) {
                    return Err(GeneratorError::usage(format!(
                        "`{key}` names unit `{unit}`, which the scan did not produce; available units: {}",
                        ctx.shape.unit_ids().collect::<Vec<_>>().join(", ")
                    )));
                }
            }
        }
        Ok(tables)
    }
}

fn unexpected(key: &str, found: &toml::Value, expected: &str) -> GeneratorError {
    GeneratorError::usage(format!(
        "`[[declare]]` argument `{key}` must be {expected}, found {found}"
    ))
}

/// A JSON string literal for embedding inside a single-quoted GitHub
/// expression (`fromJSON('[…]')`): `'` escapes as `\u0027` so a label can
/// never break out of the quoting, while JSON parsers decode it back.
pub(crate) fn json_string(value: &str) -> String {
    let mut out = String::from("\"");
    for ch in value.chars() {
        match ch {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\'' => out.push_str("\\u0027"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            other if other.is_control() => {
                let _ = write!(out, "\\u{:04x}", other as u32);
            }
            other => out.push(other),
        }
    }
    out.push('"');
    out
}

/// A JSON label array for a dispatch-selected velnor leg.
pub(crate) fn lanes_labels_json(labels: &[String]) -> String {
    let mut out = String::from("[");
    for (index, label) in labels.iter().enumerate() {
        if index > 0 {
            out.push(',');
        }
        out.push_str(&json_string(label));
    }
    out.push(']');
    out
}

/// The `workflow_dispatch` lanes input block for a default lane: a choice
/// between the default leg and its alternate. There is deliberately no
/// `both`: a dispatch runs one leg, and a both-alias would silently behave
/// as one leg while promising two.
pub(crate) fn lanes_dispatch_inputs(default: RunnerMode) -> &'static str {
    match default {
        RunnerMode::Velnor => "\n    inputs:\n      lanes:\n        description: velnor (default) | github\n        type: choice\n        default: velnor\n        options: [velnor, github]",
        RunnerMode::Github | RunnerMode::Both => "\n    inputs:\n      lanes:\n        description: github (default) | velnor\n        type: choice\n        default: github\n        options: [github, velnor]",
    }
}

/// The lanes input entry without its `inputs:` wrapper, for triggers that
/// already declare inputs: the lanes entry renders first, above the
/// family's own inputs.
pub(crate) fn lanes_input_entry(default: RunnerMode) -> &'static str {
    match default {
        RunnerMode::Velnor => "      lanes:\n        description: velnor (default) | github\n        type: choice\n        default: velnor\n        options: [velnor, github]\n",
        RunnerMode::Github | RunnerMode::Both => "      lanes:\n        description: github (default) | velnor\n        type: choice\n        default: github\n        options: [github, velnor]\n",
    }
}

/// Admit a `lanes_input` declaration: the repository must declare both
/// lanes, name velnor labels to select, and route them by labels alone — a
/// dispatch must never select an undeclared lane or silently drop a
/// declared runner group.
pub(crate) fn admit_lanes_input(
    config: &ProjectConfig,
    family: &str,
) -> Result<(), GeneratorError> {
    if config.runners != RunnerMode::Both {
        return Err(GeneratorError::usage(format!(
            "`{family}` `lanes_input` needs `[workflow] runners = \"both\"`: a dispatch must never select an undeclared lane"
        )));
    }
    if config.velnor_runner_group.is_some() {
        return Err(GeneratorError::usage(format!(
            "`{family}` `lanes_input` cannot route a declared runner group: the dispatch expression selects labels only"
        )));
    }
    if config.velnor_labels.is_empty() {
        return Err(GeneratorError::usage(format!(
            "`{family}` `lanes_input` needs `[workflow] velnor_labels`: a dispatch to velnor needs labels to select"
        )));
    }
    Ok(())
}

/// A dispatch-conditional `runs-on`: the default leg everywhere except a
/// manual dispatch that names the other lane. Non-dispatch events keep the
/// static default exactly, so scheduled runs and pushes never drift lanes.
pub(crate) fn lanes_runs_on(
    config: &ProjectConfig,
    family: &str,
    default: RunnerMode,
) -> Result<String, GeneratorError> {
    admit_lanes_input(config, family)?;
    match default {
        RunnerMode::Velnor => Ok(format!(
            "${{{{ (github.event_name == 'workflow_dispatch' && inputs.lanes == 'github') && {} || fromJSON('{}') }}}}",
            json_string(&config.github_runner),
            lanes_labels_json(&config.velnor_labels),
        )),
        RunnerMode::Github | RunnerMode::Both => Ok(format!(
            "${{{{ (github.event_name == 'workflow_dispatch' && inputs.lanes == 'velnor') && fromJSON('{}') || {} }}}}",
            lanes_labels_json(&config.velnor_labels),
            json_string(&config.github_runner),
        )),
    }
}

/// The unit kinds each per-unit pipeline primitive renders, in registry order.
pub(crate) fn pipeline_id(kind: UnitKind) -> &'static str {
    match kind {
        UnitKind::Rust => RUST_CRATE,
        UnitKind::Bun => BUN_PACKAGE,
        UnitKind::Node => NODE_PACKAGE,
        UnitKind::Gradle => GRADLE_PROJECT,
        UnitKind::Swift => SWIFT_PACKAGE,
        UnitKind::OpenTofu => OPENTOFU,
        UnitKind::Docker => DOCKER_IMAGE,
        UnitKind::Homebrew => HOMEBREW_TAP,
        UnitKind::Docs => DOCS_LINT,
    }
}

/// The primitive registry, in family order.
pub(crate) fn registry() -> Vec<Box<dyn Primitive>> {
    vec![
        Box::new(plan::AffectedPlan),
        Box::new(aggregate::UnitAggregation),
        Box::new(lanes::LaneMatrix),
        Box::new(cache::CacheContract),
        Box::new(watch::WatchGraph),
        Box::new(regen::RegenGate),
        Box::new(pipeline::RustCrate),
        Box::new(pipeline::BunPackage),
        Box::new(pipeline::NodePackage),
        Box::new(pipeline::GradleProject),
        Box::new(pipeline::SwiftPackage),
        Box::new(pipeline::OpenTofu),
        Box::new(pipeline::DockerImage),
        Box::new(pipeline::HomebrewTap),
        Box::new(pipeline::DocsLint),
        Box::new(release::Release),
        Box::new(release::Preview),
        Box::new(release::Maintenance),
        Box::new(release::ReleaseSigner),
        Box::new(release::StaticWorkflow),
        Box::new(renovate::Renovate),
        Box::new(renovate::RenovateValidate),
        Box::new(check_profiles::ScheduledChecks),
        Box::new(docs_site::DocsSite),
        Box::new(runtime_products::RuntimeProducts),
        Box::new(prepared_tools::PreparedTool),
    ]
}

fn lookup(id: &str) -> Result<&'static dyn Primitive, GeneratorError> {
    static REGISTRY: std::sync::OnceLock<Vec<Box<dyn Primitive>>> = std::sync::OnceLock::new();
    let registry = REGISTRY.get_or_init(registry);
    registry
        .iter()
        .map(AsRef::as_ref)
        .find(|primitive| primitive.id() == id)
        .ok_or_else(|| {
            GeneratorError::usage(format!(
                "`[[declare]]` names primitive `{id}`, which this generator does not render; known primitives: {}",
                registry
                    .iter()
                    .map(|primitive| primitive.id())
                    .collect::<Vec<_>>()
                    .join(", ")
            ))
        })
}

/// One declared primitive invocation, resolved from a config row.
#[derive(Clone, Debug)]
struct Declaration {
    primitive: String,
    units: Vec<String>,
    file: Option<String>,
    args: BTreeMap<String, toml::Value>,
}

impl Declaration {
    fn from_row(row: &crate::config::DeclareRow) -> Self {
        Self {
            primitive: row.primitive().to_owned(),
            units: row.units().to_vec(),
            file: row.file().map(str::to_owned),
            args: row.args().clone(),
        }
    }
}

/// The declared CI surface: the files, the workflow names they cover, and the
/// unit contracts the surface was rendered from.
pub(crate) struct Surface {
    /// Files the declared primitives emitted.
    pub(crate) files: BTreeMap<PathBuf, String>,
    /// Unit contracts after the unit-contract primitives ran.
    pub(crate) units: Vec<Unit>,
    /// Per-unit pipeline contracts after the declared rows were resolved.
    pub(crate) contracts: BTreeMap<String, UnitContract>,
    /// Workflow file names a declared row adds to the owned surface: a
    /// release-side family the scan did not own becomes owned by declaring it.
    pub(crate) added_files: Vec<String>,
}

/// Render the declared CI surface for a scanned repository.
///
/// A repository without declared rows keeps the generator's default surface:
/// the same families, rendered by the same primitives, with the default
/// arguments. Declared rows replace the default row of the family they name, so
/// a repository adopts the config one section at a time.
///
/// # Errors
/// Returns a usage error for a declaration that names an unknown primitive, a
/// unit the scan did not produce, a file the surface does not own, or an
/// argument the primitive does not accept.
#[expect(
    clippy::too_many_lines,
    reason = "generation stages contract resolution, rendering, and ownership in one transaction"
)]
pub(crate) fn generate(
    root: &std::path::Path,
    shape: &RepositoryShape,
    config: &ProjectConfig,
    generation: Option<&RepoGenerationConfig>,
) -> Result<Surface, GeneratorError> {
    let declared = match generation {
        Some(generation) => generation
            .declare()
            .iter()
            .map(Declaration::from_row)
            .collect::<Vec<_>>(),
        None => Vec::new(),
    };
    let rows = rows_for(config, &declared)?;

    // Contracts first: every later primitive renders against them.
    let cache = cache::resolve(&rows)?;
    let pins = Pins::resolved();

    // Unit contracts, in declaration order, before any file is rendered: the
    // watch graph and the regeneration gate define what a unit is for this
    // surface, and the project config records the same result.
    let lanes = lanes::resolve(config, &rows)?;
    let mut units = config.units.clone();
    for row in rows.iter().filter(|row| row.unit_contract) {
        let primitive = lookup(&row.primitive)?;
        // An empty `units` list means every unit: a contract is repository
        // policy about the whole surface unless it narrows itself.
        let scoped: Vec<&Unit> = if row.units.is_empty() {
            units.iter().collect()
        } else {
            units
                .iter()
                .filter(|unit| row.units.iter().any(|id| id == &unit.id))
                .collect()
        };
        let rendered = primitive.render(
            &ctx(
                root,
                shape,
                config,
                None,
                &scoped,
                row.file.as_deref(),
                primitive.id(),
                &pins,
                &lanes,
                &cache,
                &[],
                &BTreeMap::new(),
            ),
            &row.args(),
        )?;
        apply_units(&mut units, rendered.units, &row.primitive)?;
    }
    let mut resolved = config.clone();
    resolved.units.clone_from(&units);
    let lanes = lanes::resolve(&resolved, &rows)?;

    // Per-unit pipelines, then the plan, then the aggregates that compose both.
    let mut files = BTreeMap::new();
    let mut nodes = Vec::new();
    let mut contracts = BTreeMap::new();
    for row in rows.iter().filter(|row| !row.unit_contract) {
        let unit = row
            .units
            .first()
            .and_then(|id| units.iter().find(|unit| &unit.id == id));
        let primitive = lookup(&row.primitive)?;
        let rendered = primitive.render(
            &ctx(
                root,
                shape,
                &resolved,
                unit,
                &[],
                row.file.as_deref(),
                primitive.id(),
                &pins,
                &lanes,
                &cache,
                &nodes,
                &contracts,
            ),
            &row.args(),
        )?;
        for (path, content) in rendered.files {
            if files.insert(path.clone(), content).is_some() {
                return Err(GeneratorError::usage(format!(
                    "two declared primitives both render {}",
                    path.display()
                )));
            }
        }
        nodes.extend(rendered.nodes);
        merge_pipeline_contracts(&mut contracts, rendered.contracts)?;
    }

    // A declared file family can add a workflow the scan did not own: a
    // release lane becomes part of the surface by being declared, and the
    // caller extends the owned file list so it is emitted and recorded.
    let mut added_files: Vec<String> = Vec::new();
    for row in &rows {
        if row.unit_contract
            || (!release::is_release_side(&row.primitive)
                && !renovate::is_renovate_side(&row.primitive)
                && !docs_site::is_docs_site_side(&row.primitive)
                && !check_profiles::is_scheduled_checks_side(&row.primitive)
                && !runtime_products::is_runtime_products_side(&row.primitive))
        {
            continue;
        }
        let Some(file) = &row.file else {
            continue;
        };
        if config.workflow_files.iter().any(|owned| owned == file) {
            continue;
        }
        reject_owned_file(config, file, &row.primitive)?;
        if !added_files.contains(file) {
            added_files.push(file.clone());
        }
    }
    added_files.sort();
    Ok(Surface {
        files,
        units,
        contracts,
        added_files,
    })
}

fn merge_pipeline_contracts(
    contracts: &mut BTreeMap<String, UnitContract>,
    updates: BTreeMap<String, UnitContract>,
) -> Result<(), GeneratorError> {
    for (unit_id, contract) in updates {
        if contracts.insert(unit_id.clone(), contract).is_some() {
            return Err(GeneratorError::usage(format!(
                "two declared pipeline rows configure unit `{unit_id}`"
            )));
        }
    }
    Ok(())
}

/// A file a non-surface renderer owns cannot be added by a declaration: the
/// caller would emit the declared bytes and then have the legacy render
/// overwrite them. Naming the renderer that owns the file turns the silent
/// clobber into a usage error.
fn reject_owned_file(
    config: &ProjectConfig,
    file: &str,
    primitive: &str,
) -> Result<(), GeneratorError> {
    // The nested per-unit workflows are rendered for every scanned unit unless
    // the surface was adopted as reviewed templates.
    if !config.adopted_workflow_surface
        && let Some(unit) = config
            .units
            .iter()
            .find(|unit| nested_unit_workflow_file(unit) == file)
    {
        return Err(GeneratorError::usage(format!(
            "`[[declare]]` primitive `{primitive}` declares `{file}`, which the `{}` family renders for unit `{}`; declare the unit's pipeline or adopt the workflow surface instead",
            pipeline_id(unit.kind),
            unit.id
        )));
    }
    Ok(())
}

#[allow(clippy::too_many_arguments)]
fn ctx<'a>(
    root: &'a std::path::Path,
    shape: &'a RepositoryShape,
    config: &'a ProjectConfig,
    unit: Option<&'a Unit>,
    units: &'a [&'a Unit],
    file: Option<&'a str>,
    family: &'static str,
    pins: &'a Pins,
    lanes: &'a lanes::ResolvedLanes,
    cache: &'a cache::ResolvedCache,
    nodes: &'a [GraphNode],
    contracts: &'a BTreeMap<String, UnitContract>,
) -> RenderCtx<'a> {
    RenderCtx {
        root,
        shape,
        config,
        unit,
        units,
        file,
        family,
        pins,
        lanes,
        cache,
        nodes,
        contracts,
    }
}

fn apply_units(
    units: &mut [Unit],
    updates: Vec<Unit>,
    primitive: &str,
) -> Result<(), GeneratorError> {
    for update in updates {
        match units.iter_mut().find(|unit| unit.id == update.id) {
            Some(unit) => *unit = update,
            None => {
                return Err(GeneratorError::usage(format!(
                    "primitive `{primitive}` returned unit `{}`, which the scan did not produce",
                    update.id
                )))
            }
        }
    }
    Ok(())
}

/// Default rows for one side-file family: every owned file the config does not
/// declare itself, when the family contract says the file applies.
fn push_default_side_rows(
    rows: &mut Vec<ResolvedRow>,
    config: &ProjectConfig,
    declared: &[Declaration],
    side_files: &[(&str, &str)],
    available: &dyn Fn(&str) -> bool,
) {
    for (file, family) in side_files {
        if !config.workflow_files.iter().any(|owned| owned == file) {
            continue;
        }
        if declared.iter().any(|row| row.file.as_deref() == Some(file)) {
            continue;
        }
        if !available(family) {
            continue;
        }
        rows.push(ResolvedRow {
            primitive: (*family).to_owned(),
            units: Vec::new(),
            file: Some((*file).to_owned()),
            unit_contract: false,
            args: BTreeMap::new(),
        });
    }
}

/// The resolved declaration rows: the repository's rows over the default rows.
///
/// Defaults cover every family the generated surface owns, so a repository
/// without declared rows is rendered exactly as before. A declared row replaces
/// the default row of the family it names, which is what lets a repository
/// adopt the config one section at a time.
fn rows_for(
    config: &ProjectConfig,
    declared: &[Declaration],
) -> Result<Vec<ResolvedRow>, GeneratorError> {
    let mut rows: Vec<ResolvedRow> = Vec::new();
    // Contract rows configure the generation; they have no default row.
    let contracts = declared
        .iter()
        .filter(|row| is_unit_contract(&row.primitive))
        .cloned()
        .collect::<Vec<_>>();
    // Nested unit workflows. An adopted surface owns its workflow files as
    // reviewed templates and declares no per-unit family at all.
    if !config.adopted_workflow_surface {
        for unit in &config.units {
            let primitive = pipeline_id(unit.kind);
            if let Some(row) = declared
                .iter()
                .filter(|row| is_pipeline(&row.primitive))
                .find(|row| row.units.as_slice() == [unit.id.as_str()])
            {
                rows.push(ResolvedRow::declared(row));
                continue;
            }
            // A family the config owns is rendered from its rows only.
            if !declared
                .iter()
                .any(|row| is_pipeline(&row.primitive) && row.primitive == primitive)
            {
                rows.push(ResolvedRow::default_pipeline(primitive, unit));
            }
        }
    }
    // The plan job, then the aggregate workflows that compose it: the plan
    // contributes its node before any aggregate renders.
    let mut aggregates = Vec::new();
    for file in ["ci-pr.yml", "ci-main.yml", "nightly.yml"] {
        if !config.workflow_files.iter().any(|owned| owned == file) {
            continue;
        }
        match declared
            .iter()
            .find(|row| row.primitive == UNIT_AGGREGATION && row.file.as_deref() == Some(file))
        {
            Some(row) => aggregates.push(ResolvedRow::declared(row)),
            None => aggregates.push(ResolvedRow::default_aggregate(file)),
        }
    }
    if !aggregates.is_empty() {
        match declared.iter().find(|row| row.primitive == AFFECTED_PLAN) {
            Some(row) => rows.push(ResolvedRow::declared(row)),
            None => rows.push(ResolvedRow::default_plan()),
        }
    }
    rows.extend(aggregates);
    rows.extend(contracts.iter().map(ResolvedRow::declared));
    // Declared release-side families: the file rows they name, rendered by the
    // family's primitive.
    for row in declared.iter().filter(|row| {
        release::is_release_side(&row.primitive)
            || renovate::is_renovate_side(&row.primitive)
            || docs_site::is_docs_site_side(&row.primitive)
            || check_profiles::is_scheduled_checks_side(&row.primitive)
            || runtime_products::is_runtime_products_side(&row.primitive)
    }) {
        rows.push(ResolvedRow::declared(row));
    }
    // Release-side families: a default row per owned file, rendered by the
    // same primitives a declared row uses, unless the config declares the
    // family itself.
    if !config.adopted_workflow_surface {
        push_default_side_rows(
            &mut rows,
            config,
            declared,
            release::RELEASE_SIDE_FILES,
            // A repository without a release contract omits the publisher.
            &|family| family != RELEASE || config.release.is_some(),
        );
        push_default_side_rows(
            &mut rows,
            config,
            declared,
            renovate::RENOVATE_SIDE_FILES,
            &|family| {
                config
                    .renovate
                    .as_ref()
                    .is_some_and(|spec| family != RENOVATE_VALIDATE || spec.validate)
            },
        );
        push_default_side_rows(
            &mut rows,
            config,
            declared,
            docs_site::DOCS_SITE_SIDE_FILES,
            // A repository without a docs contract omits the pipeline.
            &|_| config.docs.is_some(),
        );
    }
    validate(config, declared, &rows)?;
    Ok(rows)
}

/// The per-unit pipeline primitive that renders `kind`.
/// The per-unit pipeline families: one file per unit, one graph node per unit.
const PIPELINES: &[&str] = &[
    RUST_CRATE,
    BUN_PACKAGE,
    NODE_PACKAGE,
    GRADLE_PROJECT,
    SWIFT_PACKAGE,
    OPENTOFU,
    DOCKER_IMAGE,
    HOMEBREW_TAP,
    DOCS_LINT,
];

fn is_pipeline(primitive: &str) -> bool {
    PIPELINES.contains(&primitive)
}

/// Contract rows mutate unit contracts before any file is rendered.
fn is_unit_contract(primitive: &str) -> bool {
    matches!(primitive, WATCH_GRAPH | REGEN_GATE | PREPARED_TOOL)
}

#[derive(Clone, Debug)]
struct ResolvedRow {
    primitive: String,
    units: Vec<String>,
    file: Option<String>,
    unit_contract: bool,
    args: BTreeMap<String, toml::Value>,
}

impl ResolvedRow {
    fn declared(row: &Declaration) -> Self {
        Self {
            primitive: row.primitive.clone(),
            units: row.units.clone(),
            file: row.file.clone(),
            unit_contract: is_unit_contract(&row.primitive),
            args: row.args.clone(),
        }
    }

    fn default_pipeline(primitive: &str, unit: &Unit) -> Self {
        Self {
            primitive: primitive.to_owned(),
            units: vec![unit.id.clone()],
            file: Some(crate::nested_unit_workflow_file(unit)),
            unit_contract: false,
            args: BTreeMap::new(),
        }
    }

    fn default_aggregate(file: &str) -> Self {
        Self {
            primitive: UNIT_AGGREGATION.to_owned(),
            units: Vec::new(),
            file: Some(file.to_owned()),
            unit_contract: false,
            args: BTreeMap::new(),
        }
    }

    fn default_plan() -> Self {
        Self {
            primitive: AFFECTED_PLAN.to_owned(),
            units: Vec::new(),
            file: None,
            unit_contract: false,
            args: BTreeMap::new(),
        }
    }

    fn args(&self) -> Args<'_> {
        Args(&self.args)
    }

    /// The unit the row renders, when it names exactly one.
    fn nested_file<'a>(&self, config: &'a ProjectConfig) -> Option<&'a Unit> {
        config
            .units
            .iter()
            .find(|unit| self.units.as_slice() == [unit.id.as_str()])
    }
}

/// Referential validation of the merged declaration set against the surface it
/// is about to render.
#[expect(
    clippy::too_many_lines,
    reason = "each validation rule is one fail-closed clause over the declared rows"
)]
fn validate(
    config: &ProjectConfig,
    declared: &[Declaration],
    rows: &[ResolvedRow],
) -> Result<(), GeneratorError> {
    // A declared id must be one the registry knows, and only the arguments its
    // schema names: a typo'd config must fail closed, never no-op.
    for row in declared {
        let primitive = lookup(&row.primitive)?;
        let schema = primitive.schema();
        for key in Args(&row.args).keys() {
            if !schema.contains(&key) {
                return Err(GeneratorError::usage(format!(
                    "`[[declare]]` primitive `{}` does not accept the argument `{key}`; accepted arguments: {}",
                    row.primitive,
                    schema.join(", ")
                )));
            }
        }
    }
    for row in rows {
        if row.unit_contract {
            if let Some(file) = &row.file {
                return Err(GeneratorError::usage(format!(
                    "`[[declare]]` primitive `{}` renders no workflow file, so it takes no `file`; remove `{file}`",
                    row.primitive
                )));
            }
            for id in &row.units {
                if !config.units.iter().any(|unit| &unit.id == id) {
                    return Err(GeneratorError::usage(format!(
                        "`[[declare]]` primitive `{}` names unit `{id}`, which the scan did not produce; available units: {}",
                        row.primitive,
                        config.units.iter().map(|unit| unit.id.as_str()).collect::<Vec<_>>().join(", ")
                    )));
                }
            }
            continue;
        }
        // The plan contributes a graph node, not a file; the aggregates that
        // compose it are the ones that render.
        // A per-unit pipeline names no file unless it moves the unit off the
        // canonical name, which validation rejects; the plan names no file at
        // all. Only the aggregates choose their file, from the set the surface
        // owns.
        let file = if row.primitive == UNIT_AGGREGATION {
            row.file.as_deref().ok_or_else(|| {
                GeneratorError::usage(format!(
                    "`[[declare]]` primitive `{}` renders a workflow file and needs `file`",
                    row.primitive
                ))
            })?
        } else {
            row.file.as_deref().unwrap_or_default()
        };
        if row.primitive == UNIT_AGGREGATION {
            if !config.workflow_files.iter().any(|owned| owned == file) {
                return Err(GeneratorError::usage(format!(
                    "`[[declare]]` primitive `{UNIT_AGGREGATION}` declares `{file}`, which the generated surface does not own; owned files: {}",
                    config.workflow_files.join(", ")
                )));
            }
            if !row.units.is_empty() {
                return Err(GeneratorError::usage(format!(
                    "`[[declare]]` primitive `{UNIT_AGGREGATION}` composes every declared unit and takes no `units`"
                )));
            }
        }
    }
    // Per-unit pipelines: one row per unit, the canonical file for that unit,
    // the right primitive for the unit's kind, and no silent gaps.
    let mut covered: Vec<(&str, &str)> = Vec::new();
    for row in rows.iter().filter(|row| is_pipeline(&row.primitive)) {
        let Some(unit) = row.nested_file(config) else {
            return Err(GeneratorError::usage(format!(
                "`[[declare]]` primitive `{}` must name exactly one unit",
                row.primitive
            )));
        };
        if pipeline_id(unit.kind) != row.primitive {
            return Err(GeneratorError::usage(format!(
                "unit `{}` is a {} unit, which `{}` does not render; use `{}`",
                unit.id,
                unit.kind.label(),
                row.primitive,
                pipeline_id(unit.kind)
            )));
        }
        if row.units.len() > 1 {
            return Err(GeneratorError::usage(format!(
                "`[[declare]]` primitive `{}` renders one workflow file per unit; declare one row per unit",
                row.primitive
            )));
        }
        if row
            .file
            .as_deref()
            .is_some_and(|file| file != nested_unit_workflow_file(unit))
        {
            return Err(GeneratorError::usage(format!(
                "`[[declare]]` primitive `{}` must declare unit `{}` as `{}`, not `{}`; the aggregate callers invoke the canonical file name",
                row.primitive,
                unit.id,
                nested_unit_workflow_file(unit),
                row.file.as_deref().unwrap_or_default()
            )));
        }
        covered.push((row.primitive.as_str(), unit.id.as_str()));
    }
    let mut seen = std::collections::BTreeSet::new();
    for (_, unit) in &covered {
        if !seen.insert(unit) {
            return Err(GeneratorError::usage(format!(
                "unit `{unit}` is declared twice; a unit renders exactly one workflow file"
            )));
        }
    }
    // A declared family must cover its kind: a unit that silently loses its CI
    // job is a gap, never a feature. `coverage = "explicit"` states the intent.
    let mut explicit = std::collections::BTreeSet::new();
    for row in rows.iter().filter(|row| is_pipeline(&row.primitive)) {
        if row.args().string("coverage")?.as_deref() == Some("explicit")
            && let Some(unit) = row.nested_file(config)
        {
            explicit.insert(unit.kind);
        }
    }
    for unit in &config.units {
        let primitive = pipeline_id(unit.kind);
        let family_declared = covered.iter().any(|(candidate, _)| *candidate == primitive);
        if family_declared && !covered.iter().any(|(_, id)| *id == unit.id) {
            if explicit.contains(&unit.kind) {
                continue;
            }
            return Err(GeneratorError::usage(format!(
                "`[[declare]]` rows cover {} units but not `{}`; declare every {} unit or set `coverage = \"explicit\"` to own the family's scope",
                unit.kind.label(),
                unit.id,
                unit.kind.label()
            )));
        }
    }
    // The declared release-side and Renovate families render whole-repository
    // workflow files: each names the canonical file it owns, and no units.
    for row in declared.iter().filter(|row| {
        release::is_release_side(&row.primitive)
            || renovate::is_renovate_side(&row.primitive)
            || docs_site::is_docs_site_side(&row.primitive)
            || check_profiles::is_scheduled_checks_side(&row.primitive)
            || runtime_products::is_runtime_products_side(&row.primitive)
    }) {
        if !row.units.is_empty() {
            return Err(GeneratorError::usage(format!(
                "`[[declare]]` primitive `{}` renders one whole-repository workflow and takes no `units`",
                row.primitive
            )));
        }
        let file = row.file.as_deref().ok_or_else(|| {
            GeneratorError::usage(format!(
                "`[[declare]]` primitive `{}` renders a workflow file and needs `file`",
                row.primitive
            ))
        })?;
        let canonical = release::canonical_release_side_file(&row.primitive)
            .or_else(|| renovate::canonical_renovate_side_file(&row.primitive))
            .or_else(|| docs_site::canonical_docs_site_side_file(&row.primitive))
            .or_else(|| runtime_products::canonical_runtime_products_side_file(&row.primitive));
        // Only a main-branch-driven release row renders outside `release.yml`;
        // tag-triggered kinds stay pinned to the canonical file.
        let main_branch_driven = row.primitive == RELEASE
            && Args(&row.args)
                .string("kind")
                .ok()
                .flatten()
                .is_some_and(|kind| release::is_main_branch_driven_release_kind(&kind));
        if let Some(canonical) = canonical
            && file != canonical
            && !main_branch_driven
        {
            return Err(GeneratorError::usage(format!(
                "`[[declare]]` primitive `{}` must declare `{canonical}`, not `{file}`",
                row.primitive
            )));
        }
    }
    // Release publishers render whole workflows, so two rows must share
    // neither a workflow name nor a version tag prefix: the same name would
    // collapse two publishers into one status context, and the same prefix
    // would mint one tag stream from two lanes. The default row counts: a
    // repository with a release contract already publishes `Release` from
    // `release.yml`.
    {
        let mut names: BTreeMap<String, String> = BTreeMap::new();
        let mut prefixes: BTreeMap<String, String> = BTreeMap::new();
        for row in rows.iter().filter(|row| row.primitive == RELEASE) {
            let Some(file) = row.file.as_deref() else {
                continue;
            };
            let name = release::release_workflow_name(file, &row.args())?;
            if names.insert(name.clone(), file.to_owned()).is_some() {
                return Err(GeneratorError::usage(format!(
                    "`[[declare]]` primitive `release` renders duplicate workflow name `{name}`; give each publisher its own `name`"
                )));
            }
            if let Some(prefix) = row.args().string("version_prefix")? {
                if prefix.is_empty() {
                    continue;
                }
                if let Some(owner) = prefixes.insert(prefix.clone(), file.to_owned()) {
                    return Err(GeneratorError::usage(format!(
                        "`[[declare]]` primitive `release` file `{file}` publishes tag prefix `{prefix}`, already owned by file `{owner}`"
                    )));
                }
            }
        }
    }
    // Every configured check profile renders exactly once: an uncovered
    // profile is a silent omission, and a doubly covered one would run the
    // same check on two cadences.
    {
        let mut covered = BTreeSet::new();
        for row in declared
            .iter()
            .filter(|row| check_profiles::is_scheduled_checks_side(&row.primitive))
        {
            // The label names the file, exactly like the render path: a
            // shared-selection error must point at the declare row's file,
            // not at the primitive every scheduled row shares.
            let label = row.file.as_deref().unwrap_or(row.primitive.as_str());
            for profile in
                check_profiles::select_profiles(&config.check_profiles, &Args(&row.args), label)?
            {
                if !covered.insert(profile.id.as_str()) {
                    return Err(GeneratorError::usage(format!(
                        "`[[declare]]` primitive `{}` renders check profile `{}` twice; declare each profile in exactly one scheduled-checks file",
                        row.primitive, profile.id
                    )));
                }
            }
        }
        for profile in &config.check_profiles {
            if !covered.contains(profile.id.as_str()) {
                return Err(GeneratorError::usage(format!(
                    "[[check_profile]] `{}` is rendered by no `[[declare]] primitive = \"scheduled-checks\"` row; declare the file that renders it",
                    profile.id
                )));
            }
        }
    }
    // Declaration order is canonical: the aggregate composes callers in the
    // order the rows were declared, so that order is pinned to the scan.
    let ordered = covered.iter().map(|(_, unit)| *unit).collect::<Vec<_>>();
    let canonical = config
        .units
        .iter()
        .map(|unit| unit.id.as_str())
        .filter(|id| ordered.contains(id))
        .collect::<Vec<_>>();
    if ordered != canonical {
        return Err(GeneratorError::usage(format!(
            "`[[declare]]` rows must be ordered like the scanned units ({}) so the aggregate composes a stable graph",
            canonical.join(", ")
        )));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    #![expect(
        clippy::panic,
        reason = "tests need setup failures to name their root cause"
    )]

    use super::*;

    /// Every primitive id in the registry is unique and resolvable, and the
    /// registry is exactly the families the generated surface owns.
    #[test]
    fn registry_resolves_every_declared_family() {
        let mut ids = Vec::new();
        for pipeline in PIPELINES {
            assert!(lookup(pipeline).is_ok(), "`{pipeline}` is not registered");
            ids.push(pipeline.to_owned());
        }
        for contract in [
            LANE_MATRIX,
            CACHE_CONTRACT,
            AFFECTED_PLAN,
            UNIT_AGGREGATION,
            WATCH_GRAPH,
            REGEN_GATE,
            RELEASE,
            PREVIEW,
            MAINTENANCE,
            RELEASE_SIGNER,
            STATIC_WORKFLOW,
            RENOVATE,
            RENOVATE_VALIDATE,
            SCHEDULED_CHECKS,
            DOCS_SITE,
        ] {
            assert!(lookup(contract).is_ok(), "`{contract}` is not registered");
            ids.push(contract);
        }
        let unique = ids.iter().collect::<std::collections::BTreeSet<_>>();
        assert_eq!(unique.len(), ids.len(), "duplicate primitive id");
    }

    /// An unknown primitive is a usage error that names what is known.
    #[test]
    fn unknown_primitive_names_the_registry() {
        let error = match lookup("not-a-primitive") {
            Err(error) => error.to_string(),
            Ok(_) => panic!("an unknown primitive is a usage error"),
        };
        assert!(error.contains("not-a-primitive"), "{error}");
        assert!(error.contains("rust-crate-pipeline"), "{error}");
    }

    /// Contract rows and file rows partition the registry: a primitive is
    /// never both.
    #[test]
    fn contracts_and_file_rows_partition_the_registry() {
        let registry = registry();
        for primitive in registry.iter().map(AsRef::as_ref) {
            let contract = is_unit_contract(primitive.id());
            let file_row = !contract;
            assert!(
                contract ^ file_row,
                "`{}` is neither a contract nor a file row",
                primitive.id()
            );
            if is_pipeline(primitive.id()) {
                assert!(
                    !contract,
                    "`{}` is a pipeline, not a contract",
                    primitive.id()
                );
            }
        }
    }

    /// A contract primitive that returns a unit the scan did not produce is a
    /// usage error, not a silent widening of the surface.
    #[test]
    fn contract_updates_must_match_scanned_units() {
        let mut units = Vec::new();
        let error = match apply_units(
            &mut units,
            vec![crate::scan::unit(
                UnitKind::Rust,
                "crates/example",
                Vec::new(),
                Vec::new(),
                None,
            )],
            "watch-graph",
        ) {
            Err(error) => error.to_string(),
            Ok(()) => panic!("a contract update for an unscanned unit is a usage error"),
        };
        assert!(error.contains("watch-graph"), "{error}");
        assert!(error.contains("which the scan did not produce"), "{error}");
    }

    /// The lanes dispatch block offers exactly the two legs around the
    /// default: no `both` alias that would silently behave as one leg.
    #[test]
    fn lanes_dispatch_inputs_offer_exactly_two_legs() {
        for (default, name, alternate) in [
            (RunnerMode::Github, "github", "velnor"),
            (RunnerMode::Velnor, "velnor", "github"),
        ] {
            let inputs = lanes_dispatch_inputs(default);
            assert!(
                inputs.contains(&format!("description: {name} (default) | {alternate}"))
                    && inputs.contains(&format!("default: {name}"))
                    && inputs.contains("type: choice"),
                "{inputs}"
            );
            assert!(!inputs.contains("both"), "{inputs}");
            let entry = lanes_input_entry(default);
            assert!(
                entry.contains(&format!("description: {name} (default) | {alternate}"))
                    && !entry.contains("both"),
                "{entry}"
            );
        }
    }

    /// Expression-embedded strings cannot break out of the single-quoted
    /// `fromJSON`: quotes, backslashes, and controls all escape.
    #[test]
    fn json_string_escapes_expression_breakouts() {
        assert_eq!(json_string("ubuntu-24.04"), "\"ubuntu-24.04\"");
        assert_eq!(
            lanes_labels_json(&["self-hosted".to_owned(), "o'brien".to_owned()]),
            "[\"self-hosted\",\"o\\u0027brien\"]"
        );
        assert_eq!(
            json_string("a\"b\\c'd"),
            "\"a\\\"b\\\\c\\u0027d\"",
            "quotes, backslashes, and apostrophes escape"
        );
    }
}
