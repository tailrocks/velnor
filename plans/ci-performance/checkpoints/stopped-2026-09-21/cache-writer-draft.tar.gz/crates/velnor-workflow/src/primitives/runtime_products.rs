//! Stage-0 runtime-product producer: the owner-only publisher of immutable
//! `velnor-workflow` binaries.
//!
//! Consumers never compile: the setup action and the Velnor policy provisioner
//! download `velnor-workflow-<RUNNER_OS>-<RUNNER_ARCH>` plus `manifest.json`
//! from the immutable release the closure names, then prove attestation,
//! manifest, digest, and the binary's own `--closure` and `--revision`
//! reports. This module
//! renders the workflow that publishes those releases. The consumer contract
//! is the specification: the tag scheme, the manifest shape, the attestation
//! subject, and the acceptance filter below mirror the setup action byte for
//! byte, and the conformance tests pin that agreement against the action
//! source itself.
//!
//! The workflow is owner-only infrastructure. It renders only for the
//! repository that ships the setup action (derived from the action's own
//! coordinate, never spelled out); every other repository gets no file, and a
//! declared row on a non-owner fails closed.
//!
//! Layout: a `closure` job first proves the run targets the default branch
//! (a dispatch from anywhere else fails instead of publishing), then resolves
//! the source closure of `HEAD` and checks whether its tag already exists
//! (unchanged closure, no rebuild); a `build` matrix compiles natively on one
//! runner per consumer platform, proves each binary reports the tag closure,
//! attests it, and uploads it; a `publish` job first proves it still owns its
//! tag (a fresher same-closure run publishes instead), then proves transport
//! integrity, assembles the manifest, attests it, smoke-tests the exact
//! consumer flow against those same bytes, and only then creates the release
//! without ever overwriting — no consumer can see a product whose
//! verification failed. Publishes serialize on the tag across refs, the
//! create carries no `--target` (a stale target would demand the workflows
//! scope `GITHUB_TOKEN` can never hold), and a conflicting create converges
//! instead of failing: this workflow is the sole writer of product tags.

use std::fmt::Write as _;

use super::{Args, Primitive, RenderCtx, Rendered};
use crate::closure::{
    product_tag, CI_FEATURES, CLOSURE_PATHS, CLOSURE_VERSION, PRODUCT_TAG_PREFIX, PROFILE_RELEASE,
};
use crate::{
    config_rust_toolchain, workflow_setup_action_repository, yaml_scalar, ActionPin,
    GeneratorError, ProjectConfig, RustToolchain, GENERATED_HEADER, HOSTED_WORKFLOW_RUNTIME_HOME,
};

/// The workflow file the producer renders into. Consumers pin this path in
/// their attestation check, so the name is load-bearing: a rename breaks
/// every verifier until the setup action ships the new pin with it.
pub(crate) const RUNTIME_PRODUCTS_FILE: &str = "ci-runtime-products.yml";

/// The producer side-file family and the canonical file it renders.
pub(crate) const RUNTIME_PRODUCTS_SIDE_FILES: &[(&str, &str)] =
    &[(RUNTIME_PRODUCTS_FILE, super::RUNTIME_PRODUCTS)];

/// Whether `primitive` renders the runtime-product producer workflow.
pub(crate) fn is_runtime_products_side(primitive: &str) -> bool {
    RUNTIME_PRODUCTS_SIDE_FILES
        .iter()
        .any(|(_, family)| *family == primitive)
}

/// The canonical filename the runtime-product primitive renders.
pub(crate) fn canonical_runtime_products_side_file(primitive: &str) -> Option<&'static str> {
    RUNTIME_PRODUCTS_SIDE_FILES
        .iter()
        .find(|(_, family)| *family == primitive)
        .map(|(file, _)| *file)
}

/// The platform→builder mapping: which runner natively compiles each
/// consumer platform's product. These labels are product infrastructure fixed
/// in generator source — a closure-covered path — not lane configuration: a
/// mapping change is a generator source change, so it alters the closure and
/// mints a new product tag instead of reusing the stale tag's binaries. Owner
/// lane labels (`github_runner`, `macos_runner`) move freely without
/// affecting the builders, and can never silently reselect them.
const LINUX_X64_RUNNER: &str = "ubuntu-24.04";
const LINUX_ARM64_RUNNER: &str = "ubuntu-24.04-arm";
const MACOS_ARM64_RUNNER: &str = "macos-15";

/// The manifest acceptance filter, exactly as the setup action evaluates it:
/// full closure, a well-formed source revision, release profile, empty
/// features, a 64-hex digest for the platform, and the asset name the
/// platform expects. The publish job evaluates this same filter over the
/// assembled manifest, so a manifest no consumer would accept never reaches
/// a release.
///
/// The revision clause is well-formedness, not equality with the requested
/// revision: several commits can share one closure (and therefore one
/// product), so the manifest names the commit the producer built from while
/// the consumer requested another. Both consumers bind the binary to the
/// manifest instead, requiring its `--revision` report to equal the
/// manifest's `revision`.
const MANIFEST_ACCEPT_FILTER: &str = ".closure == $closure and (.revision | test(\"^[0-9a-f]{40}$\")) and .profile == \"release\" and .features == \"\" and (.products[$platform].binary | test(\"^[0-9a-f]{64}$\")) and .products[$platform].asset == $asset";

/// The isolated Cargo home the producer steps build under, as a rendered
/// step-level `env:` value. The `runner` context is unavailable in job-level
/// `env:` (GitHub rejects the workflow at compile time), so each step that
/// needs isolation carries this as step-level `env:`, which does provide
/// `runner`.
const PRODUCER_CARGO_HOME_VALUE: &str = "${{ runner.temp }}/velnor-producer-cargo-home";

/// One natively built consumer platform: the `RUNNER_OS`-`RUNNER_ARCH` pair
/// the setup action resolves its asset name from, and the fixed runner that
/// builds it. Linux X64 serves the Linux lane and the Velnor hosts, Linux
/// ARM64 serves ARM consumers of both, and macOS ARM64 serves the Apple lane
/// (no lane in the repository selects an Intel Mac, so there is no macOS X64
/// consumer to build for).
struct Platform {
    os: &'static str,
    arch: &'static str,
    runner: &'static str,
}

impl Platform {
    /// The `RUNNER_OS`-`RUNNER_ARCH` platform key: the manifest key and the
    /// asset suffix in one.
    fn key(&self) -> String {
        format!("{}-{}", self.os, self.arch)
    }

    /// The release asset name the setup action downloads for this platform.
    fn asset(&self) -> String {
        format!("velnor-workflow-{}", self.key())
    }
}

/// The consumer platforms, in manifest order. All three builders are the
/// fixed product-infrastructure mapping, independent of lane configuration.
fn platforms() -> [Platform; 3] {
    [
        Platform {
            os: "Linux",
            arch: "X64",
            runner: LINUX_X64_RUNNER,
        },
        Platform {
            os: "Linux",
            arch: "ARM64",
            runner: LINUX_ARM64_RUNNER,
        },
        Platform {
            os: "macOS",
            arch: "ARM64",
            runner: MACOS_ARM64_RUNNER,
        },
    ]
}

/// The product owner: the organization of the repository that ships the setup
/// action. Derived from the action's own coordinate so owner routing cannot
/// drift from it.
fn product_owner(repository: &str) -> &str {
    repository
        .split_once('/')
        .map_or(repository, |(owner, _)| owner)
}

/// The tag the zero closure names: the worked example of the tag scheme the
/// workflow header carries. The renderer knows no closure — the workflow
/// resolves it per run — so the example pins the scheme visibly to
/// [`product_tag`]: if the prefix ever changes, the header follows it.
fn example_tag() -> String {
    product_tag(&"0".repeat(64))
}

/// The `ci-runtime-products.yml` content for a config, or `None` for every
/// repository that is not the setup-action owner. The owner check compares
/// against the action coordinate, so fixture repositories (empty or foreign)
/// render no file and their goldens never see this surface.
#[expect(
    clippy::too_many_lines,
    reason = "one workflow family renders its three jobs in one template"
)]
pub(crate) fn runtime_products_content(config: &ProjectConfig) -> Option<String> {
    if config.repository != workflow_setup_action_repository() {
        return None;
    }
    let repository = workflow_setup_action_repository();
    let owner = product_owner(repository);
    // The toolchain install is file-driven: the checkout's own
    // `rust-toolchain.toml` — itself a closure input — pins the channel, so a
    // config without a scanned Rust unit still provisions exactly the pinned
    // toolchain. The scan guarantees the pin on real repositories; the
    // fallback only serves hand-built configs.
    let toolchain = config_rust_toolchain(config).unwrap_or(RustToolchain {
        channel: String::new(),
        components: Vec::new(),
        targets: Vec::new(),
        profile: None,
    });
    let mut toolchain_steps = String::new();
    super::render_pinned_toolchain_steps(
        &mut toolchain_steps,
        ActionPin::CacheRestore.reference(),
        ActionPin::CacheSave.reference(),
        &toolchain,
        Some(&format!(
            "{} && steps.rustup-toolchain.outputs.cache-hit != 'true'",
            super::default_branch_push_cache_save_expression(&config.default_branch)
        )),
    );
    // Step-level isolation for the provision step only: restore/save touch
    // `~/.rustup` alone, while `rustup toolchain install` must not read an
    // ambient cargo config. The shared renderer stays untouched so no other
    // family gains this env.
    toolchain_steps = toolchain_steps.replace(
        "      - name: Provision Rust toolchain\n        shell: bash\n",
        &format!(
            "      - name: Provision Rust toolchain\n        shell: bash\n        env:\n          CARGO_HOME: {PRODUCER_CARGO_HOME_VALUE}\n"
        ),
    );
    let platforms = platforms();
    let mut matrix = String::new();
    for platform in &platforms {
        let _ = writeln!(
            matrix,
            "          - os: {}\n            arch: {}\n            runner: {}",
            platform.os,
            platform.arch,
            yaml_scalar(platform.runner),
        );
    }
    let mut manifest_products = String::new();
    for (index, platform) in platforms.iter().enumerate() {
        if index > 0 {
            manifest_products.push_str(", ");
        }
        let _ = write!(
            manifest_products,
            "\"{key}\": {{binary: ${var}, asset: \"{asset}\"}}",
            key = platform.key(),
            asset = platform.asset(),
            var = platform_variable(platform),
        );
    }
    let manifest_program = format!(
        "{{closure: $closure, revision: $revision, profile: \"release\", features: \"\", products: {{{manifest_products}}}}}"
    );
    let mut manifest_digests = String::new();
    for platform in &platforms {
        let _ = writeln!(
            manifest_digests,
            "            --arg {var} \"$(cat dist/{asset}.sha256)\" \\",
            var = platform_variable(platform),
            asset = platform.asset(),
        );
    }
    let platform_list = platforms
        .iter()
        .map(Platform::key)
        .collect::<Vec<_>>()
        .join(" ");
    let release_assets = platforms
        .iter()
        .map(|platform| format!("dist/{}", platform.asset()))
        .collect::<Vec<_>>()
        .join(" ");
    let closure_footer = format!(
        "closure-version:{CLOSURE_VERSION}\\nfeatures:{CI_FEATURES}\\nprofile:{PROFILE_RELEASE}\\n"
    );
    Some(format!(
        r#"{header}# Stage-0 runtime products: the immutable `velnor-workflow` binaries every
# consumer lane installs through the setup action instead of compiling.
#
# One release per source closure: tags name the closure's product tag (worked
# example for the zero closure: `{example_tag}`), so an unrelated monorepo
# change never rebuilds the runtime. Each platform job builds natively with
# `cargo build --locked --no-default-features --release`, proves the binary's
# own `--closure` report equals the tag closure and its `--revision` report
# equals the build commit, attests the asset, and uploads it; the publish
# job proves transport integrity, assembles `manifest.json` (naming the
# source revision it built from), attests it, smoke-tests the exact consumer
# flow (attestation, manifest, digest, self-report) against those same bytes,
# and only then creates the release. Verification precedes exposure: a
# product no consumer would accept never reaches a release.
#
# The workflow never overwrites: when the tag already exists the run skips,
# the publish job yields to a fresher same-closure run, serializes on the
# tag across refs, re-checks immediately before creating, and converges when
# a conflicting create loses instead of failing. The create carries no
# target: the tag names the closure, never the commit, so the API tags the
# default-branch tip when the tag is missing and never moves a tag. This
# workflow is the sole writer of product tags — no pre-tagging, no second
# path.
name: Velnor workflow runtime products
run-name: Runtime products · ${{{{ github.event_name }}}} · ${{{{ github.ref_name }}}}

on:
  push:
    branches: [{default_branch}]
  workflow_dispatch:

# Same-ref runs serialize so two pushes can never race on one release; a
# publish in flight is never cancelled. Same-closure runs across refs (a main
# push and a dispatch name the same tag) serialize again on the tag in the
# publish job, which owns the shared resource.
concurrency:
  group: runtime-products-${{{{ github.ref }}}}
  cancel-in-progress: false

permissions:
  contents: read

jobs:
  closure:
    name: Resolve runtime closure
    runs-on: {closure_runner}
    timeout-minutes: 10
    outputs:
      closure: ${{{{ steps.closure.outputs.value }}}}
      tag: ${{{{ steps.closure.outputs.tag }}}}
      head-sha: ${{{{ steps.closure.outputs.head-sha }}}}
      exists: ${{{{ steps.exists.outputs.exists }}}}
    steps:
      - name: Prove the default-branch ref
        shell: bash
        env:
          REF: ${{{{ github.ref }}}}
        run: |
          set -euo pipefail
          [[ "$REF" == "{branch_ref}" ]] || {{ echo "::error::the producer publishes only from {branch_ref}, got $REF" >&2; exit 1; }}
      - name: Checkout
        uses: {checkout}
        with:
          persist-credentials: false
      - name: Resolve source closure
        id: closure
        shell: bash
        run: |
          set -euo pipefail
          command -v sha256sum >/dev/null 2>&1 || {{ echo "::error::sha256sum is required on the closure runner" >&2; exit 1; }}
          head="$(git rev-parse HEAD)"
          [[ "$head" =~ ^[0-9a-f]{{40}}$ ]] || {{ echo "::error::HEAD is not a commit SHA: $head" >&2; exit 1; }}
          listing="$(git ls-tree -r HEAD -- {closure_paths})"
          test "$listing" != '' || {{ echo "::error::HEAD has no closure inputs" >&2; exit 1; }}
          closure="$(printf '%s\n{closure_footer}' "$(LC_ALL=C sort <<<"$listing")" | sha256sum | awk '{{print $1}}')"
          [[ "$closure" =~ ^[0-9a-f]{{64}}$ ]] || {{ echo "::error::closure resolution failed" >&2; exit 1; }}
          tag="{tag_prefix}${{closure:0:16}}"
          {{
            echo "value=$closure"
            echo "tag=$tag"
            echo "head-sha=$head"
          }} >> "$GITHUB_OUTPUT"
      - name: Check for an existing product
        id: exists
        shell: bash
        env:
          GH_TOKEN: ${{{{ github.token }}}}
          TAG: ${{{{ steps.closure.outputs.tag }}}}
        run: |
          set -euo pipefail
          if gh release view "$TAG" --repo {repository} >/dev/null 2>&1; then
            echo "exists=true" >> "$GITHUB_OUTPUT"
          else
            echo "exists=false" >> "$GITHUB_OUTPUT"
          fi

  build:
    name: Build runtime (${{{{ matrix.os }}}}-${{{{ matrix.arch }}}})
    needs: closure
    if: needs.closure.outputs.exists != 'true'
    strategy:
      fail-fast: false
      matrix:
        include:
{matrix}    runs-on: ${{{{ matrix.runner }}}}
    timeout-minutes: 60
    permissions:
      contents: read
      id-token: write
      attestations: write
    # The producer builds with an isolated Cargo home: no ambient registry,
    # git checkouts, or cargo config from the runner image can enter the
    # build. The toolchain steps cache `~/.rustup` only, which rustup owns.
    # Each step that needs the isolated home (provision, hermetic proof,
    # build, product proof) carries it as step-level `env:`: the `runner`
    # context is unavailable in job-level `env:`.
    steps:
      - name: Checkout
        uses: {checkout}
        with:
          persist-credentials: false
{toolchain_steps}      - name: Prove a hermetic build environment
        shell: bash
        env:
          CARGO_HOME: {cargo_home}
        run: |
          set -euo pipefail
          test -z "$(git status --porcelain)" || {{ echo "::error::the producer checkout is not clean" >&2; exit 1; }}
          test -z "${{RUSTFLAGS:-}}" || {{ echo "::error::RUSTFLAGS is set: ${{RUSTFLAGS}}" >&2; exit 1; }}
          test -z "${{CARGO_ENCODED_RUSTFLAGS:-}}" || {{ echo "::error::CARGO_ENCODED_RUSTFLAGS is set" >&2; exit 1; }}
          test -z "${{RUSTC_WRAPPER:-}}" || {{ echo "::error::RUSTC_WRAPPER is set: ${{RUSTC_WRAPPER}}" >&2; exit 1; }}
          [[ "${{CARGO_HOME:-}}" == "${{RUNNER_TEMP:?}}/"* ]] || {{ echo "::error::CARGO_HOME is not the isolated producer home: ${{CARGO_HOME:-<unset>}}" >&2; exit 1; }}
      - name: Build release runtime
        shell: bash
        env:
          CARGO_HOME: {cargo_home}
        run: cargo build --locked --no-default-features --release --package velnor-workflow --bin velnor-workflow
      - name: Prove the product closure
        id: prove
        shell: bash
        env:
          CLOSURE: ${{{{ needs.closure.outputs.closure }}}}
          CARGO_HOME: {cargo_home}
        run: |
          set -euo pipefail
          binary=target/release/velnor-workflow
          test -x "$binary" || {{ echo "::error::no release binary at $binary" >&2; exit 1; }}
          reported="$("$binary" --closure)"
          [[ "$reported" == "$CLOSURE" ]] || {{ echo "::error::built binary reports closure $reported, expected $CLOSURE" >&2; exit 1; }}
          head="$(git rev-parse HEAD)"
          reported_revision="$("$binary" --revision)"
          [[ "$reported_revision" == "$head" ]] || {{ echo "::error::built binary reports revision $reported_revision, expected $head" >&2; exit 1; }}
          asset="velnor-workflow-${{RUNNER_OS}}-${{RUNNER_ARCH}}"
          cp "$binary" "$asset"
          if command -v sha256sum >/dev/null 2>&1; then
            digest="$(sha256sum "$asset" | awk '{{print $1}}')"
          else
            digest="$(shasum -a 256 "$asset" | awk '{{print $1}}')"
          fi
          [[ "$digest" =~ ^[0-9a-f]{{64}}$ ]] || {{ echo "::error::digest computation failed" >&2; exit 1; }}
          printf '%s' "$digest" > "$asset.sha256"
          echo "asset=$asset" >> "$GITHUB_OUTPUT"
      - name: Attest runtime asset
        uses: {attest}
        with:
          subject-path: ${{{{ steps.prove.outputs.asset }}}}
      - name: Upload runtime asset
        uses: {upload}
        with:
          name: runtime-${{{{ matrix.os }}}}-${{{{ matrix.arch }}}}
          path: |
            ${{{{ steps.prove.outputs.asset }}}}
            ${{{{ steps.prove.outputs.asset }}}}.sha256
          if-no-files-found: error
          retention-days: 7

  publish:
    name: Publish runtime products
    needs: [closure, build]
    if: needs.closure.outputs.exists != 'true'
    runs-on: {publish_runner}
    timeout-minutes: 20
    # The true shared resource is the closure tag, not the ref: back-to-back
    # pushes with an unchanged closure — and a main push beside a dispatch —
    # name the same tag, so publishes serialize on it across refs. A publish
    # in flight is never cancelled.
    concurrency:
      group: runtime-products-tag-${{{{ needs.closure.outputs.tag }}}}
      cancel-in-progress: false
    permissions:
      contents: write
      id-token: write
      attestations: write
    steps:
      - name: Checkout default-branch tip
        uses: {checkout}
        with:
          ref: {default_branch}
          persist-credentials: false
      - name: Prove publish freshness
        shell: bash
        env:
          CLOSURE: ${{{{ needs.closure.outputs.closure }}}}
          HEAD_SHA: ${{{{ needs.closure.outputs.head-sha }}}}
          TAG: ${{{{ needs.closure.outputs.tag }}}}
        run: |
          set -euo pipefail
          # The closure job resolved CLOSURE at HEAD_SHA, but the build took
          # minutes and the default branch may have moved since. Re-resolve at
          # the tip: when the closure is unchanged the fresher run owns this
          # tag and this run yields. A resolve-time check cannot see this —
          # staleness is born mid-build.
          command -v sha256sum >/dev/null 2>&1 || {{ echo "::error::sha256sum is required on the publish runner" >&2; exit 1; }}
          tip="$(git rev-parse HEAD)"
          [[ "$tip" =~ ^[0-9a-f]{{40}}$ ]] || {{ echo "::error::HEAD is not a commit SHA: $tip" >&2; exit 1; }}
          if [[ "$tip" == "$HEAD_SHA" ]]; then
            exit 0
          fi
          listing="$(git ls-tree -r HEAD -- {closure_paths})"
          test "$listing" != '' || {{ echo "::error::HEAD has no closure inputs" >&2; exit 1; }}
          tip_closure="$(printf '%s\n{closure_footer}' "$(LC_ALL=C sort <<<"$listing")" | sha256sum | awk '{{print $1}}')"
          [[ "$tip_closure" =~ ^[0-9a-f]{{64}}$ ]] || {{ echo "::error::closure resolution failed" >&2; exit 1; }}
          if [[ "$tip_closure" == "$CLOSURE" ]]; then
            echo "::notice::the default branch moved to $tip with unchanged closure; the fresher run owns $TAG"
            exit 0
          fi
      - name: Download runtime assets
        uses: {download}
        with:
          path: dist
          merge-multiple: true
      - name: Assemble and verify the release
        id: assemble
        shell: bash
        env:
          CLOSURE: ${{{{ needs.closure.outputs.closure }}}}
          HEAD_SHA: ${{{{ needs.closure.outputs.head-sha }}}}
        run: |
          set -euo pipefail
          # The build jobs proved each binary's identity on its native runner;
          # here the digests they shipped prove the artifact transport moved
          # the same bytes. Only the native binary runs again, as a spot check.
          for platform in {platform_list}; do
            asset="velnor-workflow-$platform"
            test -s "dist/$asset" || {{ echo "::error::missing product asset $asset" >&2; exit 1; }}
            test -s "dist/$asset.sha256" || {{ echo "::error::missing digest for $asset" >&2; exit 1; }}
            expected="$(cat "dist/$asset.sha256")"
            [[ "$expected" =~ ^[0-9a-f]{{64}}$ ]] || {{ echo "::error::malformed digest for $asset" >&2; exit 1; }}
            actual="$(sha256sum "dist/$asset" | awk '{{print $1}}')"
            [[ "$actual" == "$expected" ]] || {{ echo "::error::transport digest mismatch for $asset" >&2; exit 1; }}
            # Artifact transport strips POSIX execute bits; restore them after
            # the digest proof so the native spot check below can execute.
            chmod 0755 "dist/$asset"
          done
          reported="$(./dist/velnor-workflow-Linux-X64 --closure)"
          [[ "$reported" == "$CLOSURE" ]] || {{ echo "::error::published binary reports closure $reported, expected $CLOSURE" >&2; exit 1; }}
          reported_revision="$(./dist/velnor-workflow-Linux-X64 --revision)"
          [[ "$reported_revision" == "$HEAD_SHA" ]] || {{ echo "::error::published binary reports revision $reported_revision, expected $HEAD_SHA" >&2; exit 1; }}
          jq -n \
            --arg closure "$CLOSURE" \
            --arg revision "$HEAD_SHA" \
{manifest_digests}            '{manifest_products}' \
            > dist/manifest.json
          for platform in {platform_list}; do
            jq -e --arg closure "$CLOSURE" --arg platform "$platform" --arg asset "velnor-workflow-$platform" \
              '{accept_filter}' dist/manifest.json >/dev/null
          done
          manifest_revision="$(jq -er '.revision' dist/manifest.json)"
          [[ "$manifest_revision" == "$HEAD_SHA" ]] || {{ echo "::error::assembled manifest names revision $manifest_revision, expected $HEAD_SHA" >&2; exit 1; }}
      - name: Attest release manifest
        uses: {attest}
        with:
          subject-path: dist/manifest.json
      - name: Smoke-test the release
        shell: bash
        env:
          GH_TOKEN: ${{{{ github.token }}}}
          CLOSURE: ${{{{ needs.closure.outputs.closure }}}}
        run: |
          set -euo pipefail
          # The exact consumer flow, against the local bytes the release will
          # publish: attestation, manifest, digest, and the self-report from
          # the install layout the setup action uses. The release is created
          # only after this flow passes, so a product no consumer would
          # accept fails the publish instead of shipping silently.
          asset="velnor-workflow-${{RUNNER_OS}}-${{RUNNER_ARCH}}"
          gh attestation verify "dist/$asset" --owner {owner} --signer-workflow {repository}/.github/workflows/{workflow_file} --source-ref {branch_ref}
          gh attestation verify "dist/manifest.json" --owner {owner} --signer-workflow {repository}/.github/workflows/{workflow_file} --source-ref {branch_ref}
          jq -e --arg closure "$CLOSURE" --arg platform "${{RUNNER_OS}}-${{RUNNER_ARCH}}" --arg asset "$asset" \
            '{accept_filter}' "dist/manifest.json" >/dev/null
          actual="$(sha256sum "dist/$asset" | awk '{{print $1}}')"
          expected="$(jq -er --arg platform "${{RUNNER_OS}}-${{RUNNER_ARCH}}" '.products[$platform].binary' "dist/manifest.json")"
          [[ "$actual" == "$expected" ]] || {{ echo "::error::smoke-test digest mismatch" >&2; exit 1; }}
          runtime="{runtime_home}/$CLOSURE"
          mkdir -p "$runtime/bin"
          cp "dist/$asset" "$runtime/bin/velnor-workflow"
          chmod 0755 "$runtime/bin/velnor-workflow"
          cp "dist/manifest.json" "$runtime/manifest.json"
          chmod 0644 "$runtime/manifest.json"
          reported="$("$runtime/bin/velnor-workflow" --closure)"
          [[ "$reported" == "$CLOSURE" ]] || {{ echo "::error::installed runtime reports closure $reported, expected $CLOSURE" >&2; exit 1; }}
          manifest_revision="$(jq -er '.revision' "dist/manifest.json")"
          reported_revision="$("$runtime/bin/velnor-workflow" --revision)"
          [[ "$reported_revision" == "$manifest_revision" ]] || {{ echo "::error::installed runtime reports revision $reported_revision, expected $manifest_revision" >&2; exit 1; }}
      - name: Create the release
        shell: bash
        env:
          GH_TOKEN: ${{{{ github.token }}}}
          CLOSURE: ${{{{ needs.closure.outputs.closure }}}}
          TAG: ${{{{ needs.closure.outputs.tag }}}}
          HEAD_SHA: ${{{{ needs.closure.outputs.head-sha }}}}
        run: |
          set -euo pipefail
          # Every verification above passed on exactly these bytes; the
          # re-check immediately before creating keeps the never-overwrite
          # promise against a concurrent run that published first.
          if gh release view "$TAG" --repo {repository} >/dev/null 2>&1; then
            echo "::notice::release $TAG already exists; leaving it untouched"
            exit 0
          fi
          # No target: the tag names the closure, never the commit, so the
          # API tags the default-branch tip when the tag is missing and there
          # is exactly one tag path — create-if-missing, never move. A stale
          # target would diff target..HEAD and demand the workflows scope
          # GITHUB_TOKEN can never hold whenever the range carries workflow
          # files (cli/cli#9514).
          if gh release create "$TAG" --repo {repository} --title "$TAG" \
            --notes "Immutable velnor-workflow runtime product for source closure $CLOSURE (built from $HEAD_SHA). Consumers verify the manifest digest, the binary self-report, and the build provenance attestation." \
            {release_assets} dist/manifest.json; then
            exit 0
          fi
          # Conflict converges, never fails: a concurrent run may have
          # published between the re-check and the create. Re-view with
          # backoff; the winner carries this same tag, hence this same
          # closure, so its appearance is success. Fail only if nothing
          # materializes.
          converged=false
          for delay in 5 10 15 30; do
            sleep "$delay"
            if gh release view "$TAG" --repo {repository} >/dev/null 2>&1; then
              converged=true
              break
            fi
          done
          if [[ "$converged" == true ]]; then
            echo "::notice::release $TAG appeared after a conflicting create; converging"
            exit 0
          fi
          echo "::error::release $TAG was not created and did not appear" >&2
          exit 1
"#,
        header = GENERATED_HEADER,
        example_tag = example_tag(),
        default_branch = yaml_scalar(&config.default_branch),
        branch_ref = format!("refs/heads/{}", config.default_branch),
        closure_runner = yaml_scalar(&config.github_runner),
        publish_runner = yaml_scalar(&config.github_runner),
        checkout = ActionPin::Checkout.reference(),
        attest = ActionPin::Attest.reference(),
        upload = ActionPin::UploadArtifact.reference(),
        download = ActionPin::DownloadArtifact.reference(),
        repository = repository,
        owner = owner,
        workflow_file = RUNTIME_PRODUCTS_FILE,
        runtime_home = HOSTED_WORKFLOW_RUNTIME_HOME,
        tag_prefix = PRODUCT_TAG_PREFIX,
        closure_paths = CLOSURE_PATHS.join(" "),
        closure_footer = closure_footer,
        matrix = matrix,
        manifest_products = manifest_program,
        manifest_digests = manifest_digests,
        platform_list = platform_list,
        release_assets = release_assets,
        accept_filter = MANIFEST_ACCEPT_FILTER,
        cargo_home = PRODUCER_CARGO_HOME_VALUE,
    ))
}

/// The `jq` variable holding a platform's digest while the manifest assembles:
/// `linux_x64` for `Linux-X64`, and so on.
fn platform_variable(platform: &Platform) -> String {
    platform.key().replace('-', "_").to_ascii_lowercase()
}

/// The declared runtime-product producer.
pub(crate) struct RuntimeProducts;

impl Primitive for RuntimeProducts {
    fn id(&self) -> &'static str {
        super::RUNTIME_PRODUCTS
    }

    fn schema(&self) -> &'static [&'static str] {
        &[]
    }

    fn render(&self, ctx: &RenderCtx<'_>, _args: &Args<'_>) -> Result<Rendered, GeneratorError> {
        if ctx.config.repository != workflow_setup_action_repository() {
            return Err(GeneratorError::usage(format!(
                "`{}` renders `{RUNTIME_PRODUCTS_FILE}` only for the repository that ships the setup action",
                ctx.family
            )));
        }
        let file = ctx
            .file
            .filter(|file| !file.is_empty())
            .ok_or_else(|| {
                GeneratorError::usage(format!(
                    "`{}` renders `{RUNTIME_PRODUCTS_FILE}` and needs `file`",
                    ctx.family
                ))
            })?
            .to_owned();
        let Some(content) = runtime_products_content(ctx.config) else {
            return Err(GeneratorError::usage(format!(
                "`{}` renders `{RUNTIME_PRODUCTS_FILE}` only for the repository that ships the setup action",
                ctx.family
            )));
        };
        Ok(Rendered {
            files: std::iter::once((
                std::path::PathBuf::from(".github/workflows").join(file),
                content,
            ))
            .collect(),
            ..Rendered::default()
        })
    }
}

#[cfg(test)]
mod tests {
    #![expect(
        clippy::panic,
        reason = "tests need setup failures to name their root cause"
    )]

    use std::collections::{BTreeMap, BTreeSet};
    use std::fmt::Display;
    use std::fs;
    use std::path::{Path, PathBuf};

    use sha2::{Digest, Sha256};

    use super::*;
    use crate::{RunnerMode, UnitKind};

    const FIXTURE_REVISION: &str = "0123456789abcdef0123456789abcdef01234567";

    fn must<T, E: Display>(result: Result<T, E>, context: &str) -> T {
        match result {
            Ok(value) => value,
            Err(error) => panic!("{context}: {error}"),
        }
    }

    fn must_fail<T, E: Display>(result: Result<T, E>, context: &str) -> String {
        match result {
            Ok(_) => panic!("{context} must fail"),
            Err(error) => error.to_string(),
        }
    }

    fn digest_of(content: &str) -> String {
        Sha256::digest(content.as_bytes()).iter().fold(
            String::with_capacity(64),
            |mut output, byte| {
                let _ = write!(output, "{byte:02x}");
                output
            },
        )
    }

    fn must_some<T>(option: Option<T>, context: &str) -> T {
        option.unwrap_or_else(|| panic!("{context}"))
    }

    fn unit() -> crate::Unit {
        crate::Unit {
            id: "rust-example".to_owned(),
            label: "rust-example".to_owned(),
            kind: UnitKind::Rust,
            root: ".".to_owned(),
            pinned_lockfile: true,
            watch: vec!["Cargo.toml".to_owned()],
            pr_commands: vec!["cargo check".to_owned()],
            full_commands: vec!["cargo check".to_owned()],
            github_pr_commands: None,
            github_full_commands: None,
            velnor_pr_commands: None,
            velnor_full_commands: None,
            depends_on: Vec::new(),
            cache: None,
            tool_version: None,
            mise_tools: Vec::new(),
            toolchain: Some(crate::RustToolchain {
                channel: "1.91.1".to_owned(),
                components: Vec::new(),
                targets: Vec::new(),
                profile: None,
            }),
            services: Vec::new(),
            requires_trusted: false,
            workspace_check: false,
            platform: crate::platform::PlatformRequirement::portable(),
            products: Vec::new(),
            prerequisites: Vec::new(),
            docker_contexts: Vec::new(),
            env: std::collections::BTreeMap::new(),
            mbx: None,
            prepared_tools: Vec::new(),
        }
    }

    fn config(workflow_files: &[&str]) -> ProjectConfig {
        crate::ProjectConfig {
            repository: String::new(),
            workflow_revision: FIXTURE_REVISION.to_owned(),
            profile: "generic".to_owned(),
            analysis: crate::AnalysisSummary {
                method: "test".to_owned(),
                detected: Vec::new(),
                limitations: Vec::new(),
            },
            verified: true,
            workflow_files: workflow_files
                .iter()
                .map(|file| (*file).to_owned())
                .collect(),
            notes: Vec::new(),
            version_bump_units: Vec::new(),
            default_branch: "main".to_owned(),
            runners: RunnerMode::Both,
            automatic: RunnerMode::Both,
            github_runner: "ubuntu-24.04".to_owned(),
            macos_runner: "macos-15".to_owned(),
            velnor_labels: vec!["self-hosted".to_owned(), "example-runner".to_owned()],
            release_enabled: false,
            release_reason: String::new(),
            release: None,
            renovate_enabled: false,
            renovate_reason: String::new(),
            renovate: None,
            docs_enabled: false,
            docs_reason: String::new(),
            docs: None,
            check_profiles: Vec::new(),
            maintenance: crate::MaintenanceSpec::default(),
            units: vec![unit()],
            workflow_templates: BTreeMap::new(),
            adopted_workflow_surface: false,
            actionlint_config_variables_null: false,
            ci_required: true,
            ruleset_required_status_checks: Vec::new(),
            ruleset_external_status_checks: Vec::new(),
            package_update_channels: None,
            velnor_runner_group: None,
            velnor_trusted_label: None,
            velnor_trusted_runner_available: None,
            pull_request_on_velnor: false,
            default_dispatch_runner: crate::DEFAULT_DISPATCH_RUNNER.to_owned(),
            automatic_lanes: crate::DEFAULT_AUTOMATIC_LANES.to_owned(),
            velnor_rust_needs: crate::VelnorRustNeeds::Parallel,
            velnor_concurrency_group: None,
            velnor_serial_stack_groups: false,
            static_files: Vec::new(),
            declared_surface: false,
            mise_lock_keys: BTreeSet::new(),
            github_cache: crate::config::CacheGithubSection::default(),
            velnor_host_cache: crate::config::CacheVelnorSection::default(),
        }
    }

    fn owner_config(workflow_files: &[&str]) -> ProjectConfig {
        let mut config = config(workflow_files);
        config.repository = workflow_setup_action_repository().to_owned();
        config
    }

    fn owner_content(workflow_files: &[&str]) -> String {
        must_some(
            runtime_products_content(&owner_config(workflow_files)),
            "the owner renders the producer",
        )
    }

    fn scanned_root(name: &str) -> PathBuf {
        let root = std::env::temp_dir().join(format!(
            "velnor-workflow-runtime-products-{name}-{}",
            crate::unique_suffix()
        ));
        must(fs::create_dir_all(&root), "create test repository");
        must(
            fs::write(
                root.join("Cargo.toml"),
                "[package]\nname = \"example\"\nversion = \"0.1.0\"\n",
            ),
            "write fixture manifest",
        );
        must(
            fs::write(
                root.join("rust-toolchain.toml"),
                "[toolchain]\nchannel = \"1.91.1\"\n",
            ),
            "write fixture toolchain pin",
        );
        root
    }

    fn try_generate(
        root: &std::path::Path,
        config: &ProjectConfig,
        rows: &str,
    ) -> Result<super::super::Surface, GeneratorError> {
        let shape = must(
            crate::scan::scan_shape(root, crate::RunnerMode::Both, "main", &[]),
            "scan fixture",
        );
        let directory = root.join(crate::config::GENERATION_CONFIG_PATH);
        must(
            fs::create_dir_all(directory.parent().unwrap_or(root)),
            "create generation config directory",
        );
        must(
            fs::write(
                &directory,
                format!("schema = 1\n\n[generator]\nrepository = \"example/declared\"\n\n{rows}"),
            ),
            "write declared config",
        );
        let generation = must(crate::config::discover(root), "discover declared config");
        super::super::generate(root, &shape, config, generation.as_ref())
    }

    /// The setup action source: the consumer contract the producer mirrors.
    fn setup_action_source() -> String {
        let path = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("../../.github-gen/sources/actions/setup-velnor-workflow/action.yml");
        must(fs::read_to_string(&path), "read the setup action source")
    }

    #[test]
    fn non_owner_repositories_render_no_producer() {
        assert!(
            runtime_products_content(&config(&[])).is_none(),
            "a repository without identity renders no producer"
        );
        let mut consumer = config(&[]);
        consumer.repository = "example/consumer".to_owned();
        assert!(
            runtime_products_content(&consumer).is_none(),
            "a consumer repository renders no producer"
        );
    }

    #[test]
    fn owner_renders_the_producer_on_default_branch_push_and_dispatch() {
        let mut config = owner_config(&[]);
        config.default_branch = "trunk".to_owned();
        let content = must_some(
            runtime_products_content(&config),
            "the owner renders the producer",
        );
        assert!(content.starts_with(GENERATED_HEADER), "{content}");
        assert!(
            content.contains("name: Velnor workflow runtime products"),
            "{content}"
        );
        assert!(
            content.contains("branches: [trunk]"),
            "push gates on the configured default branch: {content}"
        );
        assert!(content.contains("workflow_dispatch:"), "{content}");
        for event in ["pull_request", "schedule:", "tags:", "merge_group"] {
            assert!(
                !content.contains(event),
                "the producer admits no untrusted or scheduled trigger ({event}): {content}"
            );
        }
    }

    #[test]
    fn release_tags_come_from_product_tag() {
        let content = owner_content(&[]);
        assert!(
            content.contains(&format!("tag=\"{PRODUCT_TAG_PREFIX}${{closure:0:16}}\"")),
            "the shell forms tags from the shared prefix: {content}"
        );
        assert!(
            content.contains(&example_tag()),
            "the header pins the scheme to product_tag: {content}"
        );
        assert_eq!(
            example_tag(),
            format!("{PRODUCT_TAG_PREFIX}{}", "0".repeat(16)),
            "the worked example is the zero closure's product tag"
        );
    }

    #[test]
    fn closure_shell_matches_the_canonical_form() {
        let content = owner_content(&[]);
        let pathspec = CLOSURE_PATHS.join(" ");
        assert!(
            content.contains(&format!("git ls-tree -r HEAD -- {pathspec}")),
            "the closure pathspec derives from CLOSURE_PATHS: {content}"
        );
        assert!(
            content.contains(&format!(
                "closure-version:{CLOSURE_VERSION}\\nfeatures:{CI_FEATURES}\\nprofile:{PROFILE_RELEASE}\\n"
            )),
            "the closure footer derives from the canonical constants: {content}"
        );
        assert!(content.contains("LC_ALL=C sort"), "{content}");
        assert!(
            content.contains("[[ \"$closure\" =~ ^[0-9a-f]{64}$ ]]"),
            "a malformed closure fails the run: {content}"
        );
    }

    #[test]
    fn closure_shell_matches_the_setup_action() {
        let content = owner_content(&[]);
        let action = setup_action_source();
        // The commands differ (the action resolves any rev portably, the
        // producer resolves HEAD on Linux), but the hashed byte stream — the
        // pathspec, the byte sort, and the footer — must agree exactly.
        let action_ls_tree = must_some(
            action
                .lines()
                .map(str::trim)
                .find(|line| line.contains("ls-tree -r") && line.contains("-- ")),
            "the setup action resolves closures from git",
        );
        let action_pathspec = must_some(
            action_ls_tree
                .split_once("-- ")
                .map(|(_, pathspec)| pathspec),
            "the setup action pathspec",
        );
        let action_pathspec = must_some(
            action_pathspec.strip_suffix(")\""),
            "the setup action pathspec end",
        );
        assert_eq!(
            action_pathspec,
            CLOSURE_PATHS.join(" "),
            "the setup action pathspec is the closure paths"
        );
        assert!(
            content.contains(action_pathspec),
            "producer and setup action hash the same pathspec: {content}"
        );
        let footer = format!(
            "closure-version:{CLOSURE_VERSION}\\nfeatures:{CI_FEATURES}\\nprofile:{PROFILE_RELEASE}\\n"
        );
        assert!(
            action.contains(&footer),
            "the setup action hashes the canonical footer"
        );
        assert!(
            content.contains(&footer),
            "the producer hashes the canonical footer: {content}"
        );
        assert!(
            content.contains("LC_ALL=C sort") && action.contains("LC_ALL=C sort"),
            "both sort the listing in byte order"
        );
        assert!(
            content.contains("velnor-workflow-${RUNNER_OS}-${RUNNER_ARCH}")
                && action.contains("velnor-workflow-${RUNNER_OS}-${RUNNER_ARCH}"),
            "producer and consumer name assets identically"
        );
    }

    #[test]
    fn build_is_a_locked_hermetic_release() {
        let content = owner_content(&[]);
        assert!(
            content.contains(
                "run: cargo build --locked --no-default-features --release --package velnor-workflow --bin velnor-workflow"
            ),
            "the build honors the footer contract (locked, no default features, release): {content}"
        );
        for guard in [
            "git status --porcelain",
            "RUSTFLAGS",
            "CARGO_ENCODED_RUSTFLAGS",
            "RUSTC_WRAPPER",
        ] {
            assert!(
                content.contains(guard),
                "the hermetic proof covers {guard}: {content}"
            );
        }
        assert!(
            content.contains("CARGO_HOME: ${{ runner.temp }}/velnor-producer-cargo-home"),
            "the build runs under an isolated Cargo home: {content}"
        );
        assert!(
            !content.contains("sccache"),
            "no compiler cache wrapper may enter the producer build: {content}"
        );
        // The `runner` context is unavailable in job-level `env:` (GitHub
        // rejects the workflow at compile time), so the build job carries no
        // job-level `env:` and exactly the four steps that need isolation
        // carry step-level `CARGO_HOME`.
        let build = must_some(content.split("  build:\n").nth(1), "the build job");
        let build = must_some(build.split("\n  publish:\n").next(), "the build job body");
        assert!(
            !build.contains("\n    env:"),
            "the build job has no job-level env (runner is unavailable there): {build}"
        );
        assert_eq!(
            build
                .matches("          CARGO_HOME: ${{ runner.temp }}/velnor-producer-cargo-home")
                .count(),
            4,
            "exactly four step-level CARGO_HOME entries: {build}"
        );
        let steps: Vec<&str> = build.split("      - name: ").skip(1).collect();
        assert_eq!(steps.len(), 9, "the build job has nine steps: {build}");
        for step in &steps {
            let name = must_some(step.split('\n').next(), "the step name");
            let has_cargo_home = step.contains(PRODUCER_CARGO_HOME_VALUE);
            let needs_isolation = [
                "Provision Rust toolchain",
                "Prove a hermetic build environment",
                "Build release runtime",
                "Prove the product closure",
            ]
            .contains(&name);
            assert_eq!(
                has_cargo_home, needs_isolation,
                "step `{name}` carries step-level CARGO_HOME iff it needs isolation: {step}"
            );
        }
    }

    #[test]
    fn binary_closure_is_proven_before_upload() {
        let content = owner_content(&[]);
        let prove = must_some(
            content.find("Prove the product closure"),
            "the prove step exists",
        );
        let attest = must_some(
            content.find("Attest runtime asset"),
            "the attest step exists",
        );
        let upload = must_some(
            content.find("Upload runtime asset"),
            "the upload step exists",
        );
        assert!(
            prove < attest && attest < upload,
            "prove precedes attest precedes upload: {content}"
        );
        assert!(
            content.contains("CLOSURE: ${{ needs.closure.outputs.closure }}"),
            "the proof compares against the tag closure: {content}"
        );
        assert!(
            content.contains(
                "[[ \"$reported\" == \"$CLOSURE\" ]] || { echo \"::error::built binary reports closure"
            ),
            "a binary that misreports its closure fails the build: {content}"
        );
        assert!(
            content.contains("reported_revision=\"$(\"$binary\" --revision)\""),
            "the build probes the binary's revision stamp: {content}"
        );
        assert!(
            content.contains(
                "[[ \"$reported_revision\" == \"$head\" ]] || { echo \"::error::built binary reports revision"
            ),
            "a binary that misreports its build commit fails the build: {content}"
        );
    }

    #[test]
    fn manifest_shape_matches_the_consumer_contract() {
        let content = owner_content(&[]);
        let action = setup_action_source();
        assert!(
            action.contains(MANIFEST_ACCEPT_FILTER),
            "the acceptance filter is the setup action's own"
        );
        assert_eq!(
            content.matches(MANIFEST_ACCEPT_FILTER).count(),
            2,
            "assemble and smoke-test evaluate the consumer filter: {content}"
        );
        assert!(
            MANIFEST_ACCEPT_FILTER.contains("(.revision | test(\"^[0-9a-f]{40}$\"))"),
            "the consumer filter requires a well-formed source revision"
        );
        assert!(
            content.contains("--arg revision \"$HEAD_SHA\""),
            "the manifest names the commit the producer built from: {content}"
        );
        assert!(
            content.contains("revision: $revision"),
            "the manifest program carries the revision field: {content}"
        );
        assert!(
            content.contains("manifest_revision=\"$(jq -er '.revision' dist/manifest.json)\""),
            "the assembled manifest revision is read back: {content}"
        );
        assert!(
            content.contains(
                "[[ \"$manifest_revision\" == \"$HEAD_SHA\" ]] || { echo \"::error::assembled manifest names revision"
            ),
            "a manifest that names the wrong build commit fails the publish: {content}"
        );
        assert!(
            content.contains(
                "[[ \"$reported_revision\" == \"$HEAD_SHA\" ]] || { echo \"::error::published binary reports revision"
            ),
            "the publish spot check binds the binary stamp to the build commit: {content}"
        );
        // The revision checks above read `$HEAD_SHA` under `set -u`: the
        // assemble step must receive the build commit in its own `env:`, or
        // the step dies on an unbound variable before assembling anything.
        let assemble = must_some(
            content.split("Assemble and verify the release").nth(1),
            "the assemble step",
        );
        let assemble = must_some(
            assemble.split("- name: Attest release manifest").next(),
            "the assemble step body",
        );
        assert!(
            assemble.contains("HEAD_SHA: ${{ needs.closure.outputs.head-sha }}"),
            "the assemble step receives the build commit it proves: {assemble}"
        );
        for platform in ["Linux-X64", "Linux-ARM64", "macOS-ARM64"] {
            assert!(
                content.contains(&format!(
                    "\"{platform}\": {{binary: ${}, asset: \"velnor-workflow-{platform}\"}}",
                    platform.to_ascii_lowercase().replace('-', "_")
                )),
                "the manifest binds {platform} digest and asset: {content}"
            );
        }
        assert!(
            content.contains("profile: \"release\", features: \"\""),
            "the manifest footer matches the build: {content}"
        );
        // The Velnor policy provisioner is the second consumer: it must accept
        // the same manifest and the same attestation the setup action does.
        let velnor = crate::workflow_pinned_policy_runtime_velnor("checkout");
        assert!(
            velnor.contains(MANIFEST_ACCEPT_FILTER),
            "the Velnor consumer evaluates the same filter"
        );
        let repository = workflow_setup_action_repository();
        assert!(
            velnor.contains(&format!(
                "--signer-workflow {repository}/.github/workflows/{RUNTIME_PRODUCTS_FILE}"
            )),
            "the Velnor consumer pins the same producer workflow"
        );
        assert!(
            velnor.contains("gh attestation verify \"$temporary/manifest.json\""),
            "the Velnor consumer verifies the manifest it trusts"
        );
        assert!(
            velnor.contains("\"$existing\" != \"$expected\""),
            "the Velnor consumer reuses its slot only on a manifest digest match"
        );
        assert!(
            velnor.contains("reported_revision=\"$(\"$binary\" --revision)\""),
            "the Velnor consumer probes the slot binary's revision stamp"
        );
        assert!(
            velnor.contains("[[ \"$reported_revision\" == \"$manifest_revision\" ]]"),
            "the Velnor consumer binds the stamp to the manifest revision"
        );
    }

    #[test]
    fn attestation_covers_assets_and_manifest_in_the_pinned_workflow() {
        let content = owner_content(&[]);
        let repository = workflow_setup_action_repository();
        assert_eq!(
            content.matches(ActionPin::Attest.reference()).count(),
            2,
            "the pinned attest action covers the asset and the manifest: {content}"
        );
        assert!(
            content.contains("subject-path: ${{ steps.prove.outputs.asset }}"),
            "the per-platform asset is attested where it is built: {content}"
        );
        assert!(
            content.contains("subject-path: dist/manifest.json"),
            "the manifest is attested where it assembles: {content}"
        );
        let signer =
            format!("--signer-workflow {repository}/.github/workflows/{RUNTIME_PRODUCTS_FILE}");
        let owner_flag = format!("--owner {}", product_owner(repository));
        // `--signer-ref` does not exist in gh: `--source-ref` is the flag
        // that pins the producer run to the default branch.
        let source_ref = "--source-ref refs/heads/main";
        for flag in [signer.as_str(), owner_flag.as_str(), source_ref] {
            assert!(
                content.contains(flag),
                "the smoke test verifies {flag}: {content}"
            );
        }
        let action = setup_action_source();
        for flag in [signer.as_str(), owner_flag.as_str(), source_ref] {
            assert!(
                action.contains(flag),
                "the setup action verifies the same {flag}"
            );
        }
        // Subject-level: both consumers verify the manifest as well as the
        // asset, against the same pinned producer workflow.
        let velnor = crate::workflow_pinned_policy_runtime_velnor("checkout");
        for (name, consumer) in [
            ("setup action", action.as_str()),
            ("velnor", velnor.as_str()),
        ] {
            for subject in [
                "gh attestation verify \"$temporary/$asset\"",
                "gh attestation verify \"$temporary/manifest.json\"",
            ] {
                assert!(
                    consumer.contains(subject),
                    "the {name} consumer verifies {subject}"
                );
            }
        }
    }

    #[test]
    fn all_consumers_pin_the_same_producer_ref() {
        // The setup action, the Velnor provisioner, and the producer smoke
        // test verify the same two subjects under the same ref pin: an
        // attestation minted anywhere but the default branch verifies
        // nowhere.
        let action = setup_action_source();
        assert_eq!(
            action.matches("--source-ref refs/heads/main").count(),
            2,
            "the setup action pins the ref on the asset and the manifest"
        );
        let velnor = crate::workflow_pinned_policy_runtime_velnor("checkout");
        assert_eq!(
            velnor.matches("--source-ref refs/heads/main").count(),
            2,
            "the Velnor provisioner pins the ref on the asset and the manifest"
        );
        let content = owner_content(&[]);
        assert_eq!(
            content.matches("--source-ref refs/heads/main").count(),
            2,
            "the producer smoke test pins the ref on the asset and the manifest: {content}"
        );
    }

    #[test]
    fn producer_builders_are_fixed_closure_covered_infrastructure() {
        // Hostile lane labels must not move the builders: the matrix is the
        // fixed product-infrastructure mapping, so a label change can never
        // reuse a stale tag's binaries, and a mapping change is a generator
        // source change that mints a new closure and a new tag.
        let mut config = owner_config(&[]);
        config.github_runner = "self-hosted-spoof-x64".to_owned();
        config.macos_runner = "self-hosted-spoof-macos".to_owned();
        let content = must_some(
            runtime_products_content(&config),
            "the owner renders the producer",
        );
        let matrix = must_some(
            content
                .split("      matrix:\n        include:\n")
                .nth(1)
                .and_then(|tail| tail.split("\n    runs-on: ${{ matrix.runner }}").next()),
            "the build matrix renders",
        );
        for (os, arch, runner) in [
            ("Linux", "X64", LINUX_X64_RUNNER),
            ("Linux", "ARM64", LINUX_ARM64_RUNNER),
            ("macOS", "ARM64", MACOS_ARM64_RUNNER),
        ] {
            assert!(
                matrix.contains(&format!(
                    "- os: {os}\n            arch: {arch}\n            runner: {runner}"
                )),
                "the matrix builds {os}-{arch} on the fixed {runner}: {matrix}"
            );
        }
        for spoof in ["self-hosted-spoof-x64", "self-hosted-spoof-macos"] {
            assert!(
                !matrix.contains(spoof),
                "lane labels never reselect the builders ({spoof}): {matrix}"
            );
        }
        assert!(
            !content.contains("macOS-X64"),
            "no lane selects an Intel Mac, so no macOS X64 product is built: {content}"
        );
        assert!(
            content.contains("runs-on: ${{ matrix.runner }}"),
            "one job per platform: {content}"
        );
        // The mapping must live under a closure path: only then does a
        // builder change alter the digest and mint a new tag.
        let manifest_dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        let mapping_file = manifest_dir.join("src/primitives/runtime_products.rs");
        let mapping_source = must(
            fs::read_to_string(&mapping_file),
            "read the producer renderer",
        );
        for runner in [LINUX_X64_RUNNER, LINUX_ARM64_RUNNER, MACOS_ARM64_RUNNER] {
            assert!(
                mapping_source.contains(&format!("\"{runner}\"")),
                "the fixed mapping lives in the producer renderer: {runner}"
            );
        }
        let root = must(
            std::process::Command::new("git")
                .arg("-C")
                .arg(&manifest_dir)
                .args(["rev-parse", "--show-toplevel"])
                .output(),
            "git present",
        );
        assert!(root.status.success());
        let root = must(
            PathBuf::from(String::from_utf8_lossy(&root.stdout).trim().to_owned())
                .canonicalize()
                .map_err(|error| format!("canonicalize repository root: {error}")),
            "canonicalize the repository root",
        );
        let relative = must(
            mapping_file
                .canonicalize()
                .map_err(|error| format!("canonicalize renderer: {error}"))
                .and_then(|absolute| {
                    absolute
                        .strip_prefix(&root)
                        .map(Path::to_path_buf)
                        .map_err(|_| "the renderer is outside the repository".to_owned())
                }),
            "locate the renderer under the repository root",
        );
        assert!(
            CLOSURE_PATHS
                .iter()
                .any(|covered| { relative == Path::new(covered) || relative.starts_with(covered) }),
            "the builder mapping is closure-covered ({}): {relative:?}",
            CLOSURE_PATHS.join(", ")
        );
    }

    #[test]
    fn existing_tags_skip_and_never_overwrite() {
        let content = owner_content(&[]);
        assert!(
            content.contains("exists: ${{ steps.exists.outputs.exists }}"),
            "the closure job reports tag existence: {content}"
        );
        assert_eq!(
            content
                .matches("if: needs.closure.outputs.exists != 'true'")
                .count(),
            2,
            "build and publish skip when the tag exists: {content}"
        );
        assert!(
            content.contains("release $TAG already exists; leaving it untouched"),
            "the publish job re-checks before creating: {content}"
        );
        for overwrite in ["--clobber", "--overwrite", "release delete", "release edit"] {
            assert!(
                !content.contains(overwrite),
                "the producer never overwrites ({overwrite}): {content}"
            );
        }
    }

    #[test]
    fn actions_are_sha_pinned_with_least_privilege() {
        let content = owner_content(&[]);
        let mut pinned = 0;
        for line in content.lines().filter(|line| line.contains("uses:")) {
            let reference = must_some(line.split("uses:").nth(1), "the uses reference").trim();
            let sha = must_some(reference.split('@').nth(1), "the action pin");
            let sha = must_some(sha.split_whitespace().next(), "the bare pin");
            assert_eq!(sha.len(), 40, "SHA-pinned actions only: {line}");
            assert!(
                sha.bytes().all(|byte| byte.is_ascii_hexdigit()),
                "SHA-pinned actions only: {line}"
            );
            pinned += 1;
        }
        assert_eq!(
            pinned, 9,
            "every step the producer needs, pinned: {content}"
        );
        assert!(
            content.contains("permissions:\n  contents: read\n"),
            "the workflow defaults to read-only: {content}"
        );
        let build = must_some(content.split("  build:\n").nth(1), "the build job");
        let build = must_some(build.split("\n  publish:\n").next(), "the build job body");
        assert!(build.contains("id-token: write"), "{build}");
        assert!(build.contains("attestations: write"), "{build}");
        assert!(!build.contains("contents: write"), "{build}");
        let publish = must_some(content.split("\n  publish:\n").nth(1), "the publish job");
        assert!(publish.contains("contents: write"), "{publish}");
        assert!(publish.contains("id-token: write"), "{publish}");
        assert!(publish.contains("attestations: write"), "{publish}");
    }

    #[test]
    fn registry_resolves_the_producer() {
        assert!(is_runtime_products_side(super::super::RUNTIME_PRODUCTS));
        assert!(!is_runtime_products_side(super::super::RELEASE));
        assert_eq!(
            canonical_runtime_products_side_file(super::super::RUNTIME_PRODUCTS),
            Some(RUNTIME_PRODUCTS_FILE)
        );
        let registry = super::super::registry();
        let producer = must_some(
            registry
                .iter()
                .find(|primitive| primitive.id() == super::super::RUNTIME_PRODUCTS),
            "the producer is registered",
        );
        assert!(
            producer.schema().is_empty(),
            "the producer takes no arguments"
        );
    }

    #[test]
    fn declared_row_renders_for_the_owner_and_fails_closed_elsewhere() {
        let rows = format!(
            "[[declare]]\nprimitive = \"{}\"\nfile = \"{RUNTIME_PRODUCTS_FILE}\"\n",
            super::super::RUNTIME_PRODUCTS
        );
        let root = scanned_root("declared-owner");
        let surface = must(
            try_generate(&root, &owner_config(&["maintenance.yml"]), &rows),
            "the owner declares the producer",
        );
        let path = PathBuf::from(".github/workflows").join(RUNTIME_PRODUCTS_FILE);
        assert_eq!(
            surface.files.get(&path).map(String::as_str),
            runtime_products_content(&owner_config(&["maintenance.yml"])).as_deref(),
            "declared and legacy paths render identical bytes"
        );
        assert!(
            surface
                .added_files
                .contains(&RUNTIME_PRODUCTS_FILE.to_owned()),
            "declaring the producer owns its file: {:?}",
            surface.added_files
        );
        let _ = fs::remove_dir_all(&root);

        let root = scanned_root("declared-consumer");
        let error = must_fail(
            try_generate(&root, &config(&["maintenance.yml"]), &rows),
            "a consumer must not declare the producer",
        );
        assert!(error.contains("only for the repository"), "{error}");
        let _ = fs::remove_dir_all(&root);

        let root = scanned_root("declared-wrong-file");
        let rows = format!(
            "[[declare]]\nprimitive = \"{}\"\nfile = \"other.yml\"\n",
            super::super::RUNTIME_PRODUCTS
        );
        let error = must_fail(
            try_generate(&root, &owner_config(&["maintenance.yml"]), &rows),
            "a wrong file must fail closed",
        );
        assert!(
            error.contains(RUNTIME_PRODUCTS_FILE),
            "the error names the canonical file: {error}"
        );
        let _ = fs::remove_dir_all(&root);
    }

    #[test]
    fn owner_auto_add_through_generated_files() {
        let files = must(
            crate::generated_files(&owner_config(&[])),
            "generate the owner surface",
        );
        let path = PathBuf::from(".github/workflows").join(RUNTIME_PRODUCTS_FILE);
        assert!(
            files.contains_key(&path),
            "the owner owns the producer without declaring it: {:?}",
            files.keys().collect::<Vec<_>>()
        );
        let project = must_some(
            files.get(&PathBuf::from(".github/ci/project.toml")),
            "the project contract",
        );
        assert!(
            project.contains(RUNTIME_PRODUCTS_FILE),
            "the owned surface records the producer: {project}"
        );
        let files = must(
            crate::generated_files(&config(&[])),
            "generate the consumer surface",
        );
        assert!(
            !files.contains_key(&path),
            "a consumer surface carries no producer"
        );
        let mut adopted = owner_config(&[]);
        adopted.adopted_workflow_surface = true;
        let files = must(
            crate::generated_files(&adopted),
            "generate the adopted surface",
        );
        assert!(
            !files.contains_key(&path),
            "an adopted surface owns its files as reviewed templates"
        );
    }

    #[test]
    fn toolchain_fallback_stays_file_driven() {
        let mut config = owner_config(&[]);
        config.units[0].toolchain = None;
        let content = must_some(
            runtime_products_content(&config),
            "the owner renders without a scanned toolchain",
        );
        assert!(
            content.contains("rustup toolchain install"),
            "the install stays file-driven: {content}"
        );
        assert!(
            !content.contains("--profile"),
            "no profile is invented: {content}"
        );
    }

    #[test]
    fn smoke_test_installs_the_consumer_layout() {
        let content = owner_content(&[]);
        assert!(
            content.contains(&format!(
                "runtime=\"{HOSTED_WORKFLOW_RUNTIME_HOME}/$CLOSURE\""
            )),
            "the smoke test installs the setup action's layout: {content}"
        );
        assert!(
            content.contains("\"$runtime/bin/velnor-workflow\" --closure"),
            "the smoke test self-reports from the install layout: {content}"
        );
        assert!(
            content.contains("manifest_revision=\"$(jq -er '.revision' \"dist/manifest.json\")\""),
            "the smoke test reads the revision from the local manifest: {content}"
        );
        assert!(
            content.contains("\"$runtime/bin/velnor-workflow\" --revision"),
            "the smoke test probes the installed revision stamp: {content}"
        );
        assert!(
            content.contains(
                "[[ \"$reported_revision\" == \"$manifest_revision\" ]] || { echo \"::error::installed runtime reports revision"
            ),
            "the smoke test binds the installed stamp to the manifest: {content}"
        );
    }

    #[test]
    fn producer_runs_only_on_the_default_branch() {
        let content = owner_content(&[]);
        let closure = must_some(content.split("  closure:\n").nth(1), "the closure job");
        let closure = must_some(closure.split("\n  build:\n").next(), "the closure job body");
        // The guard is the first step: a dispatch from anywhere else fails
        // before the checkout, the closure resolution, or any build.
        let first = must_some(
            closure.split("      - name: ").nth(1),
            "the first closure step",
        );
        let name = must_some(first.split('\n').next(), "the first step name");
        assert_eq!(name, "Prove the default-branch ref", "{closure}");
        assert!(
            first.contains("REF: ${{ github.ref }}"),
            "the guard reads the run ref: {first}"
        );
        assert!(
            first.contains("[[ \"$REF\" == \"refs/heads/main\" ]]"),
            "the guard compares against the default-branch ref: {first}"
        );
        assert!(
            first.contains("the producer publishes only from refs/heads/main"),
            "the failure names the expected ref: {first}"
        );
        let mut config = owner_config(&[]);
        config.default_branch = "trunk".to_owned();
        let content = must_some(
            runtime_products_content(&config),
            "the owner renders the producer",
        );
        assert!(
            content.contains("[[ \"$REF\" == \"refs/heads/trunk\" ]]"),
            "the guard follows the configured default branch: {content}"
        );
        assert!(
            content.contains("the producer publishes only from refs/heads/trunk"),
            "the failure names the configured ref: {content}"
        );
    }

    #[test]
    fn publish_verifies_before_creating_the_release() {
        let content = owner_content(&[]);
        let publish = must_some(content.split("\n  publish:\n").nth(1), "the publish job");
        let assemble = must_some(
            publish.find("Assemble and verify the release"),
            "the assemble step",
        );
        let attest = must_some(
            publish.find("Attest release manifest"),
            "the manifest attestation step",
        );
        let smoke = must_some(
            publish.find("Smoke-test the release"),
            "the smoke-test step",
        );
        let create = must_some(publish.find("gh release create"), "the release creation");
        assert!(
            assemble < attest && attest < smoke && smoke < create,
            "assemble precedes manifest attestation precedes the smoke test precedes release creation: {publish}"
        );
        assert_eq!(
            publish.matches("gh release create").count(),
            1,
            "exactly one creation, after every verification: {publish}"
        );
        assert!(
            !publish.contains("gh release download"),
            "the smoke test proves the local bytes; nothing is downloaded from an exposed release: {publish}"
        );
        assert!(
            !content.contains("skipped"),
            "no skipped output remains: verification gates the create directly: {content}"
        );
        let recheck = must_some(
            publish.find("already exists; leaving it untouched"),
            "the pre-create re-check",
        );
        assert!(
            recheck < create,
            "the re-check fires immediately before creating: {publish}"
        );
    }

    #[test]
    fn smoke_test_pins_the_producer_ref() {
        let content = owner_content(&[]);
        assert_eq!(
            content.matches("--source-ref refs/heads/main").count(),
            2,
            "the smoke test pins the default-branch ref on the asset and the manifest: {content}"
        );
        let mut config = owner_config(&[]);
        config.default_branch = "trunk".to_owned();
        let content = must_some(
            runtime_products_content(&config),
            "the owner renders the producer",
        );
        assert_eq!(
            content.matches("--source-ref refs/heads/trunk").count(),
            2,
            "the smoke-test pin follows the configured default branch: {content}"
        );
    }

    #[test]
    fn create_carries_no_target() {
        // cli/cli#9514: an explicit --target makes the API diff
        // target..HEAD, and a range carrying workflow files demands the
        // workflows scope GITHUB_TOKEN can never hold → 403. The tag names
        // the closure, never the commit, so the create passes no target and
        // the API tags the default-branch tip when the tag is missing.
        let content = owner_content(&[]);
        for usage in ["--target ", "--target="] {
            assert!(
                !content.contains(usage),
                "no target flag usage ({usage:?}): {content}"
            );
        }
        let publish = must_some(content.split("\n  publish:\n").nth(1), "the publish job");
        assert_eq!(
            publish.matches("gh release create").count(),
            1,
            "exactly one creation: {publish}"
        );
        assert!(
            publish.contains("gh release create \"$TAG\" --repo"),
            "the create names the tag and the repository: {publish}"
        );
    }

    #[test]
    fn conflicting_create_converges_instead_of_failing() {
        let content = owner_content(&[]);
        let publish = must_some(content.split("\n  publish:\n").nth(1), "the publish job");
        let create = must_some(publish.find("gh release create"), "the release creation");
        let tail = &publish[create..];
        for marker in [
            "converged=false",
            "for delay in 5 10 15 30; do",
            "appeared after a conflicting create; converging",
            "was not created and did not appear",
        ] {
            assert!(
                tail.contains(marker),
                "the converge loop carries {marker:?}: {tail}"
            );
        }
        assert_eq!(
            tail.matches("gh release view").count(),
            1,
            "the loop re-views the same tag the create attempted: {tail}"
        );
    }

    #[test]
    fn publish_serializes_on_the_tag_across_refs() {
        let content = owner_content(&[]);
        let publish = must_some(content.split("\n  publish:\n").nth(1), "the publish job");
        assert!(
            publish.contains("group: runtime-products-tag-${{ needs.closure.outputs.tag }}"),
            "publishes serialize on the closure tag, whatever ref named it: {publish}"
        );
        assert!(
            publish.contains("cancel-in-progress: false"),
            "a publish in flight is never cancelled: {publish}"
        );
        assert!(
            content.contains("group: runtime-products-${{ github.ref }}"),
            "the same-ref run gate stays: {content}"
        );
    }

    #[test]
    fn publish_yields_to_a_fresher_same_closure_run() {
        let content = owner_content(&[]);
        let publish = must_some(content.split("\n  publish:\n").nth(1), "the publish job");
        let checkout = must_some(
            publish.find("Checkout default-branch tip"),
            "the tip checkout",
        );
        let freshness = must_some(
            publish.find("Prove publish freshness"),
            "the freshness proof",
        );
        let download = must_some(
            publish.find("Download runtime assets"),
            "the asset download",
        );
        assert!(
            checkout < freshness && freshness < download,
            "the tip checkout and freshness proof gate the publish work: {publish}"
        );
        assert!(
            publish.contains("ref: main"),
            "the checkout reads the default-branch tip: {publish}"
        );
        let pathspec = CLOSURE_PATHS.join(" ");
        assert!(
            publish.contains(&format!("git ls-tree -r HEAD -- {pathspec}")),
            "the freshness proof re-resolves the canonical closure: {publish}"
        );
        let footer = format!(
            "closure-version:{CLOSURE_VERSION}\\nfeatures:{CI_FEATURES}\\nprofile:{PROFILE_RELEASE}\\n"
        );
        assert!(
            publish.contains(&footer),
            "the freshness proof hashes the canonical footer: {publish}"
        );
        assert!(
            publish.contains("the fresher run owns $TAG"),
            "a stale same-closure run yields its tag: {publish}"
        );
        let mut config = owner_config(&[]);
        config.default_branch = "trunk".to_owned();
        let content = must_some(
            runtime_products_content(&config),
            "the owner renders the producer",
        );
        let publish = must_some(content.split("\n  publish:\n").nth(1), "the publish job");
        assert!(
            publish.contains("ref: trunk"),
            "the tip checkout follows the configured default branch: {publish}"
        );
    }

    #[test]
    fn workflow_is_the_sole_tag_writer() {
        let content = owner_content(&[]);
        assert_eq!(
            content.matches("gh release create").count(),
            1,
            "one creation is the only tag path: {content}"
        );
        assert!(
            !content.contains("git push"),
            "no explicit tag push beside the create: {content}"
        );
    }

    /// Every `run: |` shell body in the rendered producer, keyed by step
    /// name and de-indented. The template is string-built, so these bodies
    /// are what actually executes in CI: parsing and running them here
    /// catches template escaping bugs that string assertions cannot see.
    fn step_bodies(content: &str) -> Vec<(String, String)> {
        let mut bodies = Vec::new();
        let mut name = String::new();
        let mut current: Option<Vec<String>> = None;
        for line in content.lines() {
            if let Some(body) = current.as_mut() {
                if line.trim().is_empty() || line.starts_with("          ") {
                    body.push(line.strip_prefix("          ").unwrap_or("").to_owned());
                    continue;
                }
                bodies.push((std::mem::take(&mut name), body.join("\n")));
                current = None;
            }
            if let Some(step) = line.strip_prefix("      - name: ") {
                name = step.to_owned();
            } else if line.trim() == "run: |" {
                current = Some(Vec::new());
            }
        }
        if let Some(body) = current {
            bodies.push((name, body.join("\n")));
        }
        bodies
    }

    #[cfg(unix)]
    #[test]
    fn rendered_shell_parses() {
        let content = owner_content(&[]);
        let bodies = step_bodies(&content);
        for owned in [
            "Prove the default-branch ref",
            "Resolve source closure",
            "Check for an existing product",
            "Prove a hermetic build environment",
            "Prove the product closure",
            "Prove publish freshness",
            "Assemble and verify the release",
            "Smoke-test the release",
            "Create the release",
        ] {
            assert!(
                bodies
                    .iter()
                    .any(|(name, body)| name == owned && !body.is_empty()),
                "the `{owned}` shell body is extracted for parsing"
            );
        }
        for (index, (name, body)) in bodies.iter().enumerate() {
            let path = std::env::temp_dir().join(format!(
                "velnor-workflow-producer-shell-{index}-{}",
                crate::unique_suffix()
            ));
            must(fs::write(&path, body), "write the shell body");
            let output = must(
                std::process::Command::new("bash")
                    .arg("-n")
                    .arg(&path)
                    .output(),
                "parse the shell body",
            );
            let _ = fs::remove_file(&path);
            assert!(
                output.status.success(),
                "the `{name}` shell body parses: {body}\n{}",
                String::from_utf8_lossy(&output.stderr)
            );
        }
    }

    #[cfg(unix)]
    #[test]
    fn default_branch_guard_accepts_only_the_default_ref() {
        let content = owner_content(&[]);
        let bodies = step_bodies(&content);
        let guard = must_some(
            bodies
                .iter()
                .find_map(|(name, body)| (name == "Prove the default-branch ref").then_some(body)),
            "the rendered guard body",
        );
        for (reference, accepted) in [
            ("refs/heads/main", true),
            ("refs/heads/trunk", false),
            ("refs/tags/v1.2.3", false),
            ("", false),
        ] {
            let path = std::env::temp_dir().join(format!(
                "velnor-workflow-producer-guard-{}",
                crate::unique_suffix()
            ));
            must(fs::write(&path, guard), "write the guard body");
            let output = must(
                std::process::Command::new("bash")
                    .arg(&path)
                    .env("REF", reference)
                    .output(),
                "run the guard body",
            );
            let _ = fs::remove_file(&path);
            assert_eq!(
                output.status.success(),
                accepted,
                "ref `{reference}` is {}: {}",
                if accepted { "accepted" } else { "rejected" },
                String::from_utf8_lossy(&output.stderr)
            );
        }
    }

    /// Run a rendered shell body under `bash` with `cwd` as its working
    /// directory, `envs` exported, and `path_prefix` first on `PATH` when
    /// the body needs stubbed tools.
    #[cfg(unix)]
    fn run_shell_body(
        script: &std::path::Path,
        cwd: &std::path::Path,
        path_prefix: Option<&std::path::Path>,
        envs: &[(&str, &str)],
    ) -> std::process::Output {
        let mut command = std::process::Command::new("bash");
        command.arg(script).current_dir(cwd);
        for (key, value) in envs {
            command.env(key, value);
        }
        if let Some(prefix) = path_prefix {
            let mut path = prefix.as_os_str().to_owned();
            path.push(":");
            path.push(std::env::var_os("PATH").unwrap_or_default());
            command.env("PATH", path);
        }
        must(command.output(), "run the shell body")
    }

    #[cfg(unix)]
    fn make_executable(path: &std::path::Path) {
        use std::os::unix::fs::PermissionsExt as _;
        let mut permissions = must(fs::metadata(path), "stat the stub").permissions();
        permissions.set_mode(0o755);
        must(
            fs::set_permissions(path, permissions),
            "make the stub executable",
        );
    }

    /// A scratch git repository carrying every closure input path, committed
    /// once. The freshness proof under test runs with this as its cwd.
    #[cfg(unix)]
    fn closure_repo(name: &str) -> PathBuf {
        let root = std::env::temp_dir().join(format!(
            "velnor-workflow-publish-freshness-{name}-{}",
            crate::unique_suffix()
        ));
        must(
            fs::create_dir_all(root.join("crates/velnor-workflow")),
            "create the fixture crate",
        );
        must(
            fs::create_dir_all(root.join(".cargo")),
            "create the fixture cargo dir",
        );
        for file in [
            "crates/velnor-workflow/lib.rs",
            "Cargo.toml",
            "Cargo.lock",
            "rust-toolchain.toml",
            "rust-toolchain",
            ".cargo/config.toml",
        ] {
            must(
                fs::write(root.join(file), "fixture\n"),
                "write a fixture input",
            );
        }
        let git = |args: &[&str]| {
            let status = must(
                std::process::Command::new("git")
                    .args(args)
                    .current_dir(&root)
                    .status(),
                "run git",
            );
            assert!(status.success(), "git {args:?} succeeds");
        };
        git(&["init", "-q", "-b", "main"]);
        git(&["add", "-A"]);
        git(&[
            "-c",
            "user.email=velnor@example.test",
            "-c",
            "user.name=velnor",
            "commit",
            "-qm",
            "fixture",
        ]);
        root
    }

    /// A `PATH` prefix carrying `sha256sum` when the test host ships only
    /// `shasum`: both print the `<digest>  <file>` shape the proof parses,
    /// so the oracle stays the digest algorithm, not the tool name.
    #[cfg(unix)]
    fn sha256sum_prefix() -> Option<PathBuf> {
        let present = std::process::Command::new("sha256sum")
            .arg("--version")
            .output()
            .is_ok_and(|output| output.status.success());
        if present {
            return None;
        }
        let dir = std::env::temp_dir().join(format!(
            "velnor-workflow-sha256sum-{}",
            crate::unique_suffix()
        ));
        must(fs::create_dir_all(&dir), "create the shim dir");
        let shim = dir.join("sha256sum");
        must(
            fs::write(&shim, "#!/bin/sh\nexec shasum -a 256 \"$@\"\n"),
            "write the sha256sum shim",
        );
        make_executable(&shim);
        Some(dir)
    }

    #[cfg(unix)]
    #[test]
    fn freshness_proof_yields_only_on_unchanged_closure() {
        let content = owner_content(&[]);
        let bodies = step_bodies(&content);
        let proof = must_some(
            bodies
                .iter()
                .find_map(|(name, body)| (name == "Prove publish freshness").then_some(body)),
            "the rendered freshness body",
        );
        let script = std::env::temp_dir().join(format!(
            "velnor-workflow-freshness-proof-{}",
            crate::unique_suffix()
        ));
        must(fs::write(&script, proof), "write the proof body");
        let repo = closure_repo("tip");
        let tip = must(
            std::process::Command::new("git")
                .arg("-C")
                .arg(&repo)
                .args(["rev-parse", "HEAD"])
                .output(),
            "read the fixture tip",
        );
        assert!(tip.status.success(), "rev-parse succeeds");
        let tip = String::from_utf8_lossy(&tip.stdout).trim().to_owned();
        // The oracle is the generator's own canonical digest over the same
        // tree: Rust-side computation against rendered-shell computation.
        let closure = must(
            crate::closure::closure_of_tree(&repo, "HEAD", CI_FEATURES, PROFILE_RELEASE),
            "resolve the fixture closure",
        );
        assert_eq!(closure.len(), 64, "the oracle resolves a full closure");
        let prefix = sha256sum_prefix();
        let stale = "0".repeat(40);
        let zeroes = "0".repeat(64);
        let changed = "f".repeat(64);

        // At the tip the proof passes silently, whatever the closure claims.
        let output = run_shell_body(
            &script,
            &repo,
            prefix.as_deref(),
            &[
                ("CLOSURE", zeroes.as_str()),
                ("HEAD_SHA", tip.as_str()),
                ("TAG", "tag"),
            ],
        );
        assert!(
            output.status.success(),
            "the tip run proceeds: {}",
            String::from_utf8_lossy(&output.stderr)
        );
        assert!(
            output.stdout.is_empty(),
            "the tip run stays silent: {}",
            String::from_utf8_lossy(&output.stdout)
        );

        // Past the tip with an unchanged closure the proof yields the tag.
        let output = run_shell_body(
            &script,
            &repo,
            prefix.as_deref(),
            &[
                ("CLOSURE", closure.as_str()),
                ("HEAD_SHA", stale.as_str()),
                ("TAG", "tag"),
            ],
        );
        assert!(
            output.status.success(),
            "the stale run yields: {}",
            String::from_utf8_lossy(&output.stderr)
        );
        assert!(
            String::from_utf8_lossy(&output.stdout).contains("the fresher run owns"),
            "the stale run names the yield: {}",
            String::from_utf8_lossy(&output.stdout)
        );

        // Past the tip with a changed closure the proof falls through: the
        // tag is this run's own, so the publish proceeds.
        let output = run_shell_body(
            &script,
            &repo,
            prefix.as_deref(),
            &[
                ("CLOSURE", changed.as_str()),
                ("HEAD_SHA", stale.as_str()),
                ("TAG", "tag"),
            ],
        );
        assert!(
            output.status.success(),
            "the diverged run proceeds: {}",
            String::from_utf8_lossy(&output.stderr)
        );
        assert!(
            output.stdout.is_empty(),
            "the diverged run stays silent: {}",
            String::from_utf8_lossy(&output.stdout)
        );

        let _ = fs::remove_file(&script);
        let _ = fs::remove_dir_all(&repo);
        if let Some(prefix) = prefix {
            let _ = fs::remove_dir_all(&prefix);
        }
    }

    /// A stub toolbelt for the create body: a stateful `gh` plus a `sleep`
    /// that records its delays instead of waiting. `STUB_STATE` carries the
    /// per-scenario directory; `VIEW_SUCCEED_FROM` names the view call that
    /// first succeeds; `GH_CREATE_OK` decides the create.
    #[cfg(unix)]
    fn stub_toolbelt(name: &str) -> PathBuf {
        let bin = std::env::temp_dir().join(format!(
            "velnor-workflow-create-stubs-{name}-{}",
            crate::unique_suffix()
        ));
        must(fs::create_dir_all(&bin), "create the stub dir");
        must(
            fs::write(
                bin.join("gh"),
                r#"#!/bin/bash
state="${STUB_STATE:?}"
if [[ "$1" == "release" && "$2" == "view" ]]; then
  count=0
  [[ -f "$state/views" ]] && count="$(cat "$state/views")"
  count=$((count + 1))
  printf '%s' "$count" > "$state/views"
  (( count >= ${VIEW_SUCCEED_FROM:?} )) && exit 0 || exit 1
fi
if [[ "$1" == "release" && "$2" == "create" ]]; then
  [[ "${GH_CREATE_OK:-false}" == "true" ]] && exit 0 || exit 1
fi
echo "unexpected gh invocation: $*" >&2
exit 1
"#,
            ),
            "write the gh stub",
        );
        must(
            fs::write(
                bin.join("sleep"),
                "#!/bin/sh\nprintf '%s\\n' \"$*\" >> \"${STUB_STATE:?}/sleeps\"\n",
            ),
            "write the sleep stub",
        );
        make_executable(&bin.join("gh"));
        make_executable(&bin.join("sleep"));
        bin
    }

    /// One run of the create body against the stub toolbelt: its state
    /// directory (view counts, sleep log) and its captured output.
    #[cfg(unix)]
    struct CreateScenario {
        state: PathBuf,
        output: std::process::Output,
    }

    /// Run the create body for one stub scenario: `view_succeed_from` names
    /// the view call that first succeeds, `create_ok` decides the create.
    #[cfg(unix)]
    #[expect(
        clippy::too_many_arguments,
        reason = "one scenario run threads its six inputs explicitly"
    )]
    fn run_create_scenario(
        script: &std::path::Path,
        scratch: &std::path::Path,
        bin: &std::path::Path,
        name: &str,
        closure: &str,
        head: &str,
        view_succeed_from: &str,
        create_ok: &str,
    ) -> CreateScenario {
        let state = scratch.join(name);
        must(fs::create_dir_all(&state), "create the scenario state");
        let output = run_shell_body(
            script,
            scratch,
            Some(bin),
            &[
                ("TAG", "tag"),
                ("CLOSURE", closure),
                ("HEAD_SHA", head),
                (
                    "STUB_STATE",
                    must_some(state.to_str(), "the scenario state"),
                ),
                ("VIEW_SUCCEED_FROM", view_succeed_from),
                ("GH_CREATE_OK", create_ok),
            ],
        );
        CreateScenario { state, output }
    }

    #[cfg(unix)]
    #[test]
    fn conflicting_create_converges_when_the_release_appears() {
        let content = owner_content(&[]);
        let bodies = step_bodies(&content);
        let create = must_some(
            bodies
                .iter()
                .find_map(|(name, body)| (name == "Create the release").then_some(body)),
            "the rendered create body",
        );
        let script = std::env::temp_dir().join(format!(
            "velnor-workflow-create-body-{}",
            crate::unique_suffix()
        ));
        must(fs::write(&script, create), "write the create body");
        let bin = stub_toolbelt("converge");
        let scratch = std::env::temp_dir().join(format!(
            "velnor-workflow-create-scratch-{}",
            crate::unique_suffix()
        ));
        must(fs::create_dir_all(&scratch), "create the scratch dir");
        let closure = "0".repeat(64);
        let head = "0".repeat(40);

        // A clean create succeeds without ever sleeping.
        let scenario = run_create_scenario(
            &script, &scratch, &bin, "clean", &closure, &head, "99", "true",
        );
        assert!(
            scenario.output.status.success(),
            "the clean create succeeds: {}",
            String::from_utf8_lossy(&scenario.output.stderr)
        );
        assert!(
            !scenario.state.join("sleeps").exists(),
            "the clean create never sleeps"
        );
        assert_eq!(
            must(
                fs::read_to_string(scenario.state.join("views")),
                "read the view count"
            ),
            "1",
            "the clean create views once"
        );

        // A conflicting create converges when the release appears: one
        // sleep, then the winner's row.
        let scenario = run_create_scenario(
            &script, &scratch, &bin, "conflict", &closure, &head, "2", "false",
        );
        assert!(
            scenario.output.status.success(),
            "the conflicting create converges: {}",
            String::from_utf8_lossy(&scenario.output.stderr)
        );
        assert!(
            String::from_utf8_lossy(&scenario.output.stdout).contains("converging"),
            "the conflicting create names the converge: {}",
            String::from_utf8_lossy(&scenario.output.stdout)
        );
        assert_eq!(
            must(
                fs::read_to_string(scenario.state.join("sleeps")),
                "read the sleep log"
            ),
            "5\n",
            "the converge waits one backoff step"
        );

        // When nothing materializes the run fails after the full backoff.
        let scenario = run_create_scenario(
            &script, &scratch, &bin, "absent", &closure, &head, "99", "false",
        );
        assert!(
            !scenario.output.status.success(),
            "the absent release fails the run"
        );
        assert!(
            String::from_utf8_lossy(&scenario.output.stderr)
                .contains("was not created and did not appear"),
            "the failure names the missing release: {}",
            String::from_utf8_lossy(&scenario.output.stderr)
        );
        assert_eq!(
            must(
                fs::read_to_string(scenario.state.join("sleeps")),
                "read the sleep log"
            ),
            "5\n10\n15\n30\n",
            "the failure exhausts the backoff"
        );

        let _ = fs::remove_file(&script);
        let _ = fs::remove_dir_all(&scratch);
        let _ = fs::remove_dir_all(&bin);
    }

    /// The rendered bytes, pinned to the digest of the reviewed render. The
    /// digest is the expectation, not a second call into the same code, so a
    /// renderer change shows up here and has to be carried into the pin
    /// deliberately; the structural assertions above say what the pinned
    /// bytes are for.
    #[test]
    fn rendered_bytes_are_pinned() {
        const PINNED: &str = "f2e3a31f2196fc8244dd48042b9a5a796e051ab38a6c92448470ccbecb9ced44";
        let content = owner_content(&["maintenance.yml"]);
        let digest = digest_of(&content);
        assert_eq!(digest, PINNED, "rendered producer bytes changed");
    }
}
