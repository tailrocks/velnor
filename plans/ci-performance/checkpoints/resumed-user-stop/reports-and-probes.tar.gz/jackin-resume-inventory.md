# Jackin CI campaign refresh

Read-only inventory, 2026-09-21. No fetch, checkout, source edit, cache
mutation, or workflow dispatch was performed. The historical timing source is
raw job `started_at`/`completed_at`; `updated_at` is excluded.

## Revisions

| object | revision / state |
| --- | --- |
| preserved local campaign checkpoint | `34e1d852c8473b6b9128e04d811ee691aff87ba2` (`merge(ci): preserve remote progress with local draft checkpoint`) |
| local campaign remote-tracking ref | `95b437e735aafea5fe9b2e638c122345c5d141c3`, local branch is ahead 11 |
| local `main` and stale `origin/main` | `41796158b1e45535ae4e74d5ff048cb5bb4e0488` |
| GitHub `main` at refresh | `fce94cea8a15de0c2db3bb4ff880d741baf5c00a` |
| PR1007 head | `251cbd63231ee842c70f4564839bf8fddef950cc` |

`git status --short --branch` was clean at the checkpoint. The local history
contains the current-main fixes through `fce94cea` plus the campaign merges and
the desktop draft. GitHub compare reports `fce94cea` as seven commits behind
the checkpoint (no commits unique to `fce94cea` in that direction). Comparing
checkpoint `34e1d852` with PR1007 head `251cbd63` leaves only generator state
and `plans/ci-reliability-execution.md` differences; the source task graph is
the same.

Remote refs read from `git ls-remote`:

```text
main                 fce94cea8a15de0c2db3bb4ff880d741baf5c00a
refs/pull/1004/head  073ebbc514028733b3ad844e7c96a9a6ce973968
refs/pull/1005/head  f38cb9ea9fef0ed245a204da7c4396e4afe47562
refs/pull/1006/head  2498b4e113efadd9843f5976a71336c0aa7c5795
refs/pull/1007/head  251cbd63231ee842c70f4564839bf8fddef950cc
```

## Open PRs and actual overlap

* **#1004**, head `073ebbc5`, base `41796158` (open, non-draft): 431 files
  according to the changed-file API; compare reports 300 files from its old
  base. It changes `.github/ci/project.toml`, generated `ci-*` workflows,
  and adds `.github/workflows/preview.yml` (2,087 lines). It adds the
  `release-preview-package` and `verify-preview-package` Mise tasks and the
  package verifier in `crates/jackin-xtask/src/release_verify/package.rs`.
  This is the leading release/product prerequisite, not a small desktop
  timing patch. The branch is based on stale main and needs an explicit
  rebase/integration review.
* **#1007**, head `251cbd63`, base current `fce94cea` (open, draft): exactly
  four changed files: generator state, `mise.toml`,
  `crates/jackin-xtask/src/desktop/tests.rs`, and
  `plans/ci-reliability-execution.md` (`+139/-37` in PR metadata). The source
  changes add typed task-local tool declarations and structured task entries;
  generated desktop/Swift consumers are not changed by this PR.
* **#1013**, head `2604266a`, base `fce94cea` (open, non-draft): product
  replacement for #1002. Its `.github` surface is byte-identical to main; it
  does not alter this CI graph. **#1002** remains open but is superseded by
  #1013.
* **#1005**, head `f38cb9ea`, is a three-file evidence/docs PR against the
  multi-account feature branch. **#1009**, head `7787f1b4`, is a draft telemetry
  PR against that feature branch. Neither is a desktop workflow candidate.
* **#1006** is already merged as `3d510aac`; it is part of the current main
  ancestry and should not be treated as an open campaign head.

## Product graph

The local checkpoint's `mise.toml` is the authoritative task source. The
current remote main still has the older opaque task bodies; the typed draft is
in #1007/checkpoint.

| cadence / unit | ordered work | declared or runner prerequisites |
| --- | --- | --- |
| `desktop-ci` | bindings check, XcodeGen project generation, Swift format check, SwiftLint, desktop host/parity tests, app build, SwiftPM tests, app verify | Rust 1.97.1, `cargo:boltffi_cli` 0.30.1, `cargo-nextest` 0.9.140, XcodeGen 2.46.0, SwiftLint 0.65.1; `xcrun swift-format`, `xcodebuild`, SDK/Xcode are macOS runner capabilities |
| `desktop-merge` | complete `desktop-ci`, then `native/Scripts/run-ui-tests.sh` | adds `xcbeautify` 3.2.1 and `ripgrep` 15.2.0; the UI script has 19 unique serial XCTest selectors |
| `desktop-scheduled` | complete `desktop-merge`, then Periphery | adds Periphery 3.8.0 |
| `swift-package-native` | `mise run swift-package-native-ci` | depends on `rust-jackin-usage-ffi`; nested task `desktop-xcframework` needs Rust + boltffi, then `swift build`/`swift test --parallel` |
| prototype Swift unit | direct Swift build/test under `native/Design/Prototypes/UnifiedAgentUsage` | separate SwiftPM package/cache; no desktop task dependency |

Source locations: `mise.toml:127-260`,
`.github/ci/project.toml:586-609`, and generated
`.github/workflows/ci-unit-swift.yml:120-328`.

The generated desktop jobs at
`.github/workflows/desktop-merge.yml:31-42` and
`.github/workflows/desktop-scheduled.yml:31-42` still install a broad explicit
list (`cargo-binstall`, Rust, nextest, sccache, boltffi, XcodeGen, SwiftLint,
xcbeautify, ripgrep, and scheduled Periphery), then emit a second `Set up Mise`
action with `install: false`. The job executes one opaque `mise run
desktop-{merge,scheduled}` command. This bypasses task-local closure metadata.

The reusable Swift workflow accepts `mise_tools` but the generated native
Swift unit passes none; it only declares `unit_dependencies =
rust-jackin-usage-ffi` in `project.toml`. `ci-unit-swift.yml` sets
`MISE_AUTO_INSTALL=false`, `MISE_EXEC_AUTO_INSTALL=false`, and
`MISE_NOT_FOUND_AUTO_INSTALL=false` around checks, but does not set
`MISE_TASK_RUN_AUTO_INSTALL=false`. A nested task can therefore still broaden
the tool boundary. The desktop workflows do not set these fail-closed flags.

Product duplication is concrete:

1. `desktop-test` can build the XCFramework when absent; `desktop-build`
   unconditionally calls the XCFramework build again. A clean merge job can
   therefore pack the same product twice.
2. The independent `swift-package-native` unit also invokes
   `desktop-xcframework` before SwiftPM build/test. This is useful coverage,
   but it is a second XCFramework producer across CI units with no attested
   product handoff.
3. `desktop-merge` intentionally repeats all PR checks before UI checks, and
   `desktop-scheduled` intentionally repeats the merge graph before Periphery.
   These cadence repetitions are known coverage obligations; they are not proof
   that any build can be deleted.
4. The UI script has 19 distinct selectors and no `build-for-testing` /
   `test-without-building` handoff. Reuse needs raw build/product identity
   evidence before any deduplication claim.

Bindings check remains a separate mandatory, nonmutating gate. A later build's
binding-generation side effect cannot satisfy it. Keep the five host/pure Swift
harnesses, counted SwiftPM tests, app verification, all 19 UI checks, and
scheduled Periphery when changing stage boundaries.

## Saved CI evidence

The history snapshot was generated at `2026-09-20T02:28:36Z`; its run query
ends at `2026-09-20T01:55:00Z`. No newer Jackin raw run was present in the
saved observation tree, so no new collection was started.

| workflow/run | raw evidence | result and wall time |
| --- | --- | --- |
| Desktop merge push `35475235030`, job `105983237683`, head `3b1e1fc0` | `observations/jackin-35475235030-{run,jobs-page1}.json` | success, one job, 2,040 s (`2026-09-19T23:07:49Z`–`23:41:49Z`); setup 16 s, opaque task 2,015 s |
| Desktop merge push `35478203836`, job `105991074920`, head `41796158` | `observations/jackin-35478203836-{run,jobs-page1}.json` | success, one job, **2,635 s** (`2026-09-20T00:14:18Z`–`00:58:13Z`); setup 259 s, opaque task 2,363 s. Slowest successful comparable desktop cohort |
| CI main push `35475235267`, Swift job `105983319926` | `observations/jackin-35475235267-{run,jobs-page1}.json` | success, 44/44 jobs; Swift 766 s |
| CI main push `35478203945`, Swift job `105991186732` | `observations/jackin-35478203945-{run,jobs-page1}.json` | success, 44/44 jobs; Swift 855 s |
| CI PR #1003 `35476890412`, Swift job `105987647734` | `observations/raw-jobs/jackin-35476890412-attempt1-jobs-page1.json.gz`, manifest | success, 43 jobs; Swift 1,226 s |
| CI PR #1007 `35481914321`, Swift job `106001194716` | `observations/raw-jobs/jackin-35481914321-attempt1-jobs-page1.json.gz`, manifest | run failure: Rust primary and controls failed; Swift itself succeeded in 1,394 s. Do not use as a successful baseline |

The two desktop rows are single-job wall durations, so no parallel-job sum is
involved. The two main CI rows are job durations, not workflow critical paths.
The PR1007 run's successful Swift child does not make the failed workflow a
candidate sample.

## Next implementation dependency

The first bounded implementation must finish the generic typed tool boundary
before timing. Use the #1007 task declarations as input, then regenerate the
consumer workflows with a resolver that:

1. walks structured Mise task references and explicit leaf tools;
2. validates every selected tool/version/backend/OS/architecture against
   `mise.lock` and the target macOS runner;
3. emits one deduplicated stage installer, including Rust/boltffi/nextest,
   XcodeGen/SwiftLint/xcbeautify/ripgrep/Periphery only where the stage needs
   them, while retaining system Xcode/SDK capabilities as typed runner facts;
4. sets all relevant Mise auto-install switches false, especially
   `MISE_TASK_RUN_AUTO_INSTALL=false`, and fails before execution on omitted or
   unknown closure members; and
5. keeps bindings, XCFramework, SwiftPM, app, UI, and dead-code obligations
   visible and ordered. A generated check plus actionlint and negative
   missing-tool fixtures are required.

Do not use `mise install --include-task-tools` as the stage resolver: the
existing project-level dry-run proposes all 31 top-level tools. Do not infer
tools from arbitrary shell text. Do not claim the second XCFramework build is
removable until a checked product is passed with an identity/consumer receipt.

Separately, #1004's package product needs integration review: its main-only
`release-preview-package` producer creates six target payloads plus support
assets, exact checksum/cosign/SBOM/capsule manifests, and an immutable
source-bound handoff; `verify-preview-package` is rerun in producer, publisher,
and downloaded-release paths. Wire that product into generated package-release
only after the typed runtime/bootstrap contract is available. It does not
justify weakening desktop coverage or mixing release publication into the
performance experiment.

No valid timing candidate exists yet. After a real pinned runtime, generated
closure preflight, and unchanged coverage, collect at least five paired
baseline/candidate attempts for desktop merge and the important Swift cohort,
retaining failed attempts and reporting raw stage timestamps separately.

