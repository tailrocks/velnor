# MBX workload-key review

Date: 2026-09-21
Scope: read-only source/evidence review. No generator or action edits.

## Verdict

**HOLD for performance claims; accept the collision diagnosis.** The saved
snapshot key identifies a unit/source compatibility class, but it does not
identify the helper workload whose partial MBX closure is being published.
The first immutable GitHub cache writer can therefore select a guest/release
closure for a later CI/test consumer. A writer-only change cannot repair that
wrong-seed condition.

## Evidence

The canonical observation is
`plans/ci-performance/observations/checkpoint-20260920/mbx-investigation.md`.
Preview job `106091539484` saved cache ID `7902037869` with 8 actions and 973
objects. Guest job `106091539371` and CI job `106091578914` used the same exact
key despite different binaries, profiles, features, and commands. The current
CI consumer imported that 8-action/973-object snapshot. Later distinct exports
were 3,593 actions/13,304 objects and 65.57 seconds, followed by 25.75 seconds
of GitHub reservation/compression before immutable-key reservation failed. The
action logged `Saved ... (ID -1)`. This proves a key collision and an expensive
losing writer; it does not prove a compiler speedup or explain every
`not-looked-up` invocation.

The pinned action confirms the ordering. In
`/tmp/velnor-mbx-action-1.4.0/src/index.ts:356-423`, the action computes one
primary key, restores it, imports the object archive, and only saves on the
configured trusted event. In `:447-495`, it exports the complete MBX group
before calling `cache.saveCache`; a rejected immutable save cannot avoid that
export. `src/lib.ts:281-293` currently permits saves on default-branch push or
an explicitly enabled workflow dispatch. A same-repository PR merge-ref
producer would need its event and Actions-cache authority validated explicitly;
the current default PR path is restore-only. Fork bytes remain restore-only.

The generator-side gap is visible in both snapshot implementations:

* legacy `crates/velnor-workflow/src/primitives/ir.rs:1505-1532` puts
  `unit_commands(unit)` into `CompatibilityFacts`, alongside toolchain,
  linker, flags, and Cargo inputs;
* S2 `crates/velnor-workflow/src/s2/primitives/ir.rs:1732-1767` adds provider,
  platform, and trust, but still has only the unit command recipe as workload
  identity;
* `crates/velnor-workflow/src/primitives/snapshot.rs:47-76` and its S2
  counterpart hash all declared fields, but neither has a workload-specific
  execution stage, profile, feature set, target set, selected members, or
  workload declaration;
* pinned MBX
  `/tmp/velnor-mbx-source-1.12.0/crates/mbx-cache-cargo/src/lib.rs:194-203`
  deliberately ignores the Cargo command so build/test/Clippy predictions can
  share. Its rustc invocation digest can still distinguish profile, features,
  target, and compiler. That internal sharing does not prevent the outer
  immutable cache from choosing the wrong first snapshot.

The existing v3 freshness segment prevents a source-state snapshot from being
reused forever, but freshness is not workload identity. Provider/platform/trust
segments prevent cross-tier imports, but are also not workload identity.

## Recommended bounded design

Add a typed `CacheWorkload` declaration at the generator/IR boundary and make
its canonical digest part of the outer snapshot compatibility class. The
declaration should contain, as structured values:

* workload role (`guest`, `ci-check`, `clippy`, `nextest`, `release`, or an
  explicitly declared future role);
* selected package/member set and workspace root;
* Cargo profile, feature selector, target/triple set, and test/benchmark
  selection where they affect the produced state;
* a canonical invocation identity owned by the renderer, not shell token
  splitting or a free-form command string;
* the already existing payload, MBX/toolchain, provider, platform, and trust
  facts.

Canonicalize list order and encode field boundaries unambiguously. Append the
workload digest to the compatibility facts and bump the snapshot schema. An
unknown or untyped workload must fail generation; broad fallback to the unit
ID recreates the defect. Restore prefixes must retain the workload segment, so
an outer GitHub snapshot never crosses roles. MBX’s internal prediction/CAS
sharing can remain broader only where its own re-verification proves the
objects compatible; that is a separate relation from immutable snapshot
selection.

Keep save authority and receipt separate from compiler identity. Record the
event/ref/trust decision and the actual cache-save result; ID `-1` is a failed
or losing reservation, not a successful save. A producer experiment may use a
trusted default-branch push, trusted dispatch, or a same-repository PR
merge-ref writer after explicit cache-permission validation. No producer path
may make a fork writable, and a cache receipt cannot become a validation gate
for the compiler result.

## Alternatives and disposition

1. **Typed workload digest in the outer key (recommended).** Fixes the enabling
   condition while retaining safe internal MBX prediction sharing. Requires a
   schema bump and explicit declarations for every producer/consumer role.
2. **Static namespace per helper** (`guest`, `ci`, `clippy`, etc.). Smaller
   change, but future command/profile/member variants can silently collide or
   require another key edit. Accept only as an intermediate implementation if
   the same typed contract is enforced at generation.
3. **One union producer snapshot.** A producer runs every required workload and
   publishes a superset. This avoids partial first-writer state but increases
   cold cost, duplicates checks, and turns a failed/unknown helper into an
   unsafe product unless every member is receipt-bound. It is not a substitute
   for identity.
4. **Save lock/preflight or action-side duplicate suppression.** Reduces wasted
   export after another writer wins, but leaves the first wrong snapshot in
   place. Useful after identity is fixed, never the root repair.
5. **Switch target/objects transport.** Transport choice may change unpack and
   lookup cost, but cannot make distinct workloads share an immutable key
   safely. Measure it as a separate experiment.

## Required regression and measurement

The focused generator fixture should prove that identical typed workloads
produce identical keys; changing role, profile, features, target, selected
members, command identity, provider, platform, or trust changes the key; list
permutation does not; old v3 keys are rejected; and restore prefixes never
cross workloads. An emitted workflow fixture should exercise guest producer,
CI consumer, a profile/features/target mismatch, and a fork/read-only run. It
must assert the mismatch cannot import the producer’s exact outer snapshot
while retaining only an explicitly safe MBX-internal fallback.

The action fixture should distinguish exact restore, prefix restore, no
restore, successful save, and immutable reservation loss (`ID -1`). It should
assert that export/reservation time remains attributed even when no cache was
saved. Save authority tests must cover default push, enabled dispatch,
same-repository PR only if the chosen workflow grants it, and fork restore-only.

Only after those tests should the campaign run matched cold producer, exact
same-workload warm consumer, and deliberately incompatible workload cohorts on
the same runner/toolchain/source/trust. Preserve source/effective checkout
identity, imported actions/objects, compiler hits/misses/not-looked-up/bypass,
restore/export/reservation/post times, cache IDs, and save receipts. Current
Parallax/Velnor runs remain diagnostic, not a speedup sample.
