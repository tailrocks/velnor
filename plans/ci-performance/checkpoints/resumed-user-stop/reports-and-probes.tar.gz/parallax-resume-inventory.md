# Parallax resume inventory — 2026-09-21

Read-only refresh. No Git mutation or workflow dispatch.

## Revisions and PR state

| Object | Revision/state | Meaning |
|---|---|---|
| Public `main` | `5af3c01611c87252cb1e4b083c18354555649ca7` | Clean local checkout and `origin/main`; merge commit for PR119. Tree `dbe2c184e341a56c0ebc06bfec8075e7161039f7`. |
| PR119 head | `8e1262d75cdf8b091f479ef4639b139041e47eff` | Merged at `5af3c016`; same tree as public `main`. [PR119](https://github.com/tailrocks/parallax/pull/119). |
| PR118 head | `60cf651bdc81b457ddba34fb214f6b1c1aae571b` | Merged at `3a657a54`; embedded-UI product validation and package-input graph. [PR118](https://github.com/tailrocks/parallax/pull/118). |
| Validated integration checkout | `/tmp/parallax-ci-integration`, `8e1262d7` | Clean; tree-identical to public `main`, but a different local merge topology. It is evidence for the merged PR119 result, not a newer unpublished tree. |
| Archived campaign draft | `/Users/donbeave/Projects/tailrocks/parallax-project/parallax`, `3a784c6` | Branch `codex/ci-performance-campaign`, locally one commit ahead of remote `dcf1d08c`; superseded draft. It differs from current `main` by 18 files and thousands of generated lines. Do not use it as validated CI behavior. |

`gh pr list --state open` is empty. The latest visible Parallax PR is #119; no newer open consumer PR exists in the current API view.

## Current source and generated CI

`.github-gen/velnor-workflow.toml` is schema 1, pinned to Velnor runtime `4fa7a3a85f141a6bb95bc9bdf0eef9e3ddde165d`. It declares GitHub as the only automatic and manual backend (`runners = "github"`, `automatic_lanes = "github"`, `default_dispatch_runner = "github"`), Ubuntu `26.04`, and `actions: read` plus `contents: read` workflow permissions. Manual `both`/Velnor execution is not present in this current consumer tree.

The generated `.github/ci/project.toml` is schema 2 and contains 21 units: Bun UI, one benchmark Docker unit, 18 Rust units, and `rust-policy`. `ci-pr.yml` runs selected units after `plan`; `ci-main.yml` runs units after both `plan` and `policy`; the main workflow keeps `cancel-in-progress: false`. `ci-policy.yml` is `pull_request_target` with `contents: read`, checks the declared ruleset contexts, and runs the pinned policy runtime before the main required gate. The generated files are checked in and match the source config state.

The Rust reusable workflow uses `jdx/mr-boxington-action@867fc530102eec5b756075d70d850dc8330d2272` (v1.4.0), Mr. Boxington `1.12.0`, GitHub object mode, per-unit compatibility/dependency/freshness keys, a `12GiB` store bound, `MBX_GC_AUTO=0`, and `/home/runner/work/_temp` for `TMP`/`TMPDIR`. The config comment correctly says directory transport removes the old second tar unpack but does not establish that all temporary work or GC is safe.

Current scan exclusions are:

* `crates/parallax-xtask/src/release/tests.rs`;
* `scripts/fixtures/nextest-evidence/**`;
* `crates/parallax-sentry-proxy/Dockerfile`.

The last exclusion is still a coverage gap. That Dockerfile copies the repository through the named `parallax-checkout` context and performs a locked release build with Rust 1.97; current generated CI has the Rust `parallax-sentry-proxy` crate unit but no Docker unit for this Dockerfile. The exclusion must not be treated as harmless scaffold removal without a replacement Docker obligation.

## Run evidence: cold/warm cache behavior

Primary raw evidence is PR119 run [35525629941](https://github.com/tailrocks/parallax/actions/runs/35525629941), attempt 1, source `8e1262d7`, effective checkout/merge SHA `1ba04c383691f97b8cb49bb72af6c74949a1e686`.

| Measure | Observed |
|---|---:|
| Required result | 756 s |
| Last control job | 762 s |
| Sum of 24 verified job durations | 3,666 s |
| Rust server job | 723 s |
| Rust CLI job | 562 s |
| Server/CLI compiler first segment | 7m12s / 4m50s |
| Server/CLI compiler second segment | 3m13s / 3m06s |

The raw server and CLI logs both say `No mbx cache found`. Their object-cache summaries are `0 hits, 0 misses, 1654/1643 not looked up, 128 bypassed` on the first segment and `0 hits, 3 misses, 1569/1561 not looked up, 126 bypassed` on the second. Both jobs report `directory_import_exercised=false`, and the run was a pull request, so it did not exercise the MBX export path. Rustup, mold, Cargo/unit caches, and mise show exact cache hits. Therefore this is **MBX-cold / host-tool-cache-warm**, not a warm compiler-cache observation.

The schema-1 report labels MBX `prefix`, but raw state is `miss` and `reported_mbx_state_valid=false`. Raw step/compiler lines are the baseline; the report field is known telemetry misclassification. The 48 s server and 46 s CLI post-MBX steps are retained as raw durations only; they do not prove export, GC, or save work.

Older run [35522592113](https://github.com/tailrocks/parallax/actions/runs/35522592113), source PR118 head `60cf651b` and effective merge `ce04e0c0`, shows the same cold MBX pattern: server 787 s, CLI 201 s, zero object hits, and the same report-vs-raw mismatch. The source, job mix, and warm state differ, so these runs do not support a speedup claim or direct timing comparison.

Raw files retained for replay:

* `/tmp/parallax-8e126-{summary,observation,run-raw,jobs-raw,jobs.jsonl,jobs.csv,server.log,cli.log}`;
* `/tmp/parallax-60cf-{summary,final-run,jobs-raw,jobs.jsonl,jobs.csv,server.log,server-reports.json}`.

There is no accepted warm MBX hit or directory-import measurement in this evidence set. The next valid cache experiment needs a producer path with proven save authority—trusted main/default push, trusted dispatch, or a same-repository PR merge-ref writer after explicit Actions-cache permission validation—followed by an exact-compatible consumer import. Keep raw action/cache and compiler evidence separate.

## Embedded UI product and invalidation

The current source has a typed `bun-ui` producer watching `ui/**`, producing product `embedded-ui` through `build-ui-for-rust`. `mise.toml` defines that task as `cd -- ui && bun install --frozen-lockfile && bun run build`. Both `rust-parallax-server` and `rust-parallax-cli` declare the product prerequisite and also begin their own job command list with `mise run build-ui-for-rust`.

`crates/parallax-server/build.rs` is fail-closed when `embed-ui` is enabled. It requires `ui/dist/client/_shell.html`, checks workspace containment, rejects symlink components/tree entries and special files, rejects empty output and the legacy placeholder marker, and reports `mise run build-ui-for-rust` rather than writing a fake product. Release tests exercise missing, empty, legacy-marker, symlink, socket, FIFO, and real-product cases. The CLI feature delegates to the server `embed-ui` feature.

The saved generator-selection fixture `/tmp/parallax-ui-selection-after.json` records generator `4fa7a3a8` with `fallback_full=false`: a changed `ui/**` path matches `bun-ui`, then selects server/CLI through the product graph and their Rust prerequisite closure. The older `/tmp/parallax-ui-selection-048-comparison.json` records the previous whitelist behavior as unmatched-path `fallback_full=true`. The saved candidate fixture also contains an unmerged `docker-crates-parallax-sentry-proxy` unit; current public `main` does not. Treat that Docker entry as archived candidate evidence, not proof of current main coverage.

Remaining UI/product boundaries:

1. Correctness currently depends on the generator preserving the typed product edge because server/CLI watch lists themselves do not contain `ui/**`. The selection fixture proves the edge in its candidate configuration, but a current-main regression should exercise the exact checked-in config after every generator change.
2. Each server/CLI job rebuilds the UI in its own fresh checkout. There is no cross-job embedded-UI artifact handoff, so product generation is duplicated; this is an observed cost/architecture fact, not a warm-cache result.
3. The static project analysis explicitly says build-script generated outputs and system dependencies are not inferred. `build.rs` emits a directory `rerun-if-changed` marker, while CI relies on the explicit product task. UI invalidation therefore remains graph/task-contract dependent rather than inferred from Cargo alone.
4. The sentry-proxy Dockerfile remains excluded while the source Docker build uses a named checkout context and locked release build. Its Rust crate is selected independently; the Docker product obligation is not represented in current generated CI.

## Verdict

PR119/commit `5af3c016` is the current validated consumer baseline. The 8e126 integration is tree-identical and passed its 24-job PR run. Compiler evidence is mixed: Rustup/mold/Cargo are warm, MBX object storage is cold and unimported, and schema-1 MBX report fields are invalid for performance conclusions. Embedded UI product validation is fail-closed and typed into server/CLI selection, but repeated consumer builds, Cargo-vs-product invalidation dependence, and the excluded sentry Docker product remain open campaign gaps. The archived `3a784c6` draft is not evidence for current behavior.
