fn prefix_step_block_with_if(block: &str, guard: Option<&str>) -> String {
    let Some(guard) = guard else {
        return block.to_owned();
    };
    let mut out = String::new();
    let mut pending_name: Option<String> = None;
    let mut pending_if: Option<String> = None;

    let flush_step = |out: &mut String, name: &str, if_expr: Option<&str>| {
        out.push_str(name);
        out.push('\n');
        let combined = if let Some(existing) = if_expr {
            format!("        if: ${{{{ {guard} && ({existing}) }}}}\n")
        } else {
            format!("        if: ${{{{ {guard} }}}}\n")
        };
        out.push_str(&combined);
    };

    for line in block.lines() {
        if line.starts_with("      - name:") {
            if let Some(name) = pending_name.take() {
                flush_step(&mut out, &name, pending_if.as_deref());
                pending_if = None;
            }
            pending_name = Some(line.to_owned());
        } else if pending_name.is_some() && line.trim().starts_with("if:") {
            let expr = line.trim().strip_prefix("if:").unwrap_or("").trim();
            pending_if = Some(
                expr.strip_prefix("${{ ")
                    .and_then(|value| value.strip_suffix(" }}"))
                    .unwrap_or(expr)
                    .to_owned(),
            );
        } else {
            if let Some(name) = pending_name.take() {
                flush_step(&mut out, &name, pending_if.as_deref());
                pending_if = None;
            }
            out.push_str(line);
            out.push('\n');
        }
    }
    if let Some(name) = pending_name.take() {
        flush_step(&mut out, &name, pending_if.as_deref());
    }
    out
}

#[test]
fn existing_condition_after_id_remains_single() {
 let b="      - name: save\n        id: save\n        if: always() && ready\n        run: true\n";
 let out=prefix_step_block_with_if(b,Some("selected"));
 assert_eq!(out.lines().filter(|line|line.starts_with("        if:")).count(),1,"{out}");
}
#[test]
fn disjunctive_membership_is_grouped() {
 let b="      - name: save\n        if: authorized\n        run: true\n";
 let out=prefix_step_block_with_if(b,Some("first || second"));
 assert!(out.contains("(first || second) && (authorized)"),"{out}");
}
