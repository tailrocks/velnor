### 35479860264 / job 105995596023 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35479860264/job/105995596023

Class: generated-tree;candidate-product. Raw SHA256: `c816b179524552079b4286cbaff7c71591e92a6da743cbcca98b2a13279e2986`.

```text
2026-09-20T00:51:37.4956264Z error: generated files differ: .github/actionlint.yaml, .github/workflows/ci-runtime-products.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T01:06:47.1537148Z ##[error]no candidate product velnor-workflow-candidate-f9a281911e33f8f1-Linux-X64 was published within 15 minutes
2026-09-20T01:06:47.1546519Z ##[error]Process completed with exit code 1.
```

### 35479860264 / job 105997417384 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35479860264/job/105997417384

Class: unclassified. Raw SHA256: `df79d898ae7d033fb66b050cea80bb6bda054f2e38f519786fd5799e443acf9d`.

```text
2026-09-20T01:06:54.7412731Z ##[error]Process completed with exit code 1.
```

### 35479860264 / job 105997431546 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35479860264/job/105997431546

Class: unclassified. Raw SHA256: `dc873d954e030dba42a0c0d9e98f58c1881bc27369fed1883bbce1a8a16564f1`.

```text
2026-09-20T01:07:00.8561536Z ##[error]Process completed with exit code 1.
```

### 35474432949 / job 105981120289 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35474432949/job/105981120289

Class: generated-tree;candidate-product. Raw SHA256: `2fb79f5d5bf8a44a55514ee148bc263dd50c106854bcbb6a91f9b64b41afcbf6`.

```text
2026-09-19T22:50:12.3704010Z error: generated files match but generation inputs changed: generator input changed from 53 to 52 in .github/ci/.github-actions-generator-state; regenerate to record the current generation inputs
2026-09-19T23:05:14.0058186Z ##[error]no candidate product velnor-workflow-candidate-357845bacd21d340-Linux-X64 was published within 15 minutes
2026-09-19T23:05:14.0066727Z ##[error]Process completed with exit code 1.
```

### 35474432949 / job 105982951631 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35474432949/job/105982951631

Class: unclassified. Raw SHA256: `7b433ac1c31a7502e4913d53d788bc9c8b9f127404518417b988915cd579a14e`.

```text
2026-09-19T23:05:19.4331112Z ##[error]Process completed with exit code 1.
```

### 35474432949 / job 105982960074 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35474432949/job/105982960074

Class: unclassified. Raw SHA256: `6f7073c9eda87a1efd6067939464c1a45abadf2d5dd2916399d0d5cd114e92a5`.

```text
2026-09-19T23:05:24.2237748Z ##[error]Process completed with exit code 1.
```

### 35480811779 / job 105998176337 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35480811779/job/105998176337

Class: generated-tree;candidate-product. Raw SHA256: `6e8a3f9a4b33ef9a7db6786a0c8bd144aff63bc13c3f99f6f58b75bb705f0636`.

```text
2026-09-20T01:13:36.2996487Z error: generated files differ: .github/actionlint.yaml, .github/ci/project.toml, .github/workflows/ci-main.yml, .github/workflows/ci-pr.yml, .github/workflows/ci-runtime-products.yml, .github/workflows/ci-unit-rust.yml, .github/workflows/preview.yml, .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T01:28:42.8982398Z ##[error]no candidate product velnor-workflow-candidate-ee54e59efde29dba-Linux-X64 was published within 15 minutes
2026-09-20T01:28:42.8991606Z ##[error]Process completed with exit code 1.
```

### 32826979409 / job 97738741393 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32826979409/job/97738741393

Class: unclassified. Raw SHA256: `3ee9e0acb83b3350b70ee431c962e862117b587124b2cefbdad6eea3dbf0e6d8`.

```text
2026-08-25T08:36:57.4194660Z ##[error]Process completed with exit code 1.
```

### 32826979409 / job 97738767158 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32826979409/job/97738767158

Class: unclassified. Raw SHA256: `1834accc9e4c97485ecc463746008147468f8253954a73030466e411b59524df`.

```text
2026-08-25T08:37:03.0857700Z ##[error]Process completed with exit code 1.
```

### 33288263414 / job 99195925640 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33288263414/job/99195925640

Class: unclassified. Raw SHA256: `933ec3bb01f4f0be6bcf22e6de120fedec7a39d2cdbdc21073681a1cf465de56`.

```text
2026-08-30T02:40:18.0048959Z ##[error]Process completed with exit code 1.
```

### 33288263414 / job 99195936132 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33288263414/job/99195936132

Class: unclassified. Raw SHA256: `086247bbe53bdfd9b8e7d9a0468d11ed029e1c5c0f56d8ec48b6d88e0bf55f08`.

```text
2026-08-30T02:40:23.8240347Z ##[error]Process completed with exit code 1.
```

### 33288263414 / job 99196630230 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33288263414/job/99196630230

Class: unclassified. Raw SHA256: `8663671127aab8451c8377aecc59ab447d0d09cb60c14509380e0b695d0d5b9e`.

```text
2026-08-30T02:47:21.3683209Z ##[error]Process completed with exit code 1.
```

### 33288263414 / job 99196641468 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33288263414/job/99196641468

Class: unclassified. Raw SHA256: `03d0bb9c953eecf6fbf964fd88c7adb5c5e4f07062359e1983a4db6c88de4e94`.

```text
2026-08-30T02:47:27.4617210Z ##[error]Process completed with exit code 1.
```

### 35475034188 / job 105982708614 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35475034188/job/105982708614

Class: candidate-product. Raw SHA256: `4d522893bffbfbeff74c0054fa8f068834462d59bd3a2c6ed23dba33f9720be3`.

```text
2026-09-19T23:03:33.1262776Z error: invalid generation config /home/runner/work/velnor/velnor/policy-checkout/.github-gen/velnor-workflow.toml: TOML parse error at line 75, column 1
2026-09-19T23:12:38.6174052Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-5ab3170acd528b4a-Linux-X64
2026-09-19T23:12:38.6182845Z ##[error]Process completed with exit code 1.
```

### 35487077509 / job 106015396103 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35487077509/job/106015396103

Class: unclassified. Raw SHA256: `212897ad3aa534198e7e3094925e13eef789e4a87a6035a0e1433cd6c3f05f05`.

```text
2026-09-20T03:38:47.6341667Z ##[error]no runtime product for revision 284cd33a24cc9bd5ca8ddf3a97c231f4f23d4146 (closure 97c3ee10764f0d2b); the mainline runtime-product publisher builds it after merge
2026-09-20T03:38:47.6350272Z ##[error]Process completed with exit code 1.
```

### 35487077509 / job 106015419964 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35487077509/job/106015419964

Class: unclassified. Raw SHA256: `9576d25e84f76180da6faebce1c67297e1605603df8d39df1996a993c5210091`.

```text
2026-09-20T03:38:53.9410978Z ##[error]Process completed with exit code 1.
```

### 35487077509 / job 106015430767 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35487077509/job/106015430767

Class: unclassified. Raw SHA256: `9edb190c82a0b286669e97328f8abe4a610621fe0a61df7d8193e302167c4507`.

```text
2026-09-20T03:38:59.5154474Z ##[error]Process completed with exit code 1.
```

### 35483331528 / job 106005143427 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35483331528/job/106005143427

Class: unclassified. Raw SHA256: `bff3f7176c6b796ea01fe7f807cb76b00f47b61ab01a2fa017df6d704063c885`.

```text
2026-09-20T02:18:14.2899771Z error: case-sensitive file extension comparison
2026-09-20T02:18:14.2915067Z error: could not compile `velnor-workflow` (lib) due to 1 previous error
2026-09-20T02:18:26.4288928Z error: could not compile `velnor-workflow` (lib test) due to 1 previous error
2026-09-20T02:18:26.4947082Z error: CI command failed for unit rust-velnor-workflow with exit status: 101
2026-09-20T02:18:26.5021147Z ##[error]Process completed with exit code 1.
```

### 35483331528 / job 106006205745 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35483331528/job/106006205745

Class: unclassified. Raw SHA256: `541e8d7347f4e3664b01ebce7311eba1704d8e0267904be1d81b9d39db6b0d89`.

```text
2026-09-20T02:21:20.3480796Z ##[error]Process completed with exit code 1.
```

### 35483331528 / job 106006216240 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35483331528/job/106006216240

Class: unclassified. Raw SHA256: `4cbcd493e147a27a4010ebe8acba9893be2254d0bd250e84c698b383b1cf5551`.

```text
2026-09-20T02:21:25.4844242Z ##[error]Process completed with exit code 1.
```

### 33348215197 / job 99356773278 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33348215197/job/99356773278

Class: unclassified. Raw SHA256: `6d1441c66f2a1707e7f9c6bf2fe7419b7bd7e8fd64d4476543e013f7b5302be8`.

```text
2026-08-31T01:41:57.7316318Z ##[error]Process completed with exit code 1.
```

### 33348215197 / job 99356787043 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33348215197/job/99356787043

Class: unclassified. Raw SHA256: `4b5246789a2589a3e8d0ec5583f051ef47704d4c02a4277c555487fc9669984d`.

```text
2026-08-31T01:42:04.3192366Z ##[error]Process completed with exit code 1.
```

### 33348215197 / job 99357357641 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33348215197/job/99357357641

Class: unclassified. Raw SHA256: `9c71e832a9c5853b2ed2493b83d01b0a1c2cad2f7e4eb98201c3c481e9c9e0ff`.

```text
2026-08-31T01:46:01.9026558Z ##[error]Process completed with exit code 1.
```

### 33348215197 / job 99357367863 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33348215197/job/99357367863

Class: unclassified. Raw SHA256: `a4a4786f52ce030630e64b566820204418d6f58f84e7d30e3c9029ef9bdfb3c8`.

```text
2026-08-31T01:46:06.1211595Z ##[error]Process completed with exit code 1.
```

### 33353671165 / job 99372125848 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33353671165/job/99372125848

Class: unclassified. Raw SHA256: `eb3785f1471fa99a3c3c9c89f993f9515056cb5603cf8c60fccd4e7234ebf803`.

```text
2026-08-31T03:26:16.8550980Z ##[error]Process completed with exit code 1.
```

### 33353671165 / job 99372137043 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33353671165/job/99372137043

Class: unclassified. Raw SHA256: `3abf431a6ddea880a95d0f9de2ceb03b3bbeca1aa42dbbe62e5291c127acf4f5`.

```text
2026-08-31T03:26:22.2663238Z ##[error]Process completed with exit code 1.
```

### 35495039936 / job 106036394460 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35495039936/job/106036394460

Class: candidate-product. Raw SHA256: `ef8fdccd7741de24f04456587d2d1c3bf8f210852697d62aa87f156b58c7d94e`.

```text
2026-09-20T06:45:20.7074761Z error: invalid generation config /home/runner/work/velnor/velnor/policy-checkout/.github-gen/velnor-workflow.toml: TOML parse error at line 75, column 1
2026-09-20T07:00:27.4539973Z ##[error]no candidate product velnor-workflow-candidate-14b3ec4dfff6262d-Linux-X64 was published within 15 minutes
2026-09-20T07:00:27.4547655Z ##[error]Process completed with exit code 1.
```

### 35472776908 / job 105976682727 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35472776908/job/105976682727

Class: generated-tree;candidate-product. Raw SHA256: `b789b0c6d16322f53de6137abc23ad8c8ed4ccc83f56a22a2793901c3497075a`.

```text
2026-09-19T22:15:12.9198938Z error: generated files differ: .github/workflows/preview.yml, .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-19T22:19:01.3825621Z ##[error]Process completed with exit code 1.
```

### 35520025700 / job 106102422339 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35520025700/job/106102422339

Class: dead-code. Raw SHA256: `d308a46c2fc301bb18370e79ceda85be0a23faf91524fe4901f2bd6b3fc32fde`.

```text
2026-09-20T15:38:51.6354425Z error: variant `Contended` is never constructed
2026-09-20T15:38:51.6360542Z error: could not compile `velnor-runner` (lib) due to 1 previous error
2026-09-20T15:38:51.6941663Z error: CI command failed for unit rust-velnor-workflow with exit status: 101
2026-09-20T15:38:51.7063462Z ##[error]Process completed with exit code 1.
```

### 35520025700 / job 106102422370 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35520025700/job/106102422370

Class: dead-code. Raw SHA256: `85288d7942099adaaffe37fcd2e05d956128adf4dfb94d670fd2cb573d1fec9c`.

```text
2026-09-20T15:37:16.9515599Z error: variant `Contended` is never constructed
2026-09-20T15:37:16.9525166Z error: could not compile `velnor-runner` (lib) due to 1 previous error
2026-09-20T15:37:16.9923026Z error: CI command failed for unit rust-velnorctl with exit status: 101
2026-09-20T15:37:16.9993597Z ##[error]Process completed with exit code 1.
```

### 35520025700 / job 106102422400 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35520025700/job/106102422400

Class: dead-code. Raw SHA256: `a8b2b9144e880755d9855d303ad258d766675dd412034680f7514e223df61ec0`.

```text
2026-09-20T15:36:55.6532575Z error: variant `Contended` is never constructed
2026-09-20T15:36:55.6538749Z error: could not compile `velnor-runner` (lib) due to 1 previous error
2026-09-20T15:36:55.6918753Z error: CI command failed for unit rust-velnor-bench with exit status: 101
2026-09-20T15:36:55.6981339Z ##[error]Process completed with exit code 1.
```

### 35520025700 / job 106102422435 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35520025700/job/106102422435

Class: superseded-diagnostics-deletion;test-failure. Raw SHA256: `5e4ca74a61a0dd8e6403e55a231058243d2d6445c779200cc945bed894dffd98`.

```text
2026-09-20T15:40:36.8808813Z     thread 'crash_with_dead_workers_fails_explicitly' (29100) panicked at crates/velnor-runner/tests/scaleset_daemon.rs:1544:5:
2026-09-20T15:40:36.8809285Z     A's logs were exported before deletion
2026-09-20T15:40:48.8713423Z error: test run failed
2026-09-20T15:40:49.3201074Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-20T15:40:49.3275929Z ##[error]Process completed with exit code 1.
```

### 35520025700 / job 106103214707 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35520025700/job/106103214707

Class: unclassified. Raw SHA256: `171fa17a75a63ff0cd6768b4381982668ff71c015a20d1127cc2ecd61a2d67e2`.

```text
2026-09-20T15:40:56.0583836Z ##[error]Process completed with exit code 1.
```

### 35520025700 / job 106103231361 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35520025700/job/106103231361

Class: unclassified. Raw SHA256: `d9e7b908e776f84661d32e3331b3d28a27c45e0b0d2ad4bf27afe4d7fcd09a56`.

```text
2026-09-20T15:41:02.0578233Z ##[error]Process completed with exit code 1.
```

### 35471681264 / job 105973641999 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35471681264/job/105973641999

Class: candidate-product. Raw SHA256: `3b5a8cf66d814199b6a4824ac04dd4c8512b056d16bf9724a93c98bade701855`.

```text
2026-09-19T21:52:31.2178699Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-31cca14ad264f44c-Linux-X64
2026-09-19T21:52:31.2188980Z ##[error]Process completed with exit code 1.
```

### 35460187905 / job 105942532153 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35460187905/job/105942532153

Class: generated-tree;candidate-product. Raw SHA256: `d03e49c968281076b2500ee599d0307865313757749d38054aea1e235c06a71a`.

```text
2026-09-19T18:07:40.0075065Z error: generated files differ: .github/workflows/ci-unit-rust.yml, .github/workflows/preview.yml, .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-19T18:22:52.2818833Z ##[error]no candidate product velnor-workflow-candidate-966fcf7fccac88f5-Linux-X64 was published within 15 minutes
2026-09-19T18:22:52.2825848Z ##[error]Process completed with exit code 1.
```

### 33536134000 / job 99950994444 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33536134000/job/99950994444

Class: unclassified. Raw SHA256: `87bec642a00be942cce7efdf9ae44424c910ba1ed8fa9a60caf5381f6b490b2e`.

```text
2026-09-01T17:10:30.6938031Z ##[error]Process completed with exit code 1.
```

### 33536134000 / job 99958057796 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33536134000/job/99958057796

Class: unclassified. Raw SHA256: `9dfb6288c9234f3deb46e157064ee2592c4a90bf63cb5eaaaa0d977ac990e2f8`.

```text
2026-09-01T17:32:10.1045586Z ##[error]Process completed with exit code 1.
```

### 34723758941 / job 103634383569 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34723758941/job/103634383569

Class: unclassified. Raw SHA256: `caca12a957d9ee57c1c02877d77d47001a3b64978769c775a6ba558158d13099`.

```text
2026-09-12T22:51:18.0000000Z error: CI command failed for unit docker with exit status: 1
```

### 34723758941 / job 103636009165 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34723758941/job/103636009165

Class: unclassified. Raw SHA256: `1c9e0b2ae6be8aa89c200774d7d7b670fe9df57fb5205b2e6e4ed2ea245e8876`.

```text
2026-09-12T23:04:46.2251054Z ##[error]Process completed with exit code 1.
```

### 34723758941 / job 103643631940 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34723758941/job/103643631940

Class: unclassified. Raw SHA256: `e35e553fffa3dd46a8ecf7b81bbfc524d6102e6983292136331013e7e4355f1a`.

```text
2026-09-13T00:11:07.1633624Z ##[error]Process completed with exit code 1.
```

### 35485890253 / job 106012099388 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35485890253/job/106012099388

Class: candidate-product. Raw SHA256: `57a197af6e22149aff85bdc506402fec30fbcfc0be7cd9ad49f957708dc6e6f9`.

```text
2026-09-20T03:26:17.0436011Z ##[error]no candidate product velnor-workflow-candidate-1e7d319be3752d36-Linux-X64 was published within 15 minutes
2026-09-20T03:26:17.0445962Z ##[error]Process completed with exit code 1.
```

### 35484867513 / job 106009316244 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35484867513/job/106009316244

Class: unclassified. Raw SHA256: `600803246c056c22ef8625d19c542dfb59c9d89da15752f5569244ba595273ba`.

```text
2026-09-20T02:50:34.2784926Z error: this function has too many lines (102/100)
2026-09-20T02:50:34.2793456Z error: could not compile `velnor-workflow` (lib) due to 1 previous error
2026-09-20T02:50:37.4285596Z error: CI command failed for unit rust-velnor-workflow with exit status: 101
2026-09-20T02:50:37.4338581Z ##[error]Process completed with exit code 1.
```

### 35484867513 / job 106009737349 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35484867513/job/106009737349

Class: unclassified. Raw SHA256: `003d575d3294f763aaf2f22e2056c566964b983658559b2d84289a5959b7db6c`.

```text
2026-09-20T02:50:44.1147052Z ##[error]Process completed with exit code 1.
```

### 35484867513 / job 106009746939 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35484867513/job/106009746939

Class: unclassified. Raw SHA256: `5adafc85a76dd55d09cde05afdc0cb5bdb6ad8301a452dd66568e5a5c945753c`.

```text
2026-09-20T02:50:48.7466202Z ##[error]Process completed with exit code 1.
```

### 35516406522 / job 106092991732 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35516406522/job/106092991732

Class: generated-tree;candidate-product. Raw SHA256: `037679fe576e7e0ca676eac1ae0005cd9e1e0555aa4e6be5032b63eb25f53636`.

```text
2026-09-20T14:25:10.3970005Z error: generated files match but generation inputs changed: scan input changed from b096c93329fcc370 to 5691f3c8c8b8d479 in .github/ci/.github-actions-generator-state; regenerate to record the current generation inputs
2026-09-20T14:29:50.3540152Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-9e6bb04aed5e5a89-Linux-X64
2026-09-20T14:29:50.3549354Z ##[error]Process completed with exit code 1.
```

### 32776301289 / job 97588309286 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32776301289/job/97588309286

Class: unclassified. Raw SHA256: `3693e7b41c6132ea56efa5d7f16d333feb5ff4223d4cf97fd64d819352893212`.

```text
2026-08-24T20:53:29.9475848Z error: No such remote: 'origin'
```

### 32776301289 / job 97588309352 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32776301289/job/97588309352

Class: unclassified. Raw SHA256: `b74231213f64fec42618fd741471c100601b01994db02ebececb46137dc55926`.

```text
2026-08-24T20:53:29.4547840Z error: No such remote: 'origin'
```

### 32776301289 / job 97588309370 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32776301289/job/97588309370

Class: unclassified. Raw SHA256: `1d7f13a05496ffd4e9cf9ccd295ced69e6fca750910fa26e4da68b062b7bd166`.

```text
2026-08-24T20:52:56.7169044Z error: No such remote: 'origin'
```

### 32776301289 / job 97589878370 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/32776301289/job/97589878370

Class: unclassified. Raw SHA256: `ab441c845b8991d6f152103453304584f852dea77c4fad6e63dba35e5bf1b60e`.

```text
2026-08-24T20:58:13.8701057Z error: No such remote: 'origin'
```

### 32776301289 / job 97589878439 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/32776301289/job/97589878439

Class: unclassified. Raw SHA256: `91042f914226ffbcf03c5e75e0e8a0b49cbae7c5afe4251d20b9a5dd077f51e5`.

```text
2026-08-24T20:58:14.3785757Z error: No such remote: 'origin'
```

### 32776301289 / job 97589878468 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/32776301289/job/97589878468

Class: unclassified. Raw SHA256: `08019c56cbfdf7d6f7696d5cabe17ec5db5410c6492f205de6c62b378799249f`.

```text
2026-08-24T20:58:14.8926646Z error: No such remote: 'origin'
```

### 32776301289 / job 97608670834 / attempt 4

https://github.com/tailrocks/velnor/actions/runs/32776301289/job/97608670834

Class: unclassified. Raw SHA256: `8137c025c1013d00edee0cb945e62bc392f7e78d5907441a1dd2b68a8583330d`.

```text
2026-08-24T22:05:39.4573305Z error: No such remote: 'origin'
```

### 32776301289 / job 97610752271 / attempt 5

https://github.com/tailrocks/velnor/actions/runs/32776301289/job/97610752271

Class: unclassified. Raw SHA256: `acd30485859f2cae07fced243df1c10292ebc31c11c565f6b2c01885fc62ae00`.

```text
2026-08-24T22:13:34.7096154Z error: No such remote: 'origin'
```

### 32776301289 / job 97635475767 / attempt 6

https://github.com/tailrocks/velnor/actions/runs/32776301289/job/97635475767

Class: unclassified. Raw SHA256: `5dfb76534a68ce20579c86147c2f664b563ff578db8abfbd81f6a9e3772d29db`.

```text
2026-08-25T00:04:03.5827712Z error: No such remote: 'origin'
```

### 35467711578 / job 105962985201 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35467711578/job/105962985201

Class: generated-tree. Raw SHA256: `be2ededddc0f86cd985ec0365fe0bdfa0ad8e8f2f134c37426ce10eaea361de8`.

```text
2026-09-19T20:32:53.8931430Z error: workflow policy failed: generated-tree
2026-09-19T20:32:53.8938323Z FAIL generated-tree         the tree differs from the render of velnor-workflow at fdeed261bd2247a38db6922a7726cd45d3d6f31e
2026-09-19T20:32:53.8957256Z ##[error]Process completed with exit code 1.
```

### 34718367936 / job 103619583776 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34718367936/job/103619583776

Class: test-failure. Raw SHA256: `a0de84f7950f27ae3fc66b35a63a5f98fbf3d9282cd64fc8ac7622b77378e6ea`.

```text
2026-09-12T20:56:47.6931236Z     thread 'execution::cancel::tests::a_target_registered_after_cancellation_is_terminated_immediately' (4516) panicked at crates/velnor-runner/src/execution/cancel.rs:1709:9:
2026-09-12T20:56:47.6932747Z       left: []
2026-09-12T20:56:47.6932984Z      right: ["pgid:4242"]
2026-09-12T20:56:47.7017963Z error: test run failed
2026-09-12T20:56:47.7162778Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-12T20:56:47.7195509Z ##[error]Process completed with exit code 1.
```

### 34718367936 / job 103620038140 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34718367936/job/103620038140

Class: unclassified. Raw SHA256: `21e07a65f1b00cd6ffcb7a08790980e67afa28e09ad1b293419907aaef865f91`.

```text
2026-09-12T20:57:10.8172575Z ##[error]Process completed with exit code 1.
```

### 32820212810 / job 97717465757 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32820212810/job/97717465757

Class: rust-lint. Raw SHA256: `ea1bc2ed46bd3f1afb1862bd6f2f9199b2cb17b9b8e2e522c8f93163aadd7aed`.

```text
2026-08-25T07:13:31.0119615Z error: No such remote: 'origin'
2026-08-25T07:13:33.0000000Z error: No such remote: 'origin'
2026-08-25T07:16:43.0000000Z error: large size difference between variants
2026-08-25T07:16:43.0000000Z error: useless conversion to the same type: `args::CapabilitiesArgs`
2026-08-25T07:16:43.0000000Z error: useless conversion to the same type: `args::CapabilitiesArgs`
2026-08-25T07:16:43.0000000Z error: could not compile `velnor-runner` (lib) due to 3 previous errors
2026-08-25T07:16:43.0000000Z error: could not compile `velnor-runner` (lib test) due to 3 previous errors
```

### 32820212810 / job 97718872267 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/32820212810/job/97718872267

Class: rust-lint. Raw SHA256: `c7f63e8c2e3947d624c952855f7b2e773f5e862a4249e30d970996416ac5b382`.

```text
2026-08-25T07:19:09.1542718Z error: No such remote: 'origin'
2026-08-25T07:19:11.0000000Z error: No such remote: 'origin'
2026-08-25T07:22:24.0000000Z error: large size difference between variants
2026-08-25T07:22:24.0000000Z error: useless conversion to the same type: `args::CapabilitiesArgs`
2026-08-25T07:22:24.0000000Z error: useless conversion to the same type: `args::CapabilitiesArgs`
2026-08-25T07:22:24.0000000Z error: could not compile `velnor-runner` (lib) due to 3 previous errors
2026-08-25T07:22:24.0000000Z error: could not compile `velnor-runner` (lib test) due to 3 previous errors
```

### 33349702746 / job 99361146346 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33349702746/job/99361146346

Class: unclassified. Raw SHA256: `6f6324eb612d8fe4a73b63019b4e373ec53a0b333a41c2c0e62334a8ba71d4b3`.

```text
2026-08-31T02:12:13.9685106Z ##[error]Process completed with exit code 1.
```

### 33349702746 / job 99361159668 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33349702746/job/99361159668

Class: unclassified. Raw SHA256: `06336249c5de76af5564805ca72aaceaea3684e4883d7f133ad77716642addc2`.

```text
2026-08-31T02:12:18.7955647Z ##[error]Process completed with exit code 1.
```

### 33349702746 / job 99363137257 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33349702746/job/99363137257

Class: unclassified. Raw SHA256: `4f40612081c73b1b4927e14c1314c89a558a105e570e15756a6385f1c10162fd`.

```text
2026-08-31T02:25:27.8857652Z ##[error]Process completed with exit code 1.
```

### 33349702746 / job 99363149295 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33349702746/job/99363149295

Class: unclassified. Raw SHA256: `5cf98712927924415afcfc3d7c901e9c52bdceaf9b8cf7872819fb59ad5309f2`.

```text
2026-08-31T02:25:33.0513014Z ##[error]Process completed with exit code 1.
```

### 35520255650 / job 106102994568 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35520255650/job/106102994568

Class: generated-tree;candidate-product. Raw SHA256: `5ef852ed068d35393b4bcf819ad86120a28388eb873384862d202c34f0b1b86e`.

```text
2026-09-20T15:39:27.2195917Z error: generated files differ: .github/ci/project.toml, .github/workflows/ci-main.yml, .github/workflows/ci-pr.yml, .github/workflows/preview.yml, .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T15:54:29.5075601Z ##[error]no candidate product velnor-workflow-candidate-8881e50b88c80c40-Linux-X64 was published within 15 minutes
2026-09-20T15:54:29.5085947Z ##[error]Process completed with exit code 1.
```

### 35520255650 / job 106105043045 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35520255650/job/106105043045

Class: unclassified. Raw SHA256: `cb8337782ed3e176055cc9e9dac61562deb6aae1aad71e4e795fa128770b2fc8`.

```text
2026-09-20T15:54:35.6754732Z ##[error]Process completed with exit code 1.
```

### 35520255650 / job 106105054542 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35520255650/job/106105054542

Class: unclassified. Raw SHA256: `c2403d94ce8a0e47ae5813f291bfba669b3a20de9a9db15b0182748672f64a7d`.

```text
2026-09-20T15:54:40.9668491Z ##[error]Process completed with exit code 1.
```

### 35503134927 / job 106058335427 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35503134927/job/106058335427

Class: generated-tree. Raw SHA256: `f1c062151562381972b9d226292c58d4541524f8d824ed5d7bbad7c87073b7da`.

```text
2026-09-20T09:44:30.5423700Z error: workflow policy failed: generated-tree
2026-09-20T09:44:30.5433577Z FAIL generated-tree         the tree differs from the render of velnor-workflow at 0dc79895ff1c5e88be7c3822c437e1c5b5282e12
2026-09-20T09:44:30.5460942Z ##[error]Process completed with exit code 1.
```

### 32903594495 / job 97982802427 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32903594495/job/97982802427

Class: unclassified. Raw SHA256: `5503cdfae5d7ac7b59740d8a6355e7307a889359012c316f108e25b94ee64c76`.

```text
2026-08-25T22:03:11.7658142Z ##[error]Process completed with exit code 1.
```

### 32903594495 / job 97985190780 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/32903594495/job/97985190780

Class: unclassified. Raw SHA256: `db2bb439cf0a33e56a130678f3cb3b74cd669c917936054e682f3063fa691b8d`.

```text
2026-08-25T22:11:07.1310174Z ##[error]Process completed with exit code 1.
```

### 35468978367 / job 105968085418 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35468978367/job/105968085418

Class: dirty-preview. Raw SHA256: `cba7dab62bc235def08ea1a51d149de4566d79e0340f6e01b494314ad6d6c2ce`.

```text
2026-09-19T21:14:44.4635194Z error: failed to run custom build command for `velnor-runner v0.1.277 (/home/runner/work/velnor/velnor/crates/velnor-runner)`
2026-09-19T21:14:44.4651151Z   thread 'main' (18461) panicked at crates/velnor-runner/build.rs:181:9:
2026-09-19T21:15:42.6726808Z ##[error]Process completed with exit code 101.
```

### 35468978367 / job 105968085428 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35468978367/job/105968085428

Class: cross-compiler. Raw SHA256: `7b0930889d8eb7804431ce10a8b5f2ae82f2fb01df11a7cca4b5a3a4dc06de1c`.

```text
2026-09-19T21:12:58.1757093Z error: failed to run custom build command for `aws-lc-sys v0.44.0`
2026-09-19T21:13:01.7389386Z error: failed to run custom build command for `openssl-sys v0.9.117`
2026-09-19T21:13:01.8227181Z ##[error]Process completed with exit code 101.
```

### 35485593003 / job 106011278733 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35485593003/job/106011278733

Class: unclassified. Raw SHA256: `eb12e0d0e64ca3b04f42fc79b690d95f6f63a662e48b5331dd8d1d06ee920693`.

```text
2026-09-20T03:07:57.6416229Z error: unnecessary hashes around raw string literal
2026-09-20T03:07:57.6430795Z error: variables can be used directly in the `format!` string
2026-09-20T03:07:57.6440287Z error: this function has too many lines (133/100)
2026-09-20T03:07:57.6447244Z error: variables can be used directly in the `format!` string
2026-09-20T03:07:57.6454464Z error: variables can be used directly in the `format!` string
2026-09-20T03:07:57.6461993Z error: could not compile `velnor-workflow` (lib test) due to 5 previous errors
2026-09-20T03:07:57.6907358Z error: CI command failed for unit rust-velnor-workflow with exit status: 101
2026-09-20T03:07:57.6969572Z ##[error]Process completed with exit code 1.
```

### 35485593003 / job 106011758467 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35485593003/job/106011758467

Class: unclassified. Raw SHA256: `b3307d038bf2850c83418c9e2ffadb32bfd95913be8027bea8ca458b0dad8e7d`.

```text
2026-09-20T03:08:02.8493700Z ##[error]Process completed with exit code 1.
```

### 35485593003 / job 106011768784 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35485593003/job/106011768784

Class: unclassified. Raw SHA256: `f8641c9c8a2cccf58916466947243a7ec3d33491e4298577cb722365d81186cb`.

```text
2026-09-20T03:08:09.6403981Z ##[error]Process completed with exit code 1.
```

### 35504500719 / job 106063528246 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35504500719/job/106063528246

Class: cross-compiler. Raw SHA256: `9012d67418cf87297b726c6090bbd2a6a3f4af11b87e2ea330907833c3908f98`.

```text
2026-09-20T10:29:34.9159056Z error: failed to run custom build command for `aws-lc-sys v0.44.0`
2026-09-20T10:29:39.2481533Z error: failed to run custom build command for `openssl-sys v0.9.117`
2026-09-20T10:29:39.5451328Z ##[error]Process completed with exit code 101.
```

### 35504500719 / job 106063528303 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35504500719/job/106063528303

Class: dirty-preview. Raw SHA256: `d8c4dcf2a64689cca848cd11ad34206b0d05b134aed0a7375c23c3f3f5618c07`.

```text
2026-09-20T10:31:01.1942529Z error: failed to run custom build command for `velnor-runner v0.1.277 (/home/runner/work/velnor/velnor/crates/velnor-runner)`
2026-09-20T10:31:01.2143314Z   thread 'main' (17003) panicked at crates/velnor-runner/build.rs:181:9:
2026-09-20T10:32:11.1682333Z ##[error]Process completed with exit code 101.
```

### 35050333290 / job 104662483710 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35050333290/job/104662483710

Class: unclassified. Raw SHA256: `3f10acc49a607480b63ce15d641aa82acbbe55cd4235acb063467074e73b754e`.

```text
2026-09-16T04:13:42.6308471Z error: binary `velnor-workflow` already exists in destination
2026-09-16T04:13:42.6349826Z ##[error]Process completed with exit code 101.
```

### 35050333290 / job 104662544714 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35050333290/job/104662544714

Class: unclassified. Raw SHA256: `6d2078e51d523235a08cd796ff9a86a8a44a8ae9fed04ab3edf77ad6571d867f`.

```text
2026-09-16T04:13:48.0808945Z ##[error]Process completed with exit code 1.
```

### 35050333290 / job 104662561599 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35050333290/job/104662561599

Class: unclassified. Raw SHA256: `ccbd3a5691a441fb4cf96bd0cb3bfde937fdb28ab072649e80897ba9a7d3222b`.

```text
2026-09-16T04:13:53.5105634Z ##[error]Process completed with exit code 1.
```

### 35478246397 / job 105991191723 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35478246397/job/105991191723

Class: candidate-product. Raw SHA256: `ba73427efad3677f2f6821a71d19d6f54a9bd07e2125d860135a38edb1d38163`.

```text
2026-09-20T00:15:37.4924121Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-c2a3ced2ee6bc9dc-Linux-X64
2026-09-20T00:15:37.4931819Z ##[error]Process completed with exit code 1.
```

### 35057652729 / job 104672678510 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35057652729/job/104672678510

Class: unclassified. Raw SHA256: `d252f6d29be3664f57a371e50e7353bec48ba0d7bdb8f4f997b592bc25549ae2`.

```text
2026-09-16T05:06:25.9072899Z ##[error]Process completed with exit code 1.
```

### 35057652729 / job 104672698332 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35057652729/job/104672698332

Class: unclassified. Raw SHA256: `0e6b3ac74f7cfbfa30ebfe7d5ef7bed71e22fcdcdfb9c6c898de477e34d988c5`.

```text
2026-09-16T05:06:31.0892087Z ##[error]Process completed with exit code 1.
```

### 35057652729 / job 104674357541 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35057652729/job/104674357541

Class: unclassified. Raw SHA256: `218b71f6baba247629218dbb199e895aa6cff9eb4b839782ff576e29b356e696`.

```text
2026-09-16T05:14:52.1277361Z ##[error]Process completed with exit code 1.
```

### 35057652729 / job 104674373856 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35057652729/job/104674373856

Class: unclassified. Raw SHA256: `deda9261bd9f3052304be364091db9aef2b9cf9e5432e9f81b7fd6820792e4ce`.

```text
2026-09-16T05:14:57.3165151Z ##[error]Process completed with exit code 1.
```

### 35057652729 / job 104674455412 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/35057652729/job/104674455412

Class: unclassified. Raw SHA256: `1f799ba34323bf8e46eb6f505b6901089332ef3f7099899e3659305f0d09c742`.

```text
2026-09-16T05:15:19.0193632Z ##[error]Velnor rejected this job before workflow execution.
```

### 35057652729 / job 104674471153 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/35057652729/job/104674471153

Class: unclassified. Raw SHA256: `acfcb9cebce64585bd7a2e5e8237a777ec2b95db6c254f462258327f40b85ef0`.

```text
2026-09-16T05:15:25.9278438Z ##[error]Process completed with exit code 1.
```

### 35057652729 / job 104674500417 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/35057652729/job/104674500417

Class: unclassified. Raw SHA256: `1ea09eba65c2116aa3a0cc857e51b43e261ea62bce028f5b5d4096bec306df0a`.

```text
2026-09-16T05:15:31.9557151Z ##[error]Process completed with exit code 1.
```

### 35057652729 / job 104674700366 / attempt 4

https://github.com/tailrocks/velnor/actions/runs/35057652729/job/104674700366

Class: test-failure. Raw SHA256: `f31038d770d12206f05d0df4552a66def8983b0b734f0f6d032516a7ed939091`.

```text
2026-09-16T05:18:40.0000000Z     thread '<unnamed>' (6359) panicked at crates/velnor-runner/src/job_claim.rs:418:84:
2026-09-16T05:18:40.0000000Z     thread '<unnamed>' (6361) panicked at crates/velnor-runner/src/job_claim.rs:418:84:
2026-09-16T05:18:40.0000000Z     thread '<unnamed>' (6358) panicked at crates/velnor-runner/src/job_claim.rs:418:84:
2026-09-16T05:18:40.0000000Z     thread 'job_claim::tests::concurrent_claimants_and_sweeps_keep_exactly_one_owner' (6356) panicked at crates/velnor-runner/src/job_claim.rs:440:27:
2026-09-16T05:18:40.0000000Z error: test run failed
2026-09-16T05:18:40.0000000Z error: CI command failed for unit rust-velnor-runner with exit status: 100
```

### 35057652729 / job 104675207925 / attempt 4

https://github.com/tailrocks/velnor/actions/runs/35057652729/job/104675207925

Class: unclassified. Raw SHA256: `bfe6a7f12dc1f96a98948f9f72a4f5a585bf5bf62736e8e0c67b69ac539c3f1c`.

```text
2026-09-16T05:19:04.3850355Z ##[error]Process completed with exit code 1.
```

### 35057652729 / job 104675224091 / attempt 4

https://github.com/tailrocks/velnor/actions/runs/35057652729/job/104675224091

Class: unclassified. Raw SHA256: `e8da376b047d25078a2ecc62832c2886a17d3a85b2466795ea42579e051a8ac2`.

```text
2026-09-16T05:19:08.7412547Z ##[error]Process completed with exit code 1.
```

### 35474432928 / job 105981118594 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35474432928/job/105981118594

Class: generated-tree. Raw SHA256: `ef68c3bfc576183bf5fe366b48b143d27ebd378d3d1f5a2bdeedafc9abafb512`.

```text
2026-09-19T22:50:12.4589967Z error: workflow policy failed: generated-tree
2026-09-19T22:50:12.4595628Z FAIL generated-tree         the tree differs from the render of velnor-workflow at 0dc79895ff1c5e88be7c3822c437e1c5b5282e12
2026-09-19T22:50:12.4608335Z ##[error]Process completed with exit code 1.
```

### 35472844563 / job 105976895017 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35472844563/job/105976895017

Class: generated-tree. Raw SHA256: `1a3a69e14deca95d65a6705ffee2a5481a09e184a66edc484eb923f4b17ebc26`.

```text
2026-09-19T22:18:13.0363131Z error: generated files match but generation inputs changed: generator input changed from 52 to 53 in .github/ci/.github-actions-generator-state; regenerate to record the current generation inputs
2026-09-19T22:18:13.0386735Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
2026-09-19T22:18:13.0450125Z ##[error]Process completed with exit code 1.
```

### 35472844563 / job 105978102795 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35472844563/job/105978102795

Class: unclassified. Raw SHA256: `fc02a45df0d6c0a3cb4d5894f25bc6e0e8d3054c5424979c85f7beaf6ee96ce3`.

```text
2026-09-19T22:25:55.9638347Z ##[error]Process completed with exit code 1.
```

### 35472844563 / job 105978116469 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35472844563/job/105978116469

Class: unclassified. Raw SHA256: `2fc542a4734f29730763a78f9b00222517f9d5d6f53451cd352826d0cc7ad161`.

```text
2026-09-19T22:26:01.3578042Z ##[error]Process completed with exit code 1.
```

### 35484866162 / job 106009274543 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35484866162/job/106009274543

Class: generated-tree;candidate-product. Raw SHA256: `a900e47b203a3707ee284c3e9132772b5c7861b8e5c9925447a0333d7bee4c8f`.

```text
2026-09-20T02:46:59.5746200Z error: generated files differ: .github/actionlint.yaml, .github/workflows/ci-runtime-products.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T02:50:56.9716597Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-65a51a0dfe035955-Linux-X64
2026-09-20T02:50:56.9726183Z ##[error]Process completed with exit code 1.
```

### 33355700556 / job 99379145010 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33355700556/job/99379145010

Class: unclassified. Raw SHA256: `e6d7170be859664390f12c194d1bede9d2df28eddcc5219a5ebb5baf674058f5`.

```text
2026-08-31T04:13:49.2144143Z ##[error]Process completed with exit code 1.
```

### 33355700556 / job 99379163042 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33355700556/job/99379163042

Class: unclassified. Raw SHA256: `204af73fd2becfeb4606d92caa1acd6698c5e7f57d0115ac31e5688487a4aeb0`.

```text
2026-08-31T04:13:55.3238827Z ##[error]Process completed with exit code 1.
```

### 35490350289 / job 106024430147 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35490350289/job/106024430147

Class: rust-lint. Raw SHA256: `1de06c16db556302003ecaa1c465b2b022a830582df006bf8bcbb436fd3be4e1`.

```text
2026-09-20T05:01:53.8241763Z error: unused imports: `SystemTime` and `UNIX_EPOCH`
2026-09-20T05:01:53.8248731Z error: could not compile `velnor-workflow` (lib) due to 1 previous error
2026-09-20T05:01:57.8378246Z error: CI command failed for unit rust-velnor-workflow with exit status: 101
2026-09-20T05:01:57.8439524Z ##[error]Process completed with exit code 1.
```

### 35490350289 / job 106025431952 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35490350289/job/106025431952

Class: unclassified. Raw SHA256: `36191533deb3b74ece8418134f957bf07e29a7d32447f16ff054534464079974`.

```text
2026-09-20T05:07:21.6478218Z ##[error]Process completed with exit code 1.
```

### 35490350289 / job 106025441134 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35490350289/job/106025441134

Class: unclassified. Raw SHA256: `05a00a5f2409d43be420068fe12ffac3d043ea130ba1b5de077ed5e4be422200`.

```text
2026-09-20T05:07:26.0087533Z ##[error]Process completed with exit code 1.
```

### 33340598498 / job 99335754262 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33340598498/job/99335754262

Class: unclassified. Raw SHA256: `37a97b461ac60bbf81f4c122bb363ad0434452d23e1b525da06b828be1ed7b92`.

```text
2026-08-30T23:02:17.2547751Z ##[error]Process completed with exit code 1.
```

### 33340598498 / job 99335763911 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33340598498/job/99335763911

Class: unclassified. Raw SHA256: `8b622bc6dbc09a40671b32ba2cfb8e68a3aee64a29a27163cb9e5ac27df1a98f`.

```text
2026-08-30T23:02:22.8198308Z ##[error]Process completed with exit code 1.
```

### 33314047886 / job 99264089952 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33314047886/job/99264089952

Class: test-failure. Raw SHA256: `e507b0663eb6d774a2a13dd188487e69e20efd900f43a2d3251af219ac9fc53d`.

```text
2026-08-30T13:26:26.6948105Z     thread 'release::tests::maintainer_lock_proof_rejects_marker_and_shared_lock_spoofs' (11016) panicked at crates/velnor-runner/src/release/tests.rs:148:5:
2026-08-30T13:26:58.7767102Z error: test run failed
2026-08-30T13:26:58.7842286Z ##[error]Process completed with exit code 100.
```

### 33314047886 / job 99264518338 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33314047886/job/99264518338

Class: unclassified. Raw SHA256: `b9540ffe7dceca7652a91776d7d4e3add353c291010cd25a16c266b7da7db695`.

```text
2026-08-30T13:27:04.2949985Z ##[error]Process completed with exit code 1.
```

### 33314047886 / job 99264527562 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33314047886/job/99264527562

Class: unclassified. Raw SHA256: `4dd3ef79e25fd3b9d476a1a597d773eadfba7e2c1933788ed658574abac6187b`.

```text
2026-08-30T13:27:08.9975755Z ##[error]Process completed with exit code 1.
```

### 35481089629 / job 105998913030 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35481089629/job/105998913030

Class: generated-tree. Raw SHA256: `73d4c0cb982e6069a3dbd467141a41382516c46903c8c7bdd86a39a14efbdd83`.

```text
2026-09-20T01:19:30.3785228Z error: workflow policy failed: generated-tree
2026-09-20T01:19:30.3792266Z FAIL generated-tree         the tree differs from the render of velnor-workflow at 0dc79895ff1c5e88be7c3822c437e1c5b5282e12
2026-09-20T01:19:30.3811015Z ##[error]Process completed with exit code 1.
```

### 32828062184 / job 97741148122 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32828062184/job/97741148122

Class: unclassified. Raw SHA256: `3c0fc085e25f2f779e75c3fca754e63b142d4d8f03d8f50d378a948fefb4bf74`.

```text
2026-08-25T08:45:56.9910495Z ##[error]Process completed with exit code 1.
```

### 32828062184 / job 97741169683 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32828062184/job/97741169683

Class: unclassified. Raw SHA256: `53b3814a8ac0d222dbb32563d40dcf7803cbaf1469990c92c157fb1468be3440`.

```text
2026-08-25T08:46:01.6837897Z ##[error]Process completed with exit code 1.
```

### 35463512791 / job 105951480321 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35463512791/job/105951480321

Class: generated-tree. Raw SHA256: `2e91d92e34fa3c0c3429e76b1763a92e4d9907d53509fcd36e134469873f4f4d`.

```text
2026-09-19T19:10:44.1506700Z error: workflow policy failed: generated-tree
2026-09-19T19:10:44.1514225Z FAIL generated-tree         the tree differs from the render of velnor-workflow at fdeed261bd2247a38db6922a7726cd45d3d6f31e
2026-09-19T19:10:44.1539188Z ##[error]Process completed with exit code 1.
```

### 35480920648 / job 105998484852 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35480920648/job/105998484852

Class: test-failure. Raw SHA256: `a11d395c9fc66c0d4c5678450b331479fb8577d71de89ae9427cb0ea76e5941c`.

```text
2026-09-20T01:21:18.0261673Z     thread '<unnamed>' (28870) panicked at crates/velnor-runner/tests/scaleset_allocator.rs:131:69:
2026-09-20T01:21:18.0264351Z     thread '<unnamed>' (28868) panicked at crates/velnor-runner/tests/scaleset_allocator.rs:132:49:
2026-09-20T01:21:18.0265414Z     thread '<unnamed>' (28871) panicked at crates/velnor-runner/tests/scaleset_allocator.rs:141:88:
2026-09-20T01:21:18.0266497Z     thread '<unnamed>' (28866) panicked at crates/velnor-runner/tests/scaleset_allocator.rs:131:69:
2026-09-20T01:21:18.0267645Z     thread 'occupancy_never_exceeds_n_under_churn' (28864) panicked at crates/velnor-runner/tests/scaleset_allocator.rs:154:23:
2026-09-20T01:21:24.8896316Z error: test run failed
2026-09-20T01:21:25.6244988Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-20T01:21:25.6324903Z ##[error]Process completed with exit code 1.
```

### 35480920648 / job 105999595008 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35480920648/job/105999595008

Class: unclassified. Raw SHA256: `99a7f0b513bb3dee472afbb9f5e8410930a532a8a0351d88411747c16b301b48`.

```text
2026-09-20T01:25:16.6548135Z ##[error]Process completed with exit code 1.
```

### 35480920648 / job 105999611796 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35480920648/job/105999611796

Class: unclassified. Raw SHA256: `72d1b27d09ddbe487aa00abaa6648a22dc131b914f0084e5ec39f3031eec7078`.

```text
2026-09-20T01:25:23.0545389Z ##[error]Process completed with exit code 1.
```

### 35475992238 / job 105985889188 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35475992238/job/105985889188

Class: test-failure. Raw SHA256: `8386c5250fa6ae77f9d5cc4a4fbef520e091c328b0fa867663b74d49b679f3fb`.

```text
2026-09-19T23:32:31.0620182Z     thread 'generic_modules_never_name_a_repository' (15307) panicked at crates/velnor-workflow/tests/generic_surface_literals.rs:239:5:
2026-09-19T23:32:31.0629055Z       left: 5
2026-09-19T23:32:31.0629419Z      right: 4
2026-09-19T23:32:31.3207311Z error: test run failed
2026-09-19T23:32:31.3332119Z error: CI command failed for unit rust-velnor-workflow with exit status: 100
2026-09-19T23:32:31.3399973Z ##[error]Process completed with exit code 1.
```

### 35475992238 / job 105986931643 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35475992238/job/105986931643

Class: unclassified. Raw SHA256: `5607bfe11ea44ed7b4bf4c4df85b7ceed2171bd4e0c8394e89ac2beaa1c6d8ac`.

```text
2026-09-19T23:38:08.0452775Z ##[error]Process completed with exit code 1.
```

### 35475992238 / job 105986938875 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35475992238/job/105986938875

Class: unclassified. Raw SHA256: `8ae9ec3e0ae93e1773dce3944314ce6425b0743b5df2af0395848bf843899439`.

```text
2026-09-19T23:38:12.7286798Z ##[error]Process completed with exit code 1.
```

### 35515840346 / job 106093233951 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35515840346/job/106093233951

Class: dirty-preview. Raw SHA256: `347a5a55dd3b2cc2abd628f5c67fdd890c0370b426e02517efe0285bb5c5cc16`.

```text
2026-09-20T14:30:48.6367817Z error: failed to run custom build command for `velnor-runner v0.1.277 (/home/runner/work/velnor/velnor/crates/velnor-runner)`
2026-09-20T14:30:48.6413170Z   thread 'main' (18421) panicked at crates/velnor-runner/build.rs:181:9:
2026-09-20T14:31:47.5284203Z ##[error]Process completed with exit code 101.
```

### 35515840346 / job 106093233952 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35515840346/job/106093233952

Class: cross-compiler. Raw SHA256: `41ef238d32918446e7a129567e6b2aecb19d963fef67f7632e041f274bc1716d`.

```text
2026-09-20T14:28:45.3312864Z error: failed to run custom build command for `aws-lc-sys v0.44.0`
2026-09-20T14:28:50.3485708Z error: failed to run custom build command for `openssl-sys v0.9.117`
2026-09-20T14:28:50.4332551Z ##[error]Process completed with exit code 101.
```

### 35479499963 / job 105994646340 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35479499963/job/105994646340

Class: generated-tree;candidate-product. Raw SHA256: `2a93fd77bdb6c29bb077948627902ce36947d4eae9af3cdcaedbad2b69cdf35c`.

```text
2026-09-20T00:44:13.8639612Z error: generated files differ: .github/actionlint.yaml, .github/ci/project.toml, .github/workflows/ci-main.yml, .github/workflows/ci-pr.yml, .github/workflows/ci-runtime-products.yml, .github/workflows/ci-unit-rust.yml, .github/workflows/preview.yml, .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T00:56:09.5266762Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-5075e55195abdaea-Linux-X64
2026-09-20T00:56:09.5275636Z ##[error]Process completed with exit code 1.
```

### 35458464138 / job 105937865590 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35458464138/job/105937865590

Class: generated-tree;candidate-product. Raw SHA256: `8292c7e94e37b207e9f1f9da9e1bea6005bb4326f184fc8a4ed24dc514d838e5`.

```text
2026-09-19T17:33:52.6571090Z error: generated files differ: .github/workflows/ci-unit-rust.yml, .github/workflows/preview.yml, .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-19T17:48:52.3043443Z ##[error]no candidate product velnor-workflow-candidate-d5701a0dc42d1f89-Linux-X64 was published within 15 minutes
2026-09-19T17:48:52.3053567Z ##[error]Process completed with exit code 1.
```

### 35458464138 / job 105940131714 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35458464138/job/105940131714

Class: generated-tree;candidate-product. Raw SHA256: `15a2d2785bc36499366be663b1f6fb2ecebbdf48c20aee78071d3474ceba05cf`.

```text
2026-09-19T17:50:14.7736840Z error: generated files differ: .github/workflows/ci-unit-rust.yml, .github/workflows/preview.yml, .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-19T17:50:16.8572920Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-d5701a0dc42d1f89-Linux-X64
2026-09-19T17:50:16.8580166Z ##[error]Process completed with exit code 1.
```

### 35486269669 / job 106013141964 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35486269669/job/106013141964

Class: generated-tree. Raw SHA256: `1c1e67be4e1f523254a2d3486c0cb1cd3f9f6a575c96d6b8ed56313ec186287c`.

```text
2026-09-20T03:22:46.4233822Z error: generated files differ: .github/actionlint.yaml, .github/workflows/ci-main.yml, .github/workflows/ci-pr.yml, .github/workflows/ci-runtime-products.yml, .github/workflows/ci-unit-bun.yml, .github/workflows/ci-unit-docker.yml, .github/workflows/ci-unit-docs.yml, .github/workflows/ci-unit-opentofu.yml, .github/workflows/ci-unit-rust.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T03:22:46.4257998Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
2026-09-20T03:22:46.4321650Z ##[error]Process completed with exit code 1.
```

### 35486269669 / job 106014240033 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35486269669/job/106014240033

Class: unclassified. Raw SHA256: `25f0de9d57759123637a1c85948f5ed3a2807c1c691c8c22d7912f4f17afb4d6`.

```text
2026-09-20T03:29:02.3609436Z ##[error]Process completed with exit code 1.
```

### 35486269669 / job 106014248666 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35486269669/job/106014248666

Class: unclassified. Raw SHA256: `b309329e5d5b2e0cac64626b1a61f3b54e7eb8d566685ae33f32d0ce1c4466bc`.

```text
2026-09-20T03:29:06.2522348Z ##[error]Process completed with exit code 1.
```

### 33324287457 / job 99292316604 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33324287457/job/99292316604

Class: unclassified. Raw SHA256: `cdb88ad332988ae55695c63ffe0cd3d73f2999d067aba7f7a8073d07b2bc5f7a`.

```text
2026-08-30T17:11:54.5861081Z ##[error]Process completed with exit code 1.
```

### 33324287457 / job 99292331313 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33324287457/job/99292331313

Class: unclassified. Raw SHA256: `ace7647aecbb19a7c6676f66ea228fbd074e99eb885d536a12509199dae8cc1a`.

```text
2026-08-30T17:12:00.8325951Z ##[error]Process completed with exit code 1.
```

### 33324287457 / job 99292524674 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33324287457/job/99292524674

Class: unclassified. Raw SHA256: `b08871ecfe3a6b1c12cd379d4e864c5f721db15108ce13ee945bbbf2d12e03fe`.

```text
2026-08-30T17:13:31.9274778Z ##[error]Process completed with exit code 1.
```

### 33324287457 / job 99292537496 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33324287457/job/99292537496

Class: unclassified. Raw SHA256: `ec5e6f2140aa86373e930a26d10a18122e93c51fe9e4dcb8ce1b7ba2c0cb3ca1`.

```text
2026-08-30T17:13:37.9935679Z ##[error]Process completed with exit code 1.
```

### 35484968706 / job 106009552370 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35484968706/job/106009552370

Class: generated-tree;candidate-product. Raw SHA256: `cc02e1e8ce466076f21fcd1b947844259585b6b78f83056168162c12f31fcbaa`.

```text
2026-09-20T02:49:19.7345120Z error: generated files differ: .github/actionlint.yaml, .github/workflows/ci-main.yml, .github/workflows/ci-pr.yml, .github/workflows/ci-runtime-products.yml, .github/workflows/ci-unit-bun.yml, .github/workflows/ci-unit-docker.yml, .github/workflows/ci-unit-docs.yml, .github/workflows/ci-unit-opentofu.yml, .github/workflows/ci-unit-rust.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T03:04:25.2313993Z ##[error]no candidate product velnor-workflow-candidate-e17c297fa56899ab-Linux-X64 was published within 15 minutes
2026-09-20T03:04:25.2320678Z ##[error]Process completed with exit code 1.
```

### 35484968706 / job 106011339325 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35484968706/job/106011339325

Class: unclassified. Raw SHA256: `e59b00afca11cea3733a932e69c12c2c40d12137fa560cf4cc18e960faf26a9a`.

```text
2026-09-20T03:04:47.3068476Z ##[error]Process completed with exit code 1.
```

### 35484968706 / job 106011381740 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35484968706/job/106011381740

Class: unclassified. Raw SHA256: `de359abb5c3dec0128bd3a096520626b59096cbcfb01049ecdc37325d7352715`.

```text
2026-09-20T03:05:01.2105144Z ##[error]Process completed with exit code 1.
```

### 35499885181 / job 106049644356 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35499885181/job/106049644356

Class: generated-tree;candidate-product. Raw SHA256: `8fde151340ab8eac1176d0714a6e7797821159a1e778acc974c70b72bb7628c5`.

```text
2026-09-20T08:33:45.5394211Z error: generated files differ: .github/actionlint.yaml, .github/ci/project.toml, .github/workflows/ci-main.yml, .github/workflows/ci-pr.yml, .github/workflows/ci-runtime-products.yml, .github/workflows/ci-unit-bun.yml, .github/workflows/ci-unit-docker.yml, .github/workflows/ci-unit-docs.yml, .github/workflows/ci-unit-opentofu.yml, .github/workflows/ci-unit-rust.yml, .github/workflows/preview.yml, .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T08:48:49.6158455Z ##[error]no candidate product velnor-workflow-candidate-52e54c00051de431-Linux-X64 was published within 15 minutes
2026-09-20T08:48:49.6167182Z ##[error]Process completed with exit code 1.
```

### 35499885181 / job 106051546337 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35499885181/job/106051546337

Class: unclassified. Raw SHA256: `6b83e8d052c33563ef1ac3e80b0d843444dc7cd4bc16cc4eb8b504e9f0ff552d`.

```text
2026-09-20T08:48:55.2558124Z ##[error]Process completed with exit code 1.
```

### 35499885181 / job 106051554785 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35499885181/job/106051554785

Class: unclassified. Raw SHA256: `f00eb20cd09d420d36b6851e15cb1413f3207b750519132d9ca6b470fa33257d`.

```text
2026-09-20T08:48:59.4896704Z ##[error]Process completed with exit code 1.
```

### 34844613527 / job 103977415105 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34844613527/job/103977415105

Class: unclassified. Raw SHA256: `9c4c56d9656a65cd0eaf0c251f0f850216ef068fd4ade7e39ee1a6eab234eaa2`.

```text
2026-09-14T12:39:31.3629252Z ##[error]Velnor rejected this job before workflow execution.
```

### 34844613527 / job 103977789957 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34844613527/job/103977789957

Class: unclassified. Raw SHA256: `599aadf35bbe7f73bb8265c94a289692f856cfcd7c7a3fbb7f6fa04b1d3a4b5f`.

```text
2026-09-14T12:40:44.5553494Z ##[error]Velnor rejected this job before workflow execution.
```

### 35522584031 / job 106109110213 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35522584031/job/106109110213

Class: generated-tree;candidate-product. Raw SHA256: `1005d3d2e1c7bfe440bfb59c9c0db705a2196298acca1c653a8b90ed22061a90`.

```text
2026-09-20T16:24:05.8975345Z error: generated files differ: .github/ci/project.toml, .github/workflows/ci-main.yml, .github/workflows/ci-pr.yml, .github/workflows/preview.yml, .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T16:39:10.7533633Z ##[error]no candidate product velnor-workflow-candidate-8881e50b88c80c40-Linux-X64 was published within 15 minutes
2026-09-20T16:39:10.7541930Z ##[error]Process completed with exit code 1.
```

### 35518172603 / job 106097579540 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35518172603/job/106097579540

Class: test-failure. Raw SHA256: `4ed0bf97252e51d456cf4a79c94ddad8a236e6180ddcab85b76a44122abbc1e6`.

```text
2026-09-20T15:05:16.0168367Z     thread 'permit_guard::tests::startup_reconcile_retains_uncertain_attempts_without_teardown_proof' (26790) panicked at crates/velnor-runner/src/permit_guard.rs:747:9:
2026-09-20T15:05:20.6496598Z error: test run failed
2026-09-20T15:05:20.9711972Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-20T15:05:20.9798937Z ##[error]Process completed with exit code 1.
```

### 35518172603 / job 106098339589 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35518172603/job/106098339589

Class: unclassified. Raw SHA256: `628b6416b44a23a8e362f839817393b62c7f8a94ab74b6b7490f829b0ab171ab`.

```text
2026-09-20T15:05:27.8357798Z ##[error]Process completed with exit code 1.
```

### 35518172603 / job 106098353674 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35518172603/job/106098353674

Class: unclassified. Raw SHA256: `9596fff96c5bb6db1714a1c1e8ed096a8e07e175081652be5e8c61e076090223`.

```text
2026-09-20T15:05:32.0512125Z ##[error]Process completed with exit code 1.
```

### 33283639841 / job 99184002838 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33283639841/job/99184002838

Class: unclassified. Raw SHA256: `00d041eabd1571751f1012add90553ef4497b1ad38dfdacbb879cf33eebe16de`.

```text
2026-08-30T00:44:53.8301760Z ##[error]Process completed with exit code 1.
```

### 33283639841 / job 99184013972 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33283639841/job/99184013972

Class: unclassified. Raw SHA256: `6aec91d37b26b9f83dc0b274923ff835bbc1925401f03bbe1ed6e7567432f741`.

```text
2026-08-30T00:44:59.7320966Z ##[error]Process completed with exit code 1.
```

### 33283639841 / job 99184542690 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33283639841/job/99184542690

Class: unclassified. Raw SHA256: `e1e97ab4e622d948a9e3192ee1f03e816af731f95ba6f33a509d701d2bbb69de`.

```text
2026-08-30T00:50:07.2702860Z ##[error]Process completed with exit code 1.
```

### 33283639841 / job 99184558816 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33283639841/job/99184558816

Class: unclassified. Raw SHA256: `604df0b3a02c1b41c30594cdee8cd55d175a6771815524af6dbad6ebc228c6c2`.

```text
2026-08-30T00:50:13.5652949Z ##[error]Process completed with exit code 1.
```

### 33283639841 / job 99185605489 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/33283639841/job/99185605489

Class: unclassified. Raw SHA256: `1c293c71b258487b5e7c69124d03007774b25e713fa9e930c7d5d02d0afb1b47`.

```text
2026-08-30T01:00:21.8239633Z ##[error]Process completed with exit code 1.
```

### 33283639841 / job 99185617874 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/33283639841/job/99185617874

Class: unclassified. Raw SHA256: `1feb5bcad6210953a3d4a601f08d766f1afb7dbff80e0534964c6b79a44ff855`.

```text
2026-08-30T01:00:27.8765869Z ##[error]Process completed with exit code 1.
```

### 33283639841 / job 99186952847 / attempt 4

https://github.com/tailrocks/velnor/actions/runs/33283639841/job/99186952847

Class: unclassified. Raw SHA256: `456e0843a403b53c81f4acb1549aa74612175e69d46268049e681921e3569552`.

```text
2026-08-30T01:12:49.9810431Z ##[error]Process completed with exit code 1.
```

### 33283639841 / job 99186964287 / attempt 4

https://github.com/tailrocks/velnor/actions/runs/33283639841/job/99186964287

Class: unclassified. Raw SHA256: `e8adc2fbeca06bb6c78b43a606f9a832e82fd56f867ba3cbfe1152409ab3f8f1`.

```text
2026-08-30T01:12:56.2028362Z ##[error]Process completed with exit code 1.
```

### 35503026531 / job 106058050767 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35503026531/job/106058050767

Class: candidate-product. Raw SHA256: `8cbfd77d9967ea394ee8727291d098d2d52a067fd247c99b8b05d87a2738786c`.

```text
2026-09-20T09:57:07.7623117Z ##[error]no candidate product velnor-workflow-candidate-ac86a6edcc7b6330-Linux-X64 was published within 15 minutes
2026-09-20T09:57:07.7632373Z ##[error]Process completed with exit code 1.
```

### 32774139975 / job 97581216132 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32774139975/job/97581216132

Class: test-failure. Raw SHA256: `d938baa6c9d935cd99e33c46c6ba90e9a1e47b4711edd126cf06f5bb7335a27c`.

```text
2026-08-24T20:29:17.9469928Z error: No such remote: 'origin'
2026-08-24T20:29:19.0000000Z error: No such remote: 'origin'
2026-08-24T20:32:14.0000000Z     thread 'tests::write_live_evidence_cmd_creates_file' (34708) panicked at crates/velnor-tools/src/main.rs:4712:45:
2026-08-24T20:32:14.0000000Z error: test run failed
```

### 33534742680 / job 99947795378 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33534742680/job/99947795378

Class: unclassified. Raw SHA256: `09c4a555a3cdd65ed952a2edf2e939f61ad70e2d536338467102089b494313a2`.

```text
2026-09-01T17:00:47.2002348Z ##[error]Process completed with exit code 1.
```

### 33534742680 / job 99947839566 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33534742680/job/99947839566

Class: unclassified. Raw SHA256: `ce58590536f1b23ab7fde5c47f93f7022235bf124b4c99f2e35c45a1d56f9f97`.

```text
2026-09-01T17:00:57.5546631Z ##[error]Process completed with exit code 1.
```

### 35475838812 / job 105984857166 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35475838812/job/105984857166

Class: test-failure. Raw SHA256: `29840313266fceb59853591ec8f48b38224136bc3285e5da15bfda2493def8e4`.

```text
2026-09-19T23:23:50.4259835Z     thread 'generic_modules_never_name_a_repository' (15294) panicked at crates/velnor-workflow/tests/generic_surface_literals.rs:239:5:
2026-09-19T23:23:50.4267991Z       left: 5
2026-09-19T23:23:50.4269136Z      right: 4
2026-09-19T23:23:50.5946029Z error: test run failed
2026-09-19T23:23:50.6065904Z error: CI command failed for unit rust-velnor-workflow with exit status: 100
2026-09-19T23:23:50.6128955Z ##[error]Process completed with exit code 1.
```

### 35475838812 / job 105985840375 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35475838812/job/105985840375

Class: unclassified. Raw SHA256: `fecabbd481c036626f4179aafb651f0e2977879ceed8d6e461c09ea73ea17952`.

```text
2026-09-19T23:28:55.8320364Z ##[error]Process completed with exit code 1.
```

### 35475838812 / job 105985851086 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35475838812/job/105985851086

Class: unclassified. Raw SHA256: `d6c52132799e32075ff9a8526b38b874e7b4e75ef7dc4ab9db0143bb08699f0b`.

```text
2026-09-19T23:29:03.0329999Z ##[error]Process completed with exit code 1.
```

### 34039677207 / job 101506729072 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34039677207/job/101506729072

Class: unclassified. Raw SHA256: `70cf52c56e9203f37df7e600c6f922cc06f16b06b9a4fd51957d12b94a63d6de`.

```text
2026-09-06T15:13:00.7895178Z ##[error]Failed to CreateArtifact: Unable to make request: ETIMEDOUT
```

### 32864008215 / job 97854751833 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32864008215/job/97854751833

Class: rust-lint. Raw SHA256: `f526ab10317314252fdce10c5247369a215496644f58e6660cf5808eb45a93d4`.

```text
2026-08-25T15:09:35.9513112Z error: No such remote: 'origin'
2026-08-25T15:09:38.0000000Z error: No such remote: 'origin'
2026-08-25T15:13:35.0000000Z error: unused import: `Path`
2026-08-25T15:13:35.0000000Z error: unused import: `AsyncReadExt`
2026-08-25T15:13:35.0000000Z error: unused import: `AsyncReadExt`
2026-08-25T15:13:35.0000000Z error: variable does not need to be mutable
2026-08-25T15:13:35.0000000Z error: variable does not need to be mutable
2026-08-25T15:13:35.0000000Z error: variable does not need to be mutable
2026-08-25T15:13:35.0000000Z error: variable does not need to be mutable
2026-08-25T15:13:35.0000000Z error: variable does not need to be mutable
2026-08-25T15:13:35.0000000Z error: unused variable: `key`
2026-08-25T15:13:35.0000000Z error: this expression creates a reference which is immediately dereferenced by the compiler
2026-08-25T15:13:35.0000000Z error: this expression creates a reference which is immediately dereferenced by the compiler
2026-08-25T15:13:35.0000000Z error: this expression creates a reference which is immediately dereferenced by the compiler
2026-08-25T15:13:35.0000000Z error: this expression creates a reference which is immediately dereferenced by the compiler
2026-08-25T15:13:35.0000000Z error: this expression creates a reference which is immediately dereferenced by the compiler
2026-08-25T15:13:35.0000000Z error: this expression creates a reference which is immediately dereferenced by the compiler
2026-08-25T15:13:35.0000000Z error: this expression creates a reference which is immediately dereferenced by the compiler
2026-08-25T15:13:35.0000000Z error: the following explicit lifetimes could be elided: 'a
2026-08-25T15:13:35.0000000Z error: could not compile `velnor-runner` (lib) due to 16 previous errors
2026-08-25T15:13:35.0000000Z error: could not compile `velnor-runner` (lib test) due to 15 previous errors
```

### 31697333214 / job 94438583002 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/31697333214/job/94438583002

Class: unclassified. Raw SHA256: `9bb41648607f2e828b9ce8263f7fbcf741c149a339616e524e02bafb26dfe0f8`.

```text
2026-08-13T11:53:40.2550199Z error: No such remote: 'origin'
```

### 31697333214 / job 94443038421 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/31697333214/job/94443038421

Class: unclassified. Raw SHA256: `ef9122302ad5381deb5470114281abd20d62267782faa1d2bd8c337fa407abc8`.

```text
2026-08-13T12:12:05.7024844Z error: No such remote: 'origin'
```

### 33272447886 / job 99153387649 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33272447886/job/99153387649

Class: unclassified. Raw SHA256: `ec9453006842d7f8eab903267c4750d67329e1492e3abb4638d5376468e729fa`.

```text
2026-08-29T20:04:04.7749433Z ##[error]Process completed with exit code 1.
```

### 33272447886 / job 99153398414 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33272447886/job/99153398414

Class: unclassified. Raw SHA256: `c7bb076e58b140cb0a453eb729a652e70d26945d730a1edfacd90535db2b1ed2`.

```text
2026-08-29T20:04:11.6421585Z ##[error]Process completed with exit code 1.
```

### 35477443890 / job 105989051893 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35477443890/job/105989051893

Class: unclassified. Raw SHA256: `ac664ca1d4099c86a1de6b7d49493f7b087fb67ca334da395f13774d23eec7a5`.

```text
2026-09-19T23:58:47.6851113Z error: regeneration with /home/runner/work/_temp/velnor-workflow-runtime-artifact/bin/velnor-workflow-policy failed: error: invalid generation config /home/runner/work/velnor/velnor/.github-gen/velnor-workflow.toml: TOML parse error at line 75, column 1
2026-09-19T23:58:47.6872071Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
2026-09-19T23:58:47.6928945Z ##[error]Process completed with exit code 1.
```

### 35477443890 / job 105990094982 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35477443890/job/105990094982

Class: unclassified. Raw SHA256: `8e38efc407c78aa660efedd3e2da9c0daf117334791d775652ffb02ccc13693e`.

```text
2026-09-20T00:05:42.2933986Z ##[error]Process completed with exit code 1.
```

### 35477443890 / job 105990110727 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35477443890/job/105990110727

Class: unclassified. Raw SHA256: `0394605a921d0e31b1a8c357f8c8887569b47465025b7d9b006d72230df7a103`.

```text
2026-09-20T00:05:47.7131120Z ##[error]Process completed with exit code 1.
```

### 33113892515 / job 98665455382 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33113892515/job/98665455382

Class: unclassified. Raw SHA256: `45d56e40b4b069a7dae0cebe621102d76ac3c075f2890fad16db33bd55fb82db`.

```text
2026-08-27T20:40:35.5315944Z ##[error]Process completed with exit code 1.
```

### 33113892515 / job 98665486458 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33113892515/job/98665486458

Class: unclassified. Raw SHA256: `9fe9b954c2e15d934681a7a6e2b961591e04da47b71e0fbc12949b6f0075a316`.

```text
2026-08-27T20:40:41.9595797Z ##[error]Process completed with exit code 1.
```

### 35520875130 / job 106104648019 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35520875130/job/106104648019

Class: dead-code. Raw SHA256: `fef3d625365676516b7ec35d8de2848a85a65699c835dfe24dd27b27a5e7e40b`.

```text
2026-09-20T15:53:19.7071594Z error: variant `Contended` is never constructed
2026-09-20T15:53:19.7079317Z error: could not compile `velnor-runner` (lib) due to 1 previous error
2026-09-20T15:53:19.7514065Z error: CI command failed for unit rust-velnor-workflow with exit status: 101
2026-09-20T15:53:19.7587559Z ##[error]Process completed with exit code 1.
```

### 35520875130 / job 106104648299 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35520875130/job/106104648299

Class: dead-code. Raw SHA256: `12658674c831508bf9a5fed6f38bc9ce675f33da7f3136763f1b0f1c1df0122b`.

```text
2026-09-20T15:53:08.0395247Z error: variant `Contended` is never constructed
2026-09-20T15:53:08.0404865Z error: could not compile `velnor-runner` (lib) due to 1 previous error
2026-09-20T15:53:08.0806973Z error: CI command failed for unit rust-velnorctl with exit status: 101
2026-09-20T15:53:08.0882053Z ##[error]Process completed with exit code 1.
```

### 35520875130 / job 106104648432 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35520875130/job/106104648432

Class: dead-code. Raw SHA256: `08ae985d7cdf797889b4f7c2b898887d961d947d8ba9d26c8759967a606a229f`.

```text
2026-09-20T15:53:19.7974141Z error: variant `Contended` is never constructed
2026-09-20T15:53:19.7982203Z error: could not compile `velnor-runner` (lib) due to 1 previous error
2026-09-20T15:53:19.8577635Z error: CI command failed for unit rust-velnor-bench with exit status: 101
2026-09-20T15:53:19.8630329Z ##[error]Process completed with exit code 1.
```

### 34048737638 / job 101528745533 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34048737638/job/101528745533

Class: test-failure. Raw SHA256: `4e6250488d0e8d376451f4230d830ee87d9a702c070e6ba38c6eb9a160ed8a45`.

```text
2026-09-06T17:34:29.3537949Z     thread 'execution::cancel::tests::a_microvm_jailer_is_reachable_from_the_fan_out' (4828) panicked at crates/velnor-runner/src/execution/cancel.rs:1663:9:
2026-09-06T17:34:29.3539746Z       left: []
2026-09-06T17:34:29.3540226Z      right: ["pgid:4242"]
2026-09-06T17:34:29.3598397Z error: test run failed
2026-09-06T17:34:29.3733565Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-06T17:34:29.3756617Z ##[error]Process completed with exit code 1.
```

### 34048737638 / job 101529891999 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34048737638/job/101529891999

Class: unclassified. Raw SHA256: `dfb868c84d556790333f446f503cab6040c8f8da787e525d33fd095e10906ca6`.

```text
2026-09-06T17:40:19.7798726Z ##[error]Process completed with exit code 1.
```

### 35470446811 / job 105970341989 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35470446811/job/105970341989

Class: generated-tree;candidate-product. Raw SHA256: `ea7cf5ed0e44c3fd6c626a8152559554dc55a058fb822ed7d395e4b828e8d8b9`.

```text
2026-09-19T21:27:29.5647757Z error: generated files differ: .github/workflows/ci-runtime-products.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-19T21:41:11.8488861Z error: workflow policy failed: trusted-runners
2026-09-19T21:41:11.8497436Z FAIL trusted-runners        1 finding
2026-09-19T21:41:11.8512023Z ##[error]Process completed with exit code 1.
```

### 35473163732 / job 105977722286 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35473163732/job/105977722286

Class: candidate-product. Raw SHA256: `26709b244dcf02671ee63918fce49c4a441e85be3d8f46b1476dbcce00ba0d5e`.

```text
2026-09-19T22:22:59.0109384Z error: invalid generation config /home/runner/work/velnor/velnor/policy-checkout/.github-gen/velnor-workflow.toml: TOML parse error at line 74, column 1
2026-09-19T22:32:35.0292777Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-2e8a45af83e3203d-Linux-X64
2026-09-19T22:32:35.0302489Z ##[error]Process completed with exit code 1.
```

### 35497074131 / job 106041912440 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35497074131/job/106041912440

Class: candidate-product. Raw SHA256: `2285136d8712115fb798aaf5d88169b2505831999e8066aca26d94a25c3a9dc4`.

```text
2026-09-20T07:31:04.7502313Z error: invalid generation config /home/runner/work/velnor/velnor/policy-checkout/.github-gen/velnor-workflow.toml: TOML parse error at line 75, column 1
2026-09-20T07:46:06.9386991Z ##[error]no candidate product velnor-workflow-candidate-7a41bff650a72cf1-Linux-X64 was published within 15 minutes
2026-09-20T07:46:06.9397368Z ##[error]Process completed with exit code 1.
```

### 35472248023 / job 105975230801 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35472248023/job/105975230801

Class: test-failure. Raw SHA256: `5326abd44b795a963d1fb192bf9a8edd16cc2accc18b3f555e4622299fbe9e79`.

```text
2026-09-19T22:07:50.9017969Z     thread 'primitives::release::tests::identity_rows_render_the_pinned_native_surface' (7996) panicked at crates/velnor-workflow/src/primitives/release.rs:5956:9:
2026-09-19T22:07:50.9219209Z error: test run failed
2026-09-19T22:07:50.9327053Z error: CI command failed for unit rust-velnor-workflow with exit status: 100
2026-09-19T22:07:50.9384430Z ##[error]Process completed with exit code 1.
```

### 35472248023 / job 105976473678 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35472248023/job/105976473678

Class: unclassified. Raw SHA256: `8ab18ac4764b4c0fb4df164713afb7d30ba304db787dde3160c0d7fe48bc1e22`.

```text
2026-09-19T22:13:35.4598991Z ##[error]Process completed with exit code 1.
```

### 35472248023 / job 105976482315 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35472248023/job/105976482315

Class: unclassified. Raw SHA256: `107c1c1fa8a2701d77b838b798d813432fe1d562cc8349175b2f0af4e167b9e8`.

```text
2026-09-19T22:13:39.3928444Z ##[error]Process completed with exit code 1.
```

### 32798086625 / job 97653425627 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32798086625/job/97653425627

Class: rust-lint. Raw SHA256: `50e951fda0c1f3d78f2cc89d74a6b36ba298b8d752096f141eb0b964166fba2c`.

```text
2026-08-25T01:34:52.2180046Z error: No such remote: 'origin'
2026-08-25T01:34:54.0000000Z error: No such remote: 'origin'
2026-08-25T01:38:00.0000000Z error: variable does not need to be mutable
2026-08-25T01:38:00.0000000Z error: could not compile `velnor-runner` (lib) due to 1 previous error
2026-08-25T01:38:00.0000000Z error: could not compile `velnor-runner` (lib test) due to 1 previous error
```

### 35290945858 / job 105433496314 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35290945858/job/105433496314

Class: unclassified. Raw SHA256: `521dcdf25816941b4bf724f3ae3fc9cd828efc0d28cfb27def5735e4fac753d8`.

```text
2026-09-18T00:23:18.4165746Z ##[error]Velnor rejected this job before workflow execution.
```

### 35290945858 / job 105433496497 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35290945858/job/105433496497

Class: test-failure. Raw SHA256: `2c585cdb71aed09ff617852dc21269f6c6b7a2a04a8fd7a35a86ad0b9f0865a7`.

```text
2026-09-18T00:25:56.2346904Z     thread 'apt::tests::disagreeing_key_refusal_leaves_no_agent_or_key_residue' (3573) panicked at crates/velnor-workflow/src/apt.rs:6201:9:
2026-09-18T00:25:56.2463542Z error: test run failed
2026-09-18T00:25:56.6277214Z error: CI command failed for unit rust-velnor-workflow with exit status: 100
2026-09-18T00:25:56.6349631Z ##[error]Process completed with exit code 1.
```

### 35290945858 / job 105433496568 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35290945858/job/105433496568

Class: unclassified. Raw SHA256: `60db9ef9ae7bb5d1b912ac6e835789bf56827b9579d7f1de999ee8beebcafa2f`.

```text
2026-09-18T00:23:18.4816765Z ##[error]Velnor rejected this job before workflow execution.
```

### 35290945858 / job 105434309831 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35290945858/job/105434309831

Class: unclassified. Raw SHA256: `2e00c5a32a921a9e9e8e499a5a1371c493779872da335f6d9be0a03f1babcc02`.

```text
2026-09-18T00:27:04.5165596Z ##[error]Process completed with exit code 1.
```

### 35290945858 / job 105434326843 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35290945858/job/105434326843

Class: unclassified. Raw SHA256: `8b223f7f3069bcd62b501090913573c91a759db1c48c9e29eb5f0aaea6ce9c74`.

```text
2026-09-18T00:27:09.1041271Z ##[error]Process completed with exit code 1.
```

### 35290945858 / job 105437695716 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35290945858/job/105437695716

Class: unclassified. Raw SHA256: `48fade5f05d00297b06d28ebcc2d65906c113c8e9a114cff1a1c1603d20fe3e7`.

```text
2026-09-18T00:43:06.6347477Z ##[error]Velnor rejected this job before workflow execution.
```

### 35290945858 / job 105437695974 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35290945858/job/105437695974

Class: test-failure. Raw SHA256: `61632242e1e73e3100be9018b95676d08f150ea4ee6aac6f1349c13dc17cd8ea`.

```text
2026-09-18T00:45:39.6207153Z     thread 'apt::tests::preview_publish_bootstrap_initializes_once' (3744) panicked at crates/velnor-workflow/src/apt.rs:3715:27:
2026-09-18T00:45:39.6826291Z     thread 'apt::tests::preview_publish_strict_keeps_the_shared_tree_and_enforces_order' (4062) panicked at crates/velnor-workflow/src/apt.rs:3715:27:
2026-09-18T00:45:39.7034530Z error: test run failed
2026-09-18T00:45:40.1035893Z error: CI command failed for unit rust-velnor-workflow with exit status: 100
2026-09-18T00:45:40.1098938Z ##[error]Process completed with exit code 1.
```

### 35290945858 / job 105437696059 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35290945858/job/105437696059

Class: unclassified. Raw SHA256: `b2d9a7648b5ab4f7329a5fcb58455ba308dcb6adc7a2b095b3e0a0274ac79484`.

```text
2026-09-18T00:43:06.6687704Z ##[error]Velnor rejected this job before workflow execution.
```

### 35290945858 / job 105438254133 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35290945858/job/105438254133

Class: unclassified. Raw SHA256: `628a8a67d710ead78a5272aba133141aa687ca83d45f5dc86a265e2089cd7bea`.

```text
2026-09-18T00:45:46.6398777Z ##[error]Process completed with exit code 1.
```

### 35290945858 / job 105438275370 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35290945858/job/105438275370

Class: unclassified. Raw SHA256: `0741c62443363cc271e6511300c9185f103b141228251ca7326ab8b35cbc99fd`.

```text
2026-09-18T00:45:53.1467997Z ##[error]Process completed with exit code 1.
```

### 35076390290 / job 104730751020 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35076390290/job/104730751020

Class: unclassified. Raw SHA256: `f72b06b8d4d21637e196d9637e9ab969c27f8427af81f67558da90055eb5da95`.

```text
2026-09-16T08:59:28.2862578Z error: CI command failed for unit docker with exit status: 1
2026-09-16T08:59:28.2926068Z ##[error]Process completed with exit code 1.
```

### 35076390290 / job 104733995067 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35076390290/job/104733995067

Class: unclassified. Raw SHA256: `dc67daaacb7639f7aaafd5e702189198289d5e39f95e0d565f425300d4c5cf09`.

```text
2026-09-16T09:08:42.6097185Z ##[error]Process completed with exit code 1.
```

### 35076390290 / job 104734022116 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35076390290/job/104734022116

Class: unclassified. Raw SHA256: `897673c2f4d66a617bee8a0bfc394ee9130e94dbff87194b8542a77cd53b1cfd`.

```text
2026-09-16T09:08:47.7953377Z ##[error]Process completed with exit code 1.
```

### 32818378790 / job 97712015110 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32818378790/job/97712015110

Class: packaging. Raw SHA256: `e4f553da58de23e0cccc2462eb62aaad3c6cf57ff1455175b10d6d8dddb8240f`.

```text
2026-08-25T06:49:44.2820677Z ##[error]published binary digest != record (amd64)
2026-08-25T06:49:44.2828305Z ##[error]Process completed with exit code 1.
```

### 35049344938 / job 104648785471 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35049344938/job/104648785471

Class: unclassified. Raw SHA256: `983997f3b0546af11b3fd5630b410cf7b9bb2968dcefd6218357d003bd348201`.

```text
2026-09-16T03:01:51.3739327Z ##[error]Process completed with exit code 1.
```

### 35049344938 / job 104648802233 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35049344938/job/104648802233

Class: unclassified. Raw SHA256: `023c6c9a53b9bc28d53784412ea3945311c0f6c97b65e22cb1205ad891acb842`.

```text
2026-09-16T03:01:56.2014892Z ##[error]Process completed with exit code 1.
```

### 35481089696 / job 105998915789 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35481089696/job/105998915789

Class: generated-tree;candidate-product. Raw SHA256: `dc187f5fa8ca36bdd681e271f29ac8a8e8221fedd5273cd745ea0e5d7d8235e3`.

```text
2026-09-20T01:19:35.2730720Z error: generated files differ: .github/actionlint.yaml, .github/workflows/ci-runtime-products.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T01:34:42.9194983Z ##[error]no candidate product velnor-workflow-candidate-946b06a393c7bced-Linux-X64 was published within 15 minutes
2026-09-20T01:34:42.9204229Z ##[error]Process completed with exit code 1.
```

### 35481089696 / job 106000705655 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35481089696/job/106000705655

Class: unclassified. Raw SHA256: `7c91538c08d19e02184aea7baa4da43e770afa1ad7c45c3346a193f5dc01b328`.

```text
2026-09-20T01:34:50.3449413Z ##[error]Process completed with exit code 1.
```

### 35481089696 / job 106000715790 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35481089696/job/106000715790

Class: unclassified. Raw SHA256: `be0ea3c492a3749c2257292d89885a6631899128c46208522488fd915757c7a9`.

```text
2026-09-20T01:34:54.6977871Z ##[error]Process completed with exit code 1.
```

### 34732139219 / job 103656985666 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34732139219/job/103656985666

Class: unclassified. Raw SHA256: `d7bb111ae910b8f9da127b621ecc896a869bc34257226a85d731d30b987d8c01`.

```text
2026-09-13T02:07:37.0000000Z error: CI command failed for unit docker with exit status: 1
```

### 34732139219 / job 103658297501 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34732139219/job/103658297501

Class: unclassified. Raw SHA256: `8ff8ed3feb6615a0f67ca5c7500d081b96a4cc942825cf8c328e37d80476ec41`.

```text
2026-09-13T02:17:46.1501043Z ##[error]Process completed with exit code 1.
```

### 34732139219 / job 103667691884 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34732139219/job/103667691884

Class: unclassified. Raw SHA256: `50a811a7278caf94c8ef54e0f046406767ac2f1066a78227c6b1c9d0330ef528`.

```text
2026-09-13T03:41:24.0000000Z error: CI command failed for unit docker with exit status: 1
```

### 34732139219 / job 103667715097 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34732139219/job/103667715097

Class: unclassified. Raw SHA256: `7648958c30387d5e948010a36f7bdc9c8a4115e87c1b0d07494dcd84674b6dc4`.

```text
2026-09-13T03:41:35.3838642Z ##[error]Process completed with exit code 1.
```

### 34732139219 / job 103669263953 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/34732139219/job/103669263953

Class: unclassified. Raw SHA256: `9e821b8c76ef96a5b622bf1e6d0a2ca2357dbea193fd0f8777af14b927add2e3`.

```text
2026-09-13T03:56:13.0000000Z error: CI command failed for unit docker with exit status: 1
```

### 34732139219 / job 103669285473 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/34732139219/job/103669285473

Class: unclassified. Raw SHA256: `6b3ba2d30af7e6f8795137eed77d0c6903e78b1a84325894f4e749e932bdfe0d`.

```text
2026-09-13T03:56:24.8212919Z ##[error]Process completed with exit code 1.
```

### 35505010001 / job 106063255131 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35505010001/job/106063255131

Class: candidate-product. Raw SHA256: `134966090af1731a7dfff6a15ef663283aee6466f8863d4033faca32f188d132`.

```text
2026-09-20T10:40:30.8993624Z ##[error]no candidate product velnor-workflow-candidate-efb5bd10b0671f3a-Linux-X64 was published within 15 minutes
2026-09-20T10:40:30.9002744Z ##[error]Process completed with exit code 1.
```

### 35473054871 / job 105978126767 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35473054871/job/105978126767

Class: unclassified. Raw SHA256: `9d4222fc82470719b62999254735e9f2e731863af600107bd62a0ce7ba46722b`.

```text
2026-09-19T22:26:13.3999072Z ##[error]no runtime product for revision 9e06bef6da90d7084853d78a5e1fdea31a1d3a5c (closure 4e551b808646444d); the mainline runtime-product publisher builds it after merge
2026-09-19T22:26:13.4002003Z ##[error]Process completed with exit code 1.
```

### 35473054871 / job 105978155750 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35473054871/job/105978155750

Class: unclassified. Raw SHA256: `0736eb1497d9b6bb7fcf80c67b7dfb785619ec30269ff2fcc5460726f0ddd5bf`.

```text
2026-09-19T22:26:19.3662500Z ##[error]Process completed with exit code 1.
```

### 35473054871 / job 105978164090 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35473054871/job/105978164090

Class: unclassified. Raw SHA256: `9c0c262bf3d17a0713e33112443373aad99870b353d60986c2155c6a3042ba56`.

```text
2026-09-19T22:26:23.8721920Z ##[error]Process completed with exit code 1.
```

### 34054859439 / job 101546935693 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34054859439/job/101546935693

Class: unclassified. Raw SHA256: `cc8c98a9dcb51ebf91bbd31a2ac8047c86ea09d15efcfb70773d7f5a437f2e06`.

```text
2026-09-06T19:42:52.0000000Z error: CI command failed for unit docker with exit status: 1
```

### 34054859439 / job 101546935834 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34054859439/job/101546935834

Class: test-failure. Raw SHA256: `1ad7a6b7023fdf3181339781d0c305c7fddd464814eaf7cdb0778fa4fbcce1d8`.

```text
2026-09-06T19:43:32.0000000Z     thread 'supervised_controller_capacity_is_exact_for_one_and_four' (6167) panicked at crates/velnor-runner/tests/node_arch.rs:788:63:
2026-09-06T19:43:32.0000000Z error: test run failed
2026-09-06T19:43:32.0000000Z error: CI command failed for unit rust-velnor-runner with exit status: 100
```

### 34054859439 / job 101546935851 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34054859439/job/101546935851

Class: unclassified. Raw SHA256: `668ee507be9dd4d345ead78a8d2b5381a973850d5e486e8c03f48d63e1c45d88`.

```text
2026-09-06T19:42:25.3554682Z error: could not download file from 'https://static.rust-lang.org/dist/channel-rust-1.98.1.toml' to '/home/runner/.rustup/tmp/6qzsqogt2n8wyety_file.toml': error downloading file: error sending request for url (https://static.rust-lang.org/dist/channel-rust-1.98.1.toml): client error (Connect): Connection reset by peer (os error 104)
2026-09-06T19:42:25.3696414Z ##[error]The process '/home/runner/.local/share/mise/bin/mise' failed with exit code 1
```

### 34054859439 / job 101549088429 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34054859439/job/101549088429

Class: unclassified. Raw SHA256: `fc0e23f0d5f86b1a798bfa5eed5dda272ceb9f320289dd346aba4ab1da8c005d`.

```text
2026-09-06T19:56:36.1750476Z ##[error]Process completed with exit code 1.
```

### 35506627126 / job 106067435910 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35506627126/job/106067435910

Class: generated-tree;candidate-product. Raw SHA256: `7655207f35d1201360e714df8dd476130eabb3c7c055677859b9f4233d1ee661`.

```text
2026-09-20T11:00:49.6854873Z error: generated files differ: .github/ci/project.toml, .github/workflows/ci-main.yml, .github/workflows/ci-pr.yml, .github/workflows/preview.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T11:10:30.7691160Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-7c4454a1aed3d844-Linux-X64
2026-09-20T11:10:30.7700604Z ##[error]Process completed with exit code 1.
```

### 29937763985 / job 88983624047 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/29937763985/job/88983624047

Class: unclassified. Raw SHA256: `f338fe05bbbb08cae74da1f17475beb47d49e5d442c88ca2230f5dd8385ea57d`.

```text
2026-07-22T16:23:20.5406041Z error: No such remote: 'origin'
2026-07-22T16:29:47.0000000Z error: Can't resolve asset: target/aarch64-unknown-linux-gnu/release/velnor-runner (built) -> usr/bin/velnor-runner
```

### 29937763985 / job 88983624135 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/29937763985/job/88983624135

Class: unclassified. Raw SHA256: `9fffef60aa8542db6322b200d162d898cd30c7a5595c793e8a47277241dbb1c7`.

```text
2026-07-22T16:23:21.4223742Z error: No such remote: 'origin'
2026-07-22T16:29:47.0000000Z error: Can't resolve asset: target/x86_64-unknown-linux-gnu/release/velnor-runner (built) -> usr/bin/velnor-runner
```

### 29937763985 / job 88985278348 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/29937763985/job/88985278348

Class: unclassified. Raw SHA256: `e2f51db19f5c11999a54855b1c57d9736a1e85465c636e8cbed3e91bd2e8c792`.

```text
2026-07-22T16:30:06.0000000Z error: No such remote: 'origin'
```

### 29937763985 / job 88986974940 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/29937763985/job/88986974940

Class: unclassified. Raw SHA256: `f8cc9182cb50e78598976850866499507cda53ec84601f4319eb67dd3ec9c850`.

```text
2026-07-22T16:36:47.0000000Z error: No such remote: 'origin'
```

### 35475920808 / job 105985038787 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35475920808/job/105985038787

Class: generated-tree. Raw SHA256: `685813745f2c24f1579c924637f3ec355b19c50e4e867ae98dc356749cbba6db`.

```text
2026-09-19T23:22:13.7425882Z error: workflow policy failed: generated-tree
2026-09-19T23:22:13.7437489Z FAIL generated-tree         the tree differs from the render of velnor-workflow at 0dc79895ff1c5e88be7c3822c437e1c5b5282e12
2026-09-19T23:22:13.7453446Z ##[error]Process completed with exit code 1.
```

### 31721940760 / job 94520830616 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/31721940760/job/94520830616

Class: unclassified. Raw SHA256: `cf19cd33bae14c40950708d4dd127733593b4b36246c1f1adcfcd97a2ec1eb7d`.

```text
2026-08-13T16:41:32.3640206Z error: No such remote: 'origin'
```

### 31721940760 / job 94521870638 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/31721940760/job/94521870638

Class: unclassified. Raw SHA256: `6c45013dc774a279346ed598e2ec78c14d429951f3f87b7ad631b6eb58a55ff6`.

```text
2026-08-13T16:45:16.0331069Z ##[error]Process completed with exit code 1.
```

### 31721940760 / job 94521906163 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/31721940760/job/94521906163

Class: unclassified. Raw SHA256: `1c9bb7a97bce56d4d02401024f7981b7e2cb85daf10e304b38531bb96e545146`.

```text
2026-08-13T16:45:22.1540500Z ##[error]Process completed with exit code 1.
```

### 35490581231 / job 106025471748 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35490581231/job/106025471748

Class: rust-lint. Raw SHA256: `d54ad95ebc9526c3a57fcca71fac1dfe1c90e0bb7877f331657fee29eb905f61`.

```text
2026-09-20T05:11:53.8748007Z error: unused imports: `SystemTime` and `UNIX_EPOCH`
2026-09-20T05:11:53.8751372Z error: could not compile `velnor-workflow` (lib) due to 1 previous error
2026-09-20T05:11:56.7292384Z error: CI command failed for unit rust-velnor-workflow with exit status: 101
2026-09-20T05:11:56.7347021Z ##[error]Process completed with exit code 1.
```

### 35490581231 / job 106026513598 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35490581231/job/106026513598

Class: unclassified. Raw SHA256: `afbbf5fe6cb9c25b1f9c07a7a824f296be6a6f5aa0e121dc6af2ebb9c6bd2069`.

```text
2026-09-20T05:17:03.2635094Z ##[error]Process completed with exit code 1.
```

### 35490581231 / job 106026524352 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35490581231/job/106026524352

Class: unclassified. Raw SHA256: `9601069e6633dd7476f38009e41e5d6eee578cb85ef67d782e05e1befc774ee9`.

```text
2026-09-20T05:17:08.3993146Z ##[error]Process completed with exit code 1.
```

### 34475567997 / job 102865435531 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34475567997/job/102865435531

Class: test-failure. Raw SHA256: `17443d87755d4e2c3a379e432699c7660c97bb2af43c82c850fcbcbb57971bc6`.

```text
2026-09-10T12:18:49.5407595Z     thread 'execution::cancel::tests::a_target_registered_after_cancellation_is_terminated_immediately' (4645) panicked at crates/velnor-runner/src/execution/cancel.rs:1709:9:
2026-09-10T12:18:49.5409388Z       left: []
2026-09-10T12:18:49.5409901Z      right: ["pgid:4242"]
2026-09-10T12:18:49.5481010Z error: test run failed
2026-09-10T12:18:49.5626929Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-10T12:18:49.5644153Z ##[error]Process completed with exit code 1.
```

### 34475567997 / job 102866862398 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34475567997/job/102866862398

Class: unclassified. Raw SHA256: `e05dd66abdd4abdb9681c8a805b2ee461ca91ba1dedfc36172e4123813ee3f9e`.

```text
2026-09-10T12:18:55.9243716Z ##[error]Process completed with exit code 1.
```

### 35485592032 / job 106011245076 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35485592032/job/106011245076

Class: generated-tree;candidate-product. Raw SHA256: `151edbc95a2a2fa5d1d0ac4980eb5b4c621915e29896b7a06534876969fd18de`.

```text
2026-09-20T03:03:51.1863110Z error: generated files differ: .github/actionlint.yaml, .github/workflows/ci-main.yml, .github/workflows/ci-pr.yml, .github/workflows/ci-runtime-products.yml, .github/workflows/ci-unit-bun.yml, .github/workflows/ci-unit-docker.yml, .github/workflows/ci-unit-docs.yml, .github/workflows/ci-unit-opentofu.yml, .github/workflows/ci-unit-rust.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T03:08:17.6073849Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-6c0b2d4905196801-Linux-X64
2026-09-20T03:08:17.6082393Z ##[error]Process completed with exit code 1.
```

### 33107424480 / job 98640945892 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33107424480/job/98640945892

Class: unclassified. Raw SHA256: `48e48a6b070111f7cfb4e3fbca3ca32ee569f794239a36b06c26813da6fbea81`.

```text
2026-08-27T19:15:49.1596533Z ##[error]Process completed with exit code 92.
```

### 35483017222 / job 106004131793 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35483017222/job/106004131793

Class: unclassified. Raw SHA256: `72882900ca94799ea0d92633cd2d3c85c28ddd00958f907e1aa0b986ce5a4fd2`.

```text
2026-09-20T02:09:30.1097125Z error: case-sensitive file extension comparison
2026-09-20T02:09:30.1103164Z error: could not compile `velnor-workflow` (lib) due to 1 previous error
2026-09-20T02:09:37.9928735Z error: could not compile `velnor-workflow` (lib test) due to 1 previous error
2026-09-20T02:09:38.0480821Z error: CI command failed for unit rust-velnor-workflow with exit status: 101
2026-09-20T02:09:38.0534682Z ##[error]Process completed with exit code 1.
```

### 35483017222 / job 106005096068 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35483017222/job/106005096068

Class: unclassified. Raw SHA256: `d95fbb35a07dc68648983b86a68384dc01a840b9d83f64fe0fbbd702407b92b9`.

```text
2026-09-20T02:12:21.9840628Z ##[error]Process completed with exit code 1.
```

### 35483017222 / job 106005109017 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35483017222/job/106005109017

Class: unclassified. Raw SHA256: `6d41a723d45e3ab1ca913ba8f2777647b4c68d1cc81dd37ed83738f63a824e37`.

```text
2026-09-20T02:12:27.5556400Z ##[error]Process completed with exit code 1.
```

### 35502093992 / job 106055553349 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35502093992/job/106055553349

Class: generated-tree. Raw SHA256: `95db2562228d5862ab868460a1524ceca4b40ad5e96e29744cf8346ec7404768`.

```text
2026-09-20T09:21:56.5552769Z error: workflow policy failed: generated-tree
2026-09-20T09:21:56.5559079Z FAIL generated-tree         the tree differs from the render of velnor-workflow at 0dc79895ff1c5e88be7c3822c437e1c5b5282e12
2026-09-20T09:21:56.5589255Z ##[error]Process completed with exit code 1.
```

### 33347246920 / job 99353618577 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33347246920/job/99353618577

Class: rust-lint. Raw SHA256: `5a5a7fa5a8eb976032c3ab25ef4512c5a9c7bda584eb9223f1b7aa81caa44b59`.

```text
2026-08-31T01:31:30.5500151Z error[E0133]: dereference of raw pointer is unsafe and requires unsafe block
2026-08-31T01:31:30.5979881Z error[E0133]: call to unsafe function `libc::__errno_location` is unsafe and requires unsafe block
2026-08-31T01:31:31.1690050Z error: this `if` statement can be collapsed
2026-08-31T01:31:31.1963207Z error: this `if` statement can be collapsed
2026-08-31T01:31:31.1973635Z error: this `if` statement can be collapsed
2026-08-31T01:31:31.5819627Z error: could not compile `velnor-tools` (bin "velnor-tools") due to 5 previous errors
2026-08-31T01:31:32.2773194Z error: could not compile `velnor-tools` (bin "velnor-tools" test) due to 5 previous errors
2026-08-31T01:31:32.6981732Z ##[error]Process completed with exit code 101.
```

### 33347246920 / job 99355303643 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33347246920/job/99355303643

Class: unclassified. Raw SHA256: `3ab6aa91d5421bb6d120e6079b66593ef3f03196dadf934813c576a1b35ec24f`.

```text
2026-08-31T01:31:39.7813600Z ##[error]Process completed with exit code 1.
```

### 33347246920 / job 99355316330 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33347246920/job/99355316330

Class: unclassified. Raw SHA256: `9fb50ca6bb5d532eaa647259f2042f43ac0c5a8ccd2c0a5626b04e7d5a8bac9a`.

```text
2026-08-31T01:31:44.8467000Z ##[error]Process completed with exit code 1.
```

### 33347246920 / job 99356107118 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33347246920/job/99356107118

Class: rust-lint. Raw SHA256: `ca706db7166b0eb92842286a04f4689d3ad26ba82112abbc42089a1d18d0ae81`.

```text
2026-08-31T01:46:04.5470870Z error[E0133]: dereference of raw pointer is unsafe and requires unsafe block
2026-08-31T01:46:04.5950960Z error[E0133]: call to unsafe function `libc::__errno_location` is unsafe and requires unsafe block
2026-08-31T01:46:05.0360812Z error: this `if` statement can be collapsed
2026-08-31T01:46:05.0586002Z error: this `if` statement can be collapsed
2026-08-31T01:46:05.0594937Z error: this `if` statement can be collapsed
2026-08-31T01:46:05.3228323Z error: could not compile `velnor-tools` (bin "velnor-tools") due to 5 previous errors
2026-08-31T01:46:05.8190912Z error: could not compile `velnor-tools` (bin "velnor-tools" test) due to 5 previous errors
2026-08-31T01:46:05.9903608Z ##[error]Process completed with exit code 101.
```

### 33347246920 / job 99357383776 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33347246920/job/99357383776

Class: unclassified. Raw SHA256: `ff72d556bdfded8adfa8fe12cfdfabd892e1f9e0ad75db36628f569f07e30e4e`.

```text
2026-08-31T01:46:13.8227924Z ##[error]Process completed with exit code 1.
```

### 33347246920 / job 99357397673 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33347246920/job/99357397673

Class: unclassified. Raw SHA256: `9bbd0c53750b2257642cda761b2ce76686114a45ab7da7be27963cdad8de9393`.

```text
2026-08-31T01:46:18.8981592Z ##[error]Process completed with exit code 1.
```

### 33324604753 / job 99292415677 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33324604753/job/99292415677

Class: unclassified. Raw SHA256: `8c3cf9da7f3b97ed0b336293f526c63826d1392b03a985eb3d0e71673a636abb`.

```text
2026-08-30T17:12:41.0286166Z ##[error]Process completed with exit code 1.
```

### 33324604753 / job 99292426384 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33324604753/job/99292426384

Class: unclassified. Raw SHA256: `eb404c5a37f073ae4dede199b684217caa750dc35ddd0e13b038143c3b8abd22`.

```text
2026-08-30T17:12:45.7616710Z ##[error]Process completed with exit code 1.
```

### 33324604753 / job 99292792998 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33324604753/job/99292792998

Class: unclassified. Raw SHA256: `f1ec43d7497b15b24442c960a2bf69ddcc8379e574d288915f1be61e1df673e7`.

```text
2026-08-30T17:15:37.0613922Z ##[error]Process completed with exit code 1.
```

### 33324604753 / job 99292803493 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33324604753/job/99292803493

Class: unclassified. Raw SHA256: `41aa4891251ae65c035212144fa04b841cb8893dbb8627c5a1b49af7c3c788ca`.

```text
2026-08-30T17:15:43.4911223Z ##[error]Process completed with exit code 1.
```

### 35461272354 / job 105945464189 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35461272354/job/105945464189

Class: generated-tree;candidate-product. Raw SHA256: `d5200bf1e38b43f6287f02a51f6c3e8f68c20f5ab13a419f1e18fb9d6bebb9d4`.

```text
2026-09-19T18:28:02.9078667Z error: generated files differ: .github/workflows/ci-unit-rust.yml, .github/workflows/preview.yml, .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-19T18:43:07.0037542Z ##[error]no candidate product velnor-workflow-candidate-5887398768e1af80-Linux-X64 was published within 15 minutes
2026-09-19T18:43:07.0046098Z ##[error]Process completed with exit code 1.
```

### 35482338198 / job 106002289770 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35482338198/job/106002289770

Class: candidate-product. Raw SHA256: `5805cbc76ee9e47726e0ccde7792e184164bc81f46aad17a7c53fd422172eebf`.

```text
2026-09-20T01:54:57.7696988Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-946b06a393c7bced-Linux-X64
2026-09-20T01:54:57.7707080Z ##[error]Process completed with exit code 1.
```

### 35465277979 / job 105956394145 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35465277979/job/105956394145

Class: unclassified. Raw SHA256: `dd86c783ad07cf9b443470713336cb4d738ae6c4b9ac249bba4cef88d8d15f0e`.

```text
2026-09-19T19:48:31.8027810Z error: case-sensitive file extension comparison
2026-09-19T19:48:31.8039840Z error: case-sensitive file extension comparison
2026-09-19T19:48:31.8046551Z error: this function has too many lines (143/100)
2026-09-19T19:48:31.8052559Z error: could not compile `velnor-workflow` (lib) due to 3 previous errors
2026-09-19T19:48:34.7800179Z error: CI command failed for unit rust-velnor-workflow with exit status: 101
2026-09-19T19:48:34.7870990Z ##[error]Process completed with exit code 1.
```

### 35465277979 / job 105957610643 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35465277979/job/105957610643

Class: unclassified. Raw SHA256: `c582b475daf79116b0d9fc5152bf6b6ae00556308a1de9c73224002b3c0cf3b6`.

```text
2026-09-19T19:53:54.9958596Z ##[error]Process completed with exit code 1.
```

### 35465277979 / job 105957623498 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35465277979/job/105957623498

Class: unclassified. Raw SHA256: `740fbd6f9b46935053a100ecdc88606c052f5675ec652ec6b49e6a5908eef3d4`.

```text
2026-09-19T19:53:59.9008120Z ##[error]Process completed with exit code 1.
```

### 35520255573 / job 106102991421 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35520255573/job/106102991421

Class: generated-tree. Raw SHA256: `0faaac740c0d5e547aee5320e530b2dc33291dfc34ba9164fced3a62b9809dd4`.

```text
2026-09-20T15:39:26.7250437Z error: workflow policy failed: generated-tree
2026-09-20T15:39:26.7256636Z FAIL generated-tree         the tree differs from the render of velnor-workflow at 38dbf85e0bbf278cee3ec39ab90a9acc9b5b67a9
2026-09-20T15:39:26.7275979Z ##[error]Process completed with exit code 1.
```

### 32812768337 / job 97696838129 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32812768337/job/97696838129

Class: unclassified. Raw SHA256: `aa6d970b275e3fc6cc65c3435f610bdb2a465c9afbe89305ce060ebb58a9d120`.

```text
2026-08-25T05:34:19.1972756Z ##[error]Process completed with exit code 1.
```

### 32830311665 / job 97748833843 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32830311665/job/97748833843

Class: packaging. Raw SHA256: `9d471d0b7f02a383a505a033b0bd25735a72c52974c5b78b9a8f8b4501dfc0fe`.

```text
2026-08-25T09:20:34.0021627Z ##[error]deb still ships the deleted velnor-runner binary
2026-08-25T09:20:34.0030422Z ##[error]Process completed with exit code 1.
```

### 32830311665 / job 97748834118 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32830311665/job/97748834118

Class: packaging. Raw SHA256: `add96d0052e22b3cd483bea39045c5db7472e8052418c6077d527d794c2bbab7`.

```text
2026-08-25T09:20:07.4433812Z ##[error]deb still ships the deleted velnor-runner binary
2026-08-25T09:20:07.4443029Z ##[error]Process completed with exit code 1.
```

### 35483850769 / job 106006464411 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35483850769/job/106006464411

Class: test-failure. Raw SHA256: `276f799b78eda4af1a40be4d5eaf2bc537ae471a269f8b56a32149241df7a6d1`.

```text
2026-09-20T02:29:13.1374834Z     thread '<unnamed>' (28843) panicked at crates/velnor-runner/tests/scaleset_allocator.rs:141:88:
2026-09-20T02:29:13.1377235Z     thread '<unnamed>' (28845) panicked at crates/velnor-runner/tests/scaleset_allocator.rs:141:88:
2026-09-20T02:29:13.1379314Z     thread '<unnamed>' (28838) panicked at crates/velnor-runner/tests/scaleset_allocator.rs:131:69:
2026-09-20T02:29:13.1381289Z     thread 'occupancy_never_exceeds_n_under_churn' (28833) panicked at crates/velnor-runner/tests/scaleset_allocator.rs:154:23:
2026-09-20T02:29:18.8889405Z error: test run failed
2026-09-20T02:29:19.5137020Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-20T02:29:19.5220988Z ##[error]Process completed with exit code 1.
```

### 35483850769 / job 106007277459 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35483850769/job/106007277459

Class: unclassified. Raw SHA256: `a61f888ec687444a13794687b66e19ee9be1d6d7059b60043725cf527b1628be`.

```text
2026-09-20T02:30:17.8367471Z ##[error]Process completed with exit code 1.
```

### 35483850769 / job 106007291912 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35483850769/job/106007291912

Class: unclassified. Raw SHA256: `baacc43ed27a50da3331cc31c517bf379c0bcf0f96436959294e8a46551fbdaa`.

```text
2026-09-20T02:30:23.4788365Z ##[error]Process completed with exit code 1.
```

### 32786781088 / job 97622105675 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32786781088/job/97622105675

Class: unclassified. Raw SHA256: `b49427c803c141b42d7a0612490d71325d70309c14ef6f24f957f900eb47690c`.

```text
2026-08-24T23:01:42.9627149Z ##[error]Process completed with exit code 1.
```

### 32786781088 / job 97622134058 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32786781088/job/97622134058

Class: unclassified. Raw SHA256: `888218d77211b76c919355ec77411cbb857b8e07ac4d537b5ad0d6a00f352723`.

```text
2026-08-24T23:01:49.2379482Z ##[error]Process completed with exit code 1.
```

### 35515212764 / job 106089882058 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35515212764/job/106089882058

Class: candidate-product. Raw SHA256: `2cb3bea72ebd990d84ccf2df24a52e31d41471d7ff2e0596e4a21e7110b36b44`.

```text
2026-09-20T14:16:37.1473206Z ##[error]no candidate product velnor-workflow-candidate-9f41d591b590b438-Linux-X64 was published within 15 minutes
2026-09-20T14:16:37.1481468Z ##[error]Process completed with exit code 1.
```

### 35475035422 / job 105982739730 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35475035422/job/105982739730

Class: unclassified. Raw SHA256: `e0dfa4f6875118f5ca50f6c326e45a88206e4986a1338698f89afc9a7490e5fd`.

```text
2026-09-19T23:06:35.3456123Z error: regeneration with /home/runner/work/_temp/velnor-workflow-runtime-artifact/bin/velnor-workflow-policy failed: error: invalid generation config /home/runner/work/velnor/velnor/.github-gen/velnor-workflow.toml: TOML parse error at line 75, column 1
2026-09-19T23:06:35.3498219Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
2026-09-19T23:06:35.3585284Z ##[error]Process completed with exit code 1.
```

### 35475035422 / job 105983834457 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35475035422/job/105983834457

Class: unclassified. Raw SHA256: `ae25052e43a03400a0d4b8e859620d2d904c82e6246c2719a3960ef5688ea73e`.

```text
2026-09-19T23:12:25.4829618Z ##[error]Process completed with exit code 1.
```

### 35475035422 / job 105983844493 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35475035422/job/105983844493

Class: unclassified. Raw SHA256: `a1dbb1f18b9cc7fffe18f55861769ebb121016a0b510ef1de9df64c2ee22db13`.

```text
2026-09-19T23:12:30.5499436Z ##[error]Process completed with exit code 1.
```

### 33347662040 / job 99355759086 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33347662040/job/99355759086

Class: unclassified. Raw SHA256: `c28bebbcde4d7c53d565342782a3fe385e5a4a4b9893dc98987fc5a960762044`.

```text
2026-08-31T01:34:54.4054228Z ##[error]Process completed with exit code 1.
```

### 33347662040 / job 99355773351 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33347662040/job/99355773351

Class: unclassified. Raw SHA256: `05cb6512a84e6106c92a6ac0fa70f5c2988408f5bb6cd9e4dccb0aadd011027d`.

```text
2026-08-31T01:35:00.6641554Z ##[error]Process completed with exit code 1.
```

### 33347662040 / job 99357008046 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33347662040/job/99357008046

Class: unclassified. Raw SHA256: `5947777c2455649ce5e002da76877fbd580dcc888ef15328c203a0d96205bfb2`.

```text
2026-08-31T01:43:36.1906852Z ##[error]Process completed with exit code 1.
```

### 33347662040 / job 99357022379 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33347662040/job/99357022379

Class: unclassified. Raw SHA256: `5c312bbbe6de7535b1f89c1433143eb7a7144a3f8469189bd7576b05c2652b8f`.

```text
2026-08-31T01:43:42.9980829Z ##[error]Process completed with exit code 1.
```

### 33347662040 / job 99361274953 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/33347662040/job/99361274953

Class: unclassified. Raw SHA256: `fdbea4ed28e10472cad190595ec0892199931453e644c19309b29521940353cc`.

```text
2026-08-31T02:13:03.2311547Z ##[error]Process completed with exit code 1.
```

### 33347662040 / job 99361288012 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/33347662040/job/99361288012

Class: unclassified. Raw SHA256: `9d24780d40ffdf9e177998da7662e485992d94f9827f2245fb7364469478b2d8`.

```text
2026-08-31T02:13:08.3072293Z ##[error]Process completed with exit code 1.
```

### 35066494455 / job 104699877173 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35066494455/job/104699877173

Class: unclassified. Raw SHA256: `b0e078b423ce02c7af2d764f4c2c523e4519dbf405928a41bec9be0e54d0f42f`.

```text
2026-09-16T07:10:02.0000000Z error: CI command failed for unit docker with exit status: 1
```

### 35066494455 / job 104702162606 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35066494455/job/104702162606

Class: unclassified. Raw SHA256: `4a24b0559d2add23b9a98600fb12437e9697979650c216ec1f54afdc2e9c44b2`.

```text
2026-09-16T07:18:32.7408509Z ##[error]Process completed with exit code 1.
```

### 35066494455 / job 104702194549 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35066494455/job/104702194549

Class: unclassified. Raw SHA256: `31f3b1f215799f0bb5e7efb73540cfcd582ba1fc7676348963f9afdcfd5ef3e0`.

```text
2026-09-16T07:18:38.6334419Z ##[error]Process completed with exit code 1.
```

### 35041695268 / job 104623445239 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35041695268/job/104623445239

Class: unclassified. Raw SHA256: `2da1aab0cf08092b95bab2bd01cc7d53120f3c4b626df3a100eeb72fabbbf07f`.

```text
2026-09-16T00:54:31.8843373Z ##[error]Velnor rejected this job before workflow execution.
```

### 35041695268 / job 104623485631 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35041695268/job/104623485631

Class: unclassified. Raw SHA256: `194a54ef13a50c4f29aeb74e772904ef8a6e2fc77bdccab7232743adaad16aed`.

```text
2026-09-16T00:54:43.6883670Z ##[error]Velnor rejected this job before workflow execution.
```

### 35041695268 / job 104623545648 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35041695268/job/104623545648

Class: unclassified. Raw SHA256: `2d10096fdc92c0dae279a50cef96993bcf14bf528d3e9aa34b153f16b28e87c9`.

```text
2026-09-16T00:55:00.8343060Z ##[error]Velnor rejected this job before workflow execution.
```

### 35041695268 / job 104623599621 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35041695268/job/104623599621

Class: unclassified. Raw SHA256: `7ab58928b82996864d71aeaf66f4121ed2e5f7ea9e6e50fa8264379cd3860f9f`.

```text
2026-09-16T00:55:16.4579560Z ##[error]Velnor rejected this job before workflow execution.
```

### 35041695268 / job 104623838669 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35041695268/job/104623838669

Class: unclassified. Raw SHA256: `955eff6376144ba96708c993aad6e9b38f76b70e75bb7eb7d4dc0cc4f0b13aaa`.

```text
2026-09-16T00:56:28.8273581Z ##[error]Velnor rejected this job before workflow execution.
```

### 35041695268 / job 104625116132 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35041695268/job/104625116132

Class: unclassified. Raw SHA256: `c0542ee71d23dfe0b4c2d1115dd76dd7939c638f683f1fa4fdfa4cb1d59c1584`.

```text
2026-09-16T01:02:34.2169482Z ##[error]Process completed with exit code 1.
```

### 35041695268 / job 104625133615 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35041695268/job/104625133615

Class: unclassified. Raw SHA256: `705d9bd6388b6f1ae4bf381bb3d074bd9e4d7e4da11529285f8550da0d298e3c`.

```text
2026-09-16T01:02:41.5334212Z ##[error]Process completed with exit code 1.
```

### 35041695268 / job 104625520238 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35041695268/job/104625520238

Class: unclassified. Raw SHA256: `7c314948b1ca8c6cef315b446f33b879d9340d59ab4d7104e4bf06d4cf302951`.

```text
2026-09-16T01:04:29.9023911Z ##[error]Velnor rejected this job before workflow execution.
```

### 35041695268 / job 104625819084 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35041695268/job/104625819084

Class: unclassified. Raw SHA256: `4f0759c7751c35c5a3a56dd611dbc4a420ed76446147e2614108fdf3f773f358`.

```text
2026-09-16T01:05:54.9491778Z ##[error]Velnor rejected this job before workflow execution.
```

### 35041695268 / job 104625879513 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35041695268/job/104625879513

Class: unclassified. Raw SHA256: `1a64e341592ca36167ae017b8534f9bb3e7d922a58413c6881ea2cd998486d21`.

```text
2026-09-16T01:06:13.4656950Z ##[error]Process completed with exit code 1.
```

### 35041695268 / job 104625897062 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35041695268/job/104625897062

Class: unclassified. Raw SHA256: `1db6fab1edbff0b7806057c705a88791da15c9ced8bf19c60d4596d453a25390`.

```text
2026-09-16T01:06:19.8306345Z ##[error]Process completed with exit code 1.
```

### 33997691477 / job 101391312753 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33997691477/job/101391312753

Class: test-failure. Raw SHA256: `c92786d9685b1b0790e8d73a418c5efc72a6db5f8590331f517655c7fef54955`.

```text
2026-09-05T23:14:57.3935058Z     thread 'execution::cancel::tests::a_microvm_jailer_is_reachable_from_the_fan_out' (64940) panicked at crates/velnor-runner/src/execution/cancel.rs:1658:9:
2026-09-05T23:14:57.3936301Z       left: []
2026-09-05T23:14:57.3936666Z      right: ["pgid:4242"]
2026-09-05T23:14:57.4003639Z error: test run failed
2026-09-05T23:14:57.4017206Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-05T23:14:57.4035037Z ##[error]Process completed with exit code 1.
```

### 35489726952 / job 106022509212 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35489726952/job/106022509212

Class: rust-lint. Raw SHA256: `37d640be9a3afde123e765f306e18cf895d98c3745aa865f6502c4ae30184454`.

```text
2026-09-20T04:44:02.9202854Z error: unused imports: `SystemTime` and `UNIX_EPOCH`
2026-09-20T04:44:02.9210243Z error: could not compile `velnor-workflow` (lib) due to 1 previous error
2026-09-20T04:44:05.8572563Z error: CI command failed for unit rust-velnor-workflow with exit status: 101
2026-09-20T04:44:05.8634708Z ##[error]Process completed with exit code 1.
```

### 35489726952 / job 106023472513 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35489726952/job/106023472513

Class: unclassified. Raw SHA256: `52e9be10d032397129bf6ef292d53ab2fecce31a7b8579e0227e9b0e39c7d897`.

```text
2026-09-20T04:49:30.0273979Z ##[error]Process completed with exit code 1.
```

### 35489726952 / job 106023480352 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35489726952/job/106023480352

Class: unclassified. Raw SHA256: `5d6167ba544e46e48d010e0ba92a53a64ca4516c78850c90469e2477622199a6`.

```text
2026-09-20T04:49:34.0215670Z ##[error]Process completed with exit code 1.
```

### 35473163640 / job 105977761979 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35473163640/job/105977761979

Class: unclassified. Raw SHA256: `014866fbbe85eafde451978fdabcb508a52798605d3b640f6c207651013dc250`.

```text
2026-09-19T22:25:12.8000605Z error: regeneration with /home/runner/work/_temp/velnor-workflow-runtime-artifact/bin/velnor-workflow-policy failed: error: invalid generation config /home/runner/work/velnor/velnor/.github-gen/velnor-workflow.toml: TOML parse error at line 74, column 1
2026-09-19T22:25:12.8025695Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
2026-09-19T22:25:12.8092329Z ##[error]Process completed with exit code 1.
```

### 35473163640 / job 105978904813 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35473163640/job/105978904813

Class: unclassified. Raw SHA256: `c957032fca5cbd185dfc608f6676ba8001b74fa986aad5a6e8904ec57f0101de`.

```text
2026-09-19T22:32:18.5618162Z ##[error]Process completed with exit code 1.
```

### 35473163640 / job 105978915266 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35473163640/job/105978915266

Class: unclassified. Raw SHA256: `0b1f5f5bf4cfd50e413c24ae2e49e20fcb203bd8373b66c2b3cb8d7ad3984b25`.

```text
2026-09-19T22:32:23.0941006Z ##[error]Process completed with exit code 1.
```

### 35466800154 / job 105960559130 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35466800154/job/105960559130

Class: generated-tree. Raw SHA256: `9a6d5fb95bf3179ca7b560eda897c2a7c40db0d9b44bcf9d241b44bd4782380f`.

```text
2026-09-19T20:18:32.7417843Z error: generated files differ: .github/workflows/ci-unit-rust.yml, .github/workflows/preview.yml, .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-19T20:18:32.7797380Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
2026-09-19T20:18:32.7859293Z ##[error]Process completed with exit code 1.
```

### 35466800154 / job 105960559156 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35466800154/job/105960559156

Class: test-failure. Raw SHA256: `fd3ca664c26a1e210f0ef77355989a04c54c149d0fa3a14d61fd86bf504b832d`.

```text
2026-09-19T20:20:45.2897447Z     thread 'manifest::tests::release_workflow_action_refs_are_compiled_into_the_manifest' (25918) panicked at crates/velnor-runner/src/manifest.rs:2079:13:
2026-09-19T20:20:45.2990123Z error: test run failed
2026-09-19T20:20:46.3471681Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-19T20:20:46.3560449Z ##[error]Process completed with exit code 1.
```

### 35466800154 / job 105961348920 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35466800154/job/105961348920

Class: unclassified. Raw SHA256: `77720d2dab96c727d9ff18bf37d2d0f9c29f8a718c4f6fbfda8ba974616f4ea3`.

```text
2026-09-19T20:20:52.3504349Z ##[error]Process completed with exit code 1.
```

### 35466800154 / job 105961365574 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35466800154/job/105961365574

Class: unclassified. Raw SHA256: `22e5d1efa553c298be8a545771813b39d0a95d4a3832c8d48943532fff41e540`.

```text
2026-09-19T20:21:34.7760573Z ##[error]Process completed with exit code 1.
```

### 35488746252 / job 106019807295 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35488746252/job/106019807295

Class: generated-tree;candidate-product. Raw SHA256: `424a38dd9750aeaf16f31d18dd67b0a29ce197ae137ab3df27fa60b7c50cfbca`.

```text
2026-09-20T04:25:23.9847032Z error: workflow policy failed: generated-tree
2026-09-20T04:25:23.9853378Z FAIL generated-tree         could not regenerate the tree with velnor-workflow at 325719f1e05d3d46322c9fd3eeb9ad545e175638
2026-09-20T04:25:23.9871415Z ##[error]Process completed with exit code 1.
```

### 35490606803 / job 106024930819 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35490606803/job/106024930819

Class: test-failure. Raw SHA256: `213b1ef1f00893317f7a9fcb3aa0203d1ecb0fc42769c0864387013a78e3431a`.

```text
2026-09-20T05:07:21.5854437Z     thread 'an_unknown_event_stops_generation' (34700) panicked at crates/velnor-workflow/tests/scheduled_check_profiles.rs:331:5:
2026-09-20T05:07:21.6342979Z error: test run failed
2026-09-20T05:07:22.0511014Z error: CI command failed for unit rust-velnor-workflow with exit status: 100
2026-09-20T05:07:22.0561834Z ##[error]Process completed with exit code 1.
```

### 35490606803 / job 106025943912 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35490606803/job/106025943912

Class: unclassified. Raw SHA256: `f1b67f1b1ed532cfd065049cd88aa397c71b9f02dc368e985534c100290b7cfe`.

```text
2026-09-20T05:11:55.2580520Z ##[error]Process completed with exit code 1.
```

### 35490606803 / job 106025953241 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35490606803/job/106025953241

Class: unclassified. Raw SHA256: `182425b74bca5f11c7e56bd5706ec7e9bcb22c63b1dc170eeb1e1f092d531cef`.

```text
2026-09-20T05:11:59.9699964Z ##[error]Process completed with exit code 1.
```

### 35472247973 / job 105975202161 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35472247973/job/105975202161

Class: generated-tree;candidate-product. Raw SHA256: `a3f9ea3159ad2deb844d8f9f86ffb6d7341696d8fc278eafe17f7c5d6397f0cc`.

```text
2026-09-19T22:04:25.2966821Z error: generated files differ: .github/workflows/preview.yml, .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-19T22:13:55.2326012Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-c99a402b2893537c-Linux-X64
2026-09-19T22:13:55.2332521Z ##[error]Process completed with exit code 1.
```

### 29844702274 / job 88682534026 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/29844702274/job/88682534026

Class: unclassified. Raw SHA256: `085dae2aa42af8f651799f2c449d75e4411a6168de9711356a9d3e4a8c4c4bb1`.

```text
2026-07-21T15:37:03.0000000Z error: No such remote: 'origin'
```

### 35191259124 / job 105104121488 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35191259124/job/105104121488

Class: unclassified. Raw SHA256: `343fef0bc4bcc21673e521efe6a49ddd8dc5e22612ca8f6063978a8377d779ee`.

```text
2026-09-17T06:45:42.9650974Z ##[error]no runtime product for revision 12b2570072a6294395c87ddea2b785750adfc3ed (closure 4ef63457fa892a18); the mainline runtime-product publisher builds it after merge
2026-09-17T06:45:42.9655008Z ##[error]Process completed with exit code 1.
```

### 35191259124 / job 105104172584 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35191259124/job/105104172584

Class: unclassified. Raw SHA256: `30f27c361a5e40a9787eb9d4d9af1eccf8ae3e4f10bc29e743d174809f477799`.

```text
2026-09-17T06:45:48.1221351Z ##[error]Process completed with exit code 1.
```

### 35191259124 / job 105104189645 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35191259124/job/105104189645

Class: unclassified. Raw SHA256: `bbd6bf112b9137cf2fbad02ff44dcfb57d3e23b6229492e29fc40cbc2660d2c3`.

```text
2026-09-17T06:45:53.2154551Z ##[error]Process completed with exit code 1.
```

### 35191259124 / job 105106469458 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35191259124/job/105106469458

Class: unclassified. Raw SHA256: `0b3c246abf5640ff7d619b0ea241d15340659b9b625dc9753e369fe6dfcf3637`.

```text
2026-09-17T06:55:18.1101312Z ##[error]Velnor rejected this job before workflow execution.
```

### 35191259124 / job 105106469480 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35191259124/job/105106469480

Class: unclassified. Raw SHA256: `9cb9c67f04cbca881161fa9b7731d1d1bb66ed0ceb5e5e4315ee5e2c77454526`.

```text
2026-09-17T06:55:30.0597758Z ##[error]Velnor rejected this job before workflow execution.
```

### 35191259124 / job 105106469515 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35191259124/job/105106469515

Class: unclassified. Raw SHA256: `6b7833103de0c1a9de820ecfe8ec26ed396978572eb2987bd0dc604dd5f89fbc`.

```text
2026-09-17T06:55:18.0099053Z ##[error]Velnor rejected this job before workflow execution.
```

### 35191259124 / job 105106469845 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35191259124/job/105106469845

Class: unclassified. Raw SHA256: `e1ccf95e2268f1592fcdbaf89a0138209c699bbf0f83ef272213f81ae132b607`.

```text
2026-09-17T06:55:18.0681682Z ##[error]Velnor rejected this job before workflow execution.
```

### 35191259124 / job 105106469944 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35191259124/job/105106469944

Class: unclassified. Raw SHA256: `b83aae8c941839c2d287cf012399d7f8cfac04a88e78ac39069435511c9dab0c`.

```text
2026-09-17T06:55:30.0524767Z ##[error]Velnor rejected this job before workflow execution.
```

### 35191259124 / job 105107613170 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35191259124/job/105107613170

Class: unclassified. Raw SHA256: `ca0ce07fc9629131d5c247b56c060cccd67c8ef0c094c09c2ba368c2dd57e178`.

```text
2026-09-17T06:59:59.4370190Z ##[error]Process completed with exit code 1.
```

### 35191259124 / job 105107639888 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35191259124/job/105107639888

Class: unclassified. Raw SHA256: `e8b5ab8e12251924c03330353bc835a7e6bdc82da699f1a729a5d01aaecdff79`.

```text
2026-09-17T07:00:05.6467877Z ##[error]Process completed with exit code 1.
```

### 35487938941 / job 106017677895 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35487938941/job/106017677895

Class: generated-tree. Raw SHA256: `a41ec052810f466a19ba838760427f3d03656c493e3cdd1c0de9029c92e860ce`.

```text
2026-09-20T04:00:13.6526939Z error: generated files match but generation inputs changed: scan input changed from 3a91fbc407f94101 to d423c214e43dc929 in .github/ci/.github-actions-generator-state; regenerate to record the current generation inputs
2026-09-20T04:00:13.6551202Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
2026-09-20T04:00:13.6616072Z ##[error]Process completed with exit code 1.
```

### 35487938941 / job 106018700076 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35487938941/job/106018700076

Class: unclassified. Raw SHA256: `dcdef00df0be6c8e8da5b3d7d76c873003dd4b37f150f17ad5f4feee123f97d6`.

```text
2026-09-20T04:07:34.9454843Z ##[error]Process completed with exit code 1.
```

### 35487938941 / job 106018709887 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35487938941/job/106018709887

Class: unclassified. Raw SHA256: `d66663592cd3336cdf568717b0552ea82373076ccb59ae5bba1de38f57b9f1c2`.

```text
2026-09-20T04:07:39.8033633Z ##[error]Process completed with exit code 1.
```

### 35445033591 / job 105902386777 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35445033591/job/105902386777

Class: generated-tree;candidate-product. Raw SHA256: `fc3702044e3388d79d996fe3b3b29d3004c561ff1d9ad1933c7e4d6bf1edeab7`.

```text
2026-09-19T13:11:58.8473458Z error: generated files differ: .github/ci/project.toml, .github/workflows/ci-main.yml, .github/workflows/ci-pr.yml, .github/workflows/ci-unit-rust.yml, .github/workflows/preview.yml, .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-19T13:26:58.4732583Z ##[error]no candidate product velnor-workflow-candidate-128ec58bb341e639-Linux-X64 was published within 15 minutes
2026-09-19T13:26:58.4742602Z ##[error]Process completed with exit code 1.
```

### 32830300665 / job 97747729759 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32830300665/job/97747729759

Class: packaging. Raw SHA256: `23a4500c9963e83ccc0bde90732485c3215159512847cb6941a890526a8eca6f`.

```text
2026-08-25T09:16:12.6806158Z ##[error]deb still ships the deleted velnor-runner binary
2026-08-25T09:16:12.6817000Z ##[error]Process completed with exit code 1.
```

### 32830300665 / job 97747729803 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32830300665/job/97747729803

Class: packaging. Raw SHA256: `26963ffb2f432a272df27ac1ed96f30cb68229239acdd9c07449922fee0f99a9`.

```text
2026-08-25T09:16:37.3232158Z ##[error]deb still ships the deleted velnor-runner binary
2026-08-25T09:16:37.3241216Z ##[error]Process completed with exit code 1.
```

### 34857550192 / job 104020912434 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34857550192/job/104020912434

Class: unclassified. Raw SHA256: `7f1dbbc84d4fc4542a84751c614e3d4bc74ca674b84985583f7a45d2e855c079`.

```text
2026-09-14T14:44:14.8034807Z ##[error]Velnor rejected this job before workflow execution.
```

### 35191256269 / job 105104109210 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35191256269/job/105104109210

Class: candidate-product. Raw SHA256: `2c9b9b3f90280d388b3ade367ab9eb0175156107248926f0af7f4215195ca870`.

```text
2026-09-17T06:45:58.2015700Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-975a4abef15fc3e1-Linux-X64
2026-09-17T06:45:58.2022699Z ##[error]Process completed with exit code 1.
```

### 35087503480 / job 104766756993 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35087503480/job/104766756993

Class: unclassified. Raw SHA256: `b5d2f89e1eda4b999b8de3d40d1bdc9f4bdc37259bba60cdfbb78f9e013175aa`.

```text
2026-09-16T10:59:41.4752453Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
2026-09-16T10:59:41.4820851Z ##[error]Process completed with exit code 1.
```

### 35087503480 / job 104767815272 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35087503480/job/104767815272

Class: unclassified. Raw SHA256: `0b9d9eea8bc9a2499b78ed750e5118e7ffeb34b8788e08571ca87ce5cae21402`.

```text
2026-09-16T11:02:30.0000000Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
```

### 35087503480 / job 104769180931 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35087503480/job/104769180931

Class: unclassified. Raw SHA256: `9da1f213e88fbed716261aadc543ee7fd23c221e8d84204d4636a8cd554e19cc`.

```text
2026-09-16T11:10:09.5049262Z ##[error]Process completed with exit code 1.
```

### 35087503480 / job 104770127620 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35087503480/job/104770127620

Class: unclassified. Raw SHA256: `24c8f243ed1e79b2cf80cf5b537489b26a65d3ea2a7599dae5e9d9a6dc5aa274`.

```text
2026-09-16T11:12:39.6551807Z ##[error]Process completed with exit code 1.
```

### 35087503480 / job 104771378485 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35087503480/job/104771378485

Class: unclassified. Raw SHA256: `69eab0600cac2cfad67beacbbf35c288f83324a7b227e548b73d001bca8a14af`.

```text
2026-09-16T11:17:58.6356916Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
2026-09-16T11:17:58.6439395Z ##[error]Process completed with exit code 1.
```

### 35087503480 / job 104771386125 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35087503480/job/104771386125

Class: unclassified. Raw SHA256: `79ec89bf5e04f5f9160c58354775899cc85bf8fe57bfbd06bf3a388d46d70090`.

```text
2026-09-16T11:15:41.0000000Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
```

### 35087503480 / job 104772384780 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35087503480/job/104772384780

Class: unclassified. Raw SHA256: `f07e6c04307bed04aa975f4eb7ee9ead1e0227cce627d66b39579db541b4b891`.

```text
2026-09-16T11:23:45.2070165Z ##[error]Process completed with exit code 1.
```

### 35087503480 / job 104774057986 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35087503480/job/104774057986

Class: unclassified. Raw SHA256: `d27f2936122c7a7ba0cc2b0798fdd75158a3da0f01b02309b8864d00d3ea1f9e`.

```text
2026-09-16T11:32:22.0684319Z ##[error]Process completed with exit code 1.
```

### 35478969299 / job 105993432750 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35478969299/job/105993432750

Class: test-failure. Raw SHA256: `1b8fa369ad64905192132b9815e74c89a246d4d2738115a4ab3e081d0d100f7e`.

```text
2026-09-20T00:38:49.6338269Z     thread 'manifest::tests::compiled_manifest_is_version_fourteen_and_structurally_immutable' (26054) panicked at crates/velnor-runner/src/manifest.rs:1960:9:
2026-09-20T00:38:49.6340832Z       left: 15
2026-09-20T00:38:49.6341534Z      right: 14
2026-09-20T00:38:49.6795450Z error: test run failed
2026-09-20T00:38:50.0197602Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-20T00:38:50.0277359Z ##[error]Process completed with exit code 1.
```

### 35478969299 / job 105993432800 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35478969299/job/105993432800

Class: test-failure. Raw SHA256: `3aab0c822d612c42cccb2ce9ca1efdc1f12ffe41a367f78a5a14bbf1583291bc`.

```text
2026-09-20T00:39:40.6000559Z     thread 'primitives::release::tests::default_rows_render_the_legacy_release_surface' (27276) panicked at crates/velnor-workflow/src/primitives/release.rs:5818:9:
2026-09-20T00:39:40.6067357Z error: test run failed
2026-09-20T00:39:41.1494717Z error: CI command failed for unit rust-velnor-workflow with exit status: 100
2026-09-20T00:39:41.1560608Z ##[error]Process completed with exit code 1.
```

### 35478969299 / job 105994366240 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35478969299/job/105994366240

Class: unclassified. Raw SHA256: `65b21baeea6913b986a51bd9c320a94eb2356a9209522e031f6a0c538d37219f`.

```text
2026-09-20T00:41:08.6889859Z ##[error]Process completed with exit code 1.
```

### 35478969299 / job 105994375565 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35478969299/job/105994375565

Class: unclassified. Raw SHA256: `351cf8da6fd87f2db5855e9ea1bfb18ce5b10aaedebb2f9dadaf705e0e64b2ea`.

```text
2026-09-20T00:41:13.0780933Z ##[error]Process completed with exit code 1.
```

### 35492229748 / job 106029030391 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35492229748/job/106029030391

Class: generated-tree;candidate-product. Raw SHA256: `bf4d0ba2f698b1dc9b1c3051013a1b40d07d46f2e3e0699ce318cbf7b8735704`.

```text
2026-09-20T05:49:33.3120409Z error: workflow policy failed: generated-tree
2026-09-20T05:49:33.3126283Z FAIL generated-tree         could not regenerate the tree with velnor-workflow at 325719f1e05d3d46322c9fd3eeb9ad545e175638
2026-09-20T05:49:33.3145292Z ##[error]Process completed with exit code 1.
```

### 34745867993 / job 103693815198 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34745867993/job/103693815198

Class: test-failure. Raw SHA256: `1f0f03602d06c6d7e8f089970cdcf897fc718f6b9737f71bd3757cf32d90d01c`.

```text
2026-09-13T07:45:35.0000000Z     thread '<unnamed>' (773) panicked at crates/velnor-control/src/store/mod.rs:1129:73:
2026-09-13T07:45:35.0000000Z     thread 'store::tests::five_concurrent_daemons_migrate_read_write_without_corruption' (708) panicked at crates/velnor-control/src/store/mod.rs:1161:31:
2026-09-13T07:45:35.0000000Z error: test run failed
2026-09-13T07:45:35.0000000Z error: CI command failed for unit rust-velnor-control with exit status: 100
```

### 34745867993 / job 103694545054 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34745867993/job/103694545054

Class: unclassified. Raw SHA256: `2395e63ed92c20d96048cb2e417c41f646085217805de468b2897cd06b56a5b2`.

```text
2026-09-13T07:50:53.9822879Z ##[error]Process completed with exit code 1.
```

### 34745867993 / job 103697887284 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34745867993/job/103697887284

Class: test-failure. Raw SHA256: `bdaa57d43acb011ba934e645001d1fb281c6955a67230a37095a440148f17e21`.

```text
2026-09-13T08:25:19.0000000Z     thread 'store::retention::tests::large_terminal_ancestry_converges_in_bounded_exact_chunks' (566) panicked at crates/velnor-control/src/store/retention.rs:3342:51:
2026-09-13T08:25:19.0000000Z error: test run failed
2026-09-13T08:25:19.0000000Z error: CI command failed for unit rust-velnor-control with exit status: 100
```

### 34745867993 / job 103698404343 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34745867993/job/103698404343

Class: unclassified. Raw SHA256: `d74483c178b12ca644b6a29cbf5de41e6af50017548db711e9266fd84d1cd770`.

```text
2026-09-13T08:25:30.9721205Z ##[error]Process completed with exit code 1.
```

### 32866518369 / job 97864295012 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32866518369/job/97864295012

Class: rust-lint. Raw SHA256: `434105eccef81243df6adce0220fd2824c0d30b35d0b859e105d9c1256832767`.

```text
2026-08-25T15:37:09.6889716Z error: No such remote: 'origin'
2026-08-25T15:37:21.0000000Z error: No such remote: 'origin'
2026-08-25T15:43:37.0000000Z error: unused import: `JoinSet`
2026-08-25T15:43:37.0000000Z error: could not compile `velnor-runner` (lib) due to 1 previous error
2026-08-25T15:43:37.0000000Z error: could not compile `velnor-runner` (lib test) due to 1 previous error
```

### 35485124588 / job 106009997331 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35485124588/job/106009997331

Class: generated-tree;candidate-product. Raw SHA256: `053bb2f833c7a0cdb237ec497817590216da18dd836d05c1cca64e7e927fb5ef`.

```text
2026-09-20T02:53:05.1065924Z error: generated files differ: .github/actionlint.yaml, .github/workflows/ci-main.yml, .github/workflows/ci-pr.yml, .github/workflows/ci-runtime-products.yml, .github/workflows/ci-unit-bun.yml, .github/workflows/ci-unit-docker.yml, .github/workflows/ci-unit-docs.yml, .github/workflows/ci-unit-opentofu.yml, .github/workflows/ci-unit-rust.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T02:58:01.0431279Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-5d507b16c10b4c1d-Linux-X64
2026-09-20T02:58:01.0441412Z ##[error]Process completed with exit code 1.
```

### 35481211642 / job 105999269772 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35481211642/job/105999269772

Class: generated-tree;candidate-product. Raw SHA256: `1943eecdc99d73d7844a2ae36e09a8cb6a7bcdac70e46911faefa741a72f263f`.

```text
2026-09-20T01:22:35.6458914Z error: generated files differ: .github/actionlint.yaml, .github/workflows/ci-runtime-products.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T01:37:39.9757581Z ##[error]no candidate product velnor-workflow-candidate-cff9beb3f3b32c14-Linux-X64 was published within 15 minutes
2026-09-20T01:37:39.9762909Z ##[error]Process completed with exit code 1.
```

### 31700426640 / job 94448003510 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/31700426640/job/94448003510

Class: unclassified. Raw SHA256: `10de6d90255628b12ea04ea62f97d82d83e02913b272129d27a385f581a76534`.

```text
2026-08-13T12:31:31.3122234Z ##[error]Process completed with exit code 1.
```

### 31700426640 / job 94448027600 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/31700426640/job/94448027600

Class: unclassified. Raw SHA256: `daccd37ce4815beca27f333441dfd24680659f4dabdd0a153c63691f9236cb6d`.

```text
2026-08-13T12:31:36.6578377Z ##[error]Process completed with exit code 1.
```

### 31700426640 / job 94491793939 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/31700426640/job/94491793939

Class: unclassified. Raw SHA256: `e0ba2c116a1a66a619e9ca1122c417ec8e7fc52b00107829131cf00c4f28dbc9`.

```text
2026-08-13T15:04:00.0458495Z error: No such remote: 'origin'
```

### 31700426640 / job 94492807811 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/31700426640/job/94492807811

Class: unclassified. Raw SHA256: `0caa78bbe56630992f2396e0793f7cbbf0c786df8054af68c94373c8242da390`.

```text
2026-08-13T15:07:06.5832434Z ##[error]Process completed with exit code 1.
```

### 31700426640 / job 94492835108 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/31700426640/job/94492835108

Class: unclassified. Raw SHA256: `a4e70dd9c41ce6327233444cc5f0787f30d25c20cf547aa4cec78010620eeb23`.

```text
2026-08-13T15:07:11.3092063Z ##[error]Process completed with exit code 1.
```

### 35473905533 / job 105979702186 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35473905533/job/105979702186

Class: generated-tree;candidate-product. Raw SHA256: `3c50f2214cb3060ba6165f1ae965849bc7c77a348b6646bfc4e3a771c3de8db9`.

```text
2026-09-19T22:38:37.4154452Z error: generated files match but generation inputs changed: scan input changed from 8d96315cc857133b to f1f9ff652d60f12c in .github/ci/.github-actions-generator-state; regenerate to record the current generation inputs
2026-09-19T22:48:23.3860986Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-4089a8d0c08edcb1-Linux-X64
2026-09-19T22:48:23.3870189Z ##[error]Process completed with exit code 1.
```

### 35483489289 / job 106005422506 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35483489289/job/106005422506

Class: generated-tree;candidate-product. Raw SHA256: `616a412476618cbea4839cad0e622e2a087f77a7a6bf30602786970d15663f52`.

```text
2026-09-20T02:19:57.2429666Z error: workflow policy failed: generated-tree
2026-09-20T02:19:57.2439001Z FAIL generated-tree         could not regenerate the tree with velnor-workflow at 325719f1e05d3d46322c9fd3eeb9ad545e175638
2026-09-20T02:19:57.2456158Z ##[error]Process completed with exit code 1.
```

### 33342433323 / job 99340902344 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33342433323/job/99340902344

Class: unclassified. Raw SHA256: `285545329c0d2d0fcc9c8da1e82a4b2812fda08b2c1ec4bf0839c6fb4200c649`.

```text
2026-08-30T23:45:07.7039254Z ##[error]Process completed with exit code 1.
```

### 33342433323 / job 99340911173 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33342433323/job/99340911173

Class: unclassified. Raw SHA256: `99be666dfcfbe43633d66da5367d0f1d461e37fb4b2550945ef5ea6f3b2bf501`.

```text
2026-08-30T23:45:12.6208010Z ##[error]Process completed with exit code 1.
```

### 33342433323 / job 99341900890 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33342433323/job/99341900890

Class: unclassified. Raw SHA256: `5d8de60cc6a51863e44d73815c6ee19acb43a2743f8ce9b62ed87ffc372df9eb`.

```text
2026-08-30T23:53:47.3251379Z ##[error]Process completed with exit code 1.
```

### 33342433323 / job 99341912270 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33342433323/job/99341912270

Class: unclassified. Raw SHA256: `0deaefbf31180ae370758472d10711e138fd7cc3f89e0afb86aecae6dcf7e1df`.

```text
2026-08-30T23:53:52.9811813Z ##[error]Process completed with exit code 1.
```

### 34919484162 / job 104225491845 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34919484162/job/104225491845

Class: unclassified. Raw SHA256: `3292175adf39a4b01f389b17f52ab77c5abd2c7693d49988e0240c644800e4df`.

```text
2026-09-15T02:06:50.3530747Z ##[error]Unable to download artifact(s): Failed to ListArtifacts: Received non-retryable error: Failed request: (403) Forbidden: Error from intermediary with HTTP status code 403 "Forbidden"
```

### 34919484162 / job 104225492572 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34919484162/job/104225492572

Class: unclassified. Raw SHA256: `cc1fa28e5cd406ff8e1ccd0877ba15136c2c8d5dd09cd1a56ce0055f06308f23`.

```text
2026-09-15T02:06:49.9045954Z ##[error]Unable to download artifact(s): Failed to ListArtifacts: Received non-retryable error: Failed request: (403) Forbidden: Error from intermediary with HTTP status code 403 "Forbidden"
```

### 34919484162 / job 104236537526 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34919484162/job/104236537526

Class: unclassified. Raw SHA256: `ef1d4730482df8c5ce44ff8dea29c869bad5e2b849374f55948e2d6d90f9d7f7`.

```text
2026-09-15T03:03:23.3933741Z ##[error]Process completed with exit code 1.
```

### 34919484162 / job 104236563154 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34919484162/job/104236563154

Class: unclassified. Raw SHA256: `002ced8585f3cd80e95ee009ed63a91c7eb05ea8eb2b0f8e4db3a2a9d93d8527`.

```text
2026-09-15T03:03:28.8688891Z ##[error]Process completed with exit code 1.
```

### 32826462429 / job 97737125048 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32826462429/job/97737125048

Class: unclassified. Raw SHA256: `60c042ef39057997d9242ee75c35b538398fce667ed5e708699b626a93579c63`.

```text
2026-08-25T08:30:57.3281316Z ##[error]Process completed with exit code 1.
```

### 32826462429 / job 97737149459 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32826462429/job/97737149459

Class: unclassified. Raw SHA256: `62c4a9776521c0ee5c16bffa8cd60ec0f67ab943299fa3b9a48f1b1116d136cf`.

```text
2026-08-25T08:31:02.5236279Z ##[error]Process completed with exit code 1.
```

### 34711777475 / job 103608893278 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34711777475/job/103608893278

Class: unclassified. Raw SHA256: `5c8e16c24bc139696be5e2cb4dd36b164b075dfb1c9d788467c21d009ab91ca5`.

```text
2026-09-12T19:31:57.3322405Z ##[error]Process completed with exit code 1.
```

### 35156666243 / job 104997633812 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35156666243/job/104997633812

Class: unclassified. Raw SHA256: `ecd3037bdbaa51fadf2346e81238cc94c575c51ab50b19b8c5d367509c48d9b8`.

```text
2026-09-16T22:14:48.8222981Z ##[error]no runtime product for revision a70d5bdbdde6a3c5b815897ae2825969da47d6c5 (closure fd45efac853b6570); the mainline runtime-product publisher builds it after merge
2026-09-16T22:14:48.8226473Z ##[error]Process completed with exit code 1.
```

### 35497921459 / job 106044302264 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35497921459/job/106044302264

Class: generated-tree;candidate-product. Raw SHA256: `e9f3eec191107332a65dc28da6dc5f399217268abe5cc7817edf9ec5c566cbe9`.

```text
2026-09-20T07:50:07.4224100Z error: generated files differ: .github/actionlint.yaml, .github/workflows/ci-main.yml, .github/workflows/ci-pr.yml, .github/workflows/ci-runtime-products.yml, .github/workflows/ci-unit-bun.yml, .github/workflows/ci-unit-docker.yml, .github/workflows/ci-unit-docs.yml, .github/workflows/ci-unit-opentofu.yml, .github/workflows/ci-unit-rust.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T08:05:14.4850244Z ##[error]no candidate product velnor-workflow-candidate-310397af17b12801-Linux-X64 was published within 15 minutes
2026-09-20T08:05:14.4856421Z ##[error]Process completed with exit code 1.
```

### 35497921459 / job 106046121670 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35497921459/job/106046121670

Class: unclassified. Raw SHA256: `a5e30433082003392898e563cf60d9e62a2e0aa7912a6e8b85b92e122d1fd8ca`.

```text
2026-09-20T08:05:21.4659295Z ##[error]Process completed with exit code 1.
```

### 35497921459 / job 106046132141 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35497921459/job/106046132141

Class: unclassified. Raw SHA256: `d9b61159bbf34e57a274b895cfffc095ebf5ee6cf1af0e86df2e1f858396f053`.

```text
2026-09-20T08:05:25.4373809Z ##[error]Process completed with exit code 1.
```

### 35046368486 / job 104639945003 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35046368486/job/104639945003

Class: unclassified. Raw SHA256: `2e7f80b86ce8d7d58ae26d4835b7fc40de6b8ca3025f39cfdad0af505855198a`.

```text
2026-09-16T02:16:27.5759494Z ##[error]Process completed with exit code 1.
```

### 35046368486 / job 104639961016 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35046368486/job/104639961016

Class: unclassified. Raw SHA256: `d35f4d237a64b4b8bb8f6604f9db2075565a9f05972957ddb42bf730edfc81ca`.

```text
2026-09-16T02:16:31.7951430Z ##[error]Process completed with exit code 1.
```

### 35046368486 / job 104640779884 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35046368486/job/104640779884

Class: unclassified. Raw SHA256: `5f3c3290a37e8211808adcdc80718b45e3e239e4043745db8da9f390720630fd`.

```text
2026-09-16T02:20:38.3462462Z ##[error]Process completed with exit code 1.
```

### 35046368486 / job 104640794942 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35046368486/job/104640794942

Class: unclassified. Raw SHA256: `54e0683f65d56645cccde1c87aecaed00683f7bcce9bbdf1b1ddbf1ed94d96fa`.

```text
2026-09-16T02:20:42.2431177Z ##[error]Process completed with exit code 1.
```

### 35475991201 / job 105985233621 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35475991201/job/105985233621

Class: generated-tree;candidate-product. Raw SHA256: `461d0cf52d0815c25eb7896b60ae72544401986692b618856bb2ba82f97b8337`.

```text
2026-09-19T23:24:07.0833329Z error: generated files differ: .github/actionlint.yaml, .github/workflows/ci-runtime-products.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-19T23:38:21.5659139Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-44080cae6ffe61cf-Linux-X64
2026-09-19T23:38:21.5666936Z ##[error]Process completed with exit code 1.
```

### 31715849028 / job 94500280464 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/31715849028/job/94500280464

Class: unclassified. Raw SHA256: `0bcd47b366ddbd0ab3764121787163d7fab4b6a71aaab6ade2df2d8933ef9ae3`.

```text
2026-08-13T15:31:31.0308170Z error: No such remote: 'origin'
```

### 31715849028 / job 94501155497 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/31715849028/job/94501155497

Class: unclassified. Raw SHA256: `df57de72398f346d7d8b8dd45369b64423adc19715939f6b563f860edf96d01d`.

```text
2026-08-13T15:34:29.4452512Z ##[error]Process completed with exit code 1.
```

### 31715849028 / job 94501187783 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/31715849028/job/94501187783

Class: unclassified. Raw SHA256: `9f9dd7a2c8fb1b9381d5d82b0c8a49bc75f44b84945361cf8cc4c2145e5f8e79`.

```text
2026-08-13T15:34:36.1691556Z ##[error]Process completed with exit code 1.
```

### 31715849028 / job 94513433748 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/31715849028/job/94513433748

Class: unclassified. Raw SHA256: `fbd0d9f7e8c17d4cc7622a16a0098e6ecb9b94398f88b713d03e9e24d5b69279`.

```text
2026-08-13T16:15:36.4345562Z error: No such remote: 'origin'
```

### 31715849028 / job 94514315012 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/31715849028/job/94514315012

Class: unclassified. Raw SHA256: `816c09b2ce9d718c6bb4db3f1a53d0cdb0fdc3d309e559f8ae41e2641c2e3692`.

```text
2026-08-13T16:18:38.5235790Z ##[error]Process completed with exit code 1.
```

### 31715849028 / job 94514343518 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/31715849028/job/94514343518

Class: unclassified. Raw SHA256: `1d0e8c677d5e6e27a02b7bdfbe2474eb8299a6b94a88c058ca3cc14c7d5c69a8`.

```text
2026-08-13T16:18:43.8526995Z ##[error]Process completed with exit code 1.
```

### 31715849028 / job 94515159789 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/31715849028/job/94515159789

Class: unclassified. Raw SHA256: `a0d8f6d6a71ede77ee46db7a5775942249d8fb35522348e8af26873344d65590`.

```text
2026-08-13T16:21:32.6044269Z error: No such remote: 'origin'
```

### 31715849028 / job 94516026788 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/31715849028/job/94516026788

Class: unclassified. Raw SHA256: `c44c645a8b5f232a5d8e73101f115dd873e36bf06d4886e26a6c9e74e2759be7`.

```text
2026-08-13T16:24:31.5925070Z ##[error]Process completed with exit code 1.
```

### 31715849028 / job 94516048791 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/31715849028/job/94516048791

Class: unclassified. Raw SHA256: `72546dde97c3583e222fde94dbc5d31d776f6afe65d541c2353b16e4391ab3db`.

```text
2026-08-13T16:24:36.8240965Z ##[error]Process completed with exit code 1.
```

### 35503134923 / job 106058337028 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35503134923/job/106058337028

Class: generated-tree;candidate-product. Raw SHA256: `6a1464dbce46ba3c6ce84229a74ac60d7620ada8ccc5ceb0fdc902442f8fa7a9`.

```text
2026-09-20T09:44:32.3651169Z error: generated files differ: .github/actionlint.yaml, .github/ci/project.toml, .github/workflows/ci-main.yml, .github/workflows/ci-pr.yml, .github/workflows/ci-runtime-products.yml, .github/workflows/ci-unit-bun.yml, .github/workflows/ci-unit-docker.yml, .github/workflows/ci-unit-docs.yml, .github/workflows/ci-unit-opentofu.yml, .github/workflows/ci-unit-rust.yml, .github/workflows/preview.yml, .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T09:59:35.2493490Z ##[error]no candidate product velnor-workflow-candidate-ce870d7c6fbfb4a4-Linux-X64 was published within 15 minutes
2026-09-20T09:59:35.2503432Z ##[error]Process completed with exit code 1.
```

### 35503134923 / job 106060082098 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35503134923/job/106060082098

Class: unclassified. Raw SHA256: `96ffcb3a121cadb523e74238c73f900abe64d893d0aaedb0dcb7bf13e12e76fd`.

```text
2026-09-20T09:59:41.8157367Z ##[error]Process completed with exit code 1.
```

### 35503134923 / job 106060092414 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35503134923/job/106060092414

Class: unclassified. Raw SHA256: `0ec6833c8f5a060f2c62982d7eb46798f9826e79f743f576a5ebcf4c43153b9e`.

```text
2026-09-20T09:59:47.5073014Z ##[error]Process completed with exit code 1.
```

### 35482256453 / job 106002076413 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35482256453/job/106002076413

Class: generated-tree. Raw SHA256: `cc955300a87bb86427e846c6a65f9fed06f3d1597cb78b3fc754a21eb9b4455d`.

```text
2026-09-20T01:48:48.2161642Z error: generated files differ: .github/workflows/ci-main.yml, .github/workflows/ci-pr.yml, .github/workflows/ci-unit-bun.yml, .github/workflows/ci-unit-docker.yml, .github/workflows/ci-unit-docs.yml, .github/workflows/ci-unit-opentofu.yml, .github/workflows/ci-unit-rust.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T01:48:48.2199179Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
2026-09-20T01:48:48.2261248Z ##[error]Process completed with exit code 1.
```

### 35482256453 / job 106002496254 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35482256453/job/106002496254

Class: unclassified. Raw SHA256: `cb2ecb0527687ba79153bfc846a9de3f794858d07a43811fbf34d26ed5b9ae65`.

```text
2026-09-20T01:50:32.2551809Z ##[error]Process completed with exit code 1.
```

### 35482256453 / job 106002504602 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35482256453/job/106002504602

Class: unclassified. Raw SHA256: `a6df747c12750a578d62b01401d7acf5853013296371aa8e14c3e9c4ebaebb3b`.

```text
2026-09-20T01:50:36.6664932Z ##[error]Process completed with exit code 1.
```

### 35478701292 / job 105992554962 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35478701292/job/105992554962

Class: test-failure. Raw SHA256: `acd54aaeea4f3e6c73c441af38eac2f4be567f0c1ae22d47685c2831ea1d7d96`.

```text
2026-09-20T00:31:53.8563215Z     thread 'primitives::release::tests::default_rows_render_the_legacy_release_surface' (27074) panicked at crates/velnor-workflow/src/primitives/release.rs:5818:9:
2026-09-20T00:31:53.8612775Z error: test run failed
2026-09-20T00:31:54.1833144Z error: CI command failed for unit rust-velnor-workflow with exit status: 100
2026-09-20T00:31:54.1901655Z ##[error]Process completed with exit code 1.
```

### 35478701292 / job 105992555034 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35478701292/job/105992555034

Class: test-failure. Raw SHA256: `9f621197d276db2d9bf6f76a01d766e43988549b44ed157a91b310f36ac9706a`.

```text
2026-09-20T00:30:47.4037699Z     thread 'manifest::tests::compiled_manifest_is_version_fourteen_and_structurally_immutable' (26057) panicked at crates/velnor-runner/src/manifest.rs:1960:9:
2026-09-20T00:30:47.4039627Z       left: 15
2026-09-20T00:30:47.4040599Z      right: 14
2026-09-20T00:30:47.4470789Z error: test run failed
2026-09-20T00:30:47.7836051Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-20T00:30:47.7935661Z ##[error]Process completed with exit code 1.
```

### 35478701292 / job 105992555139 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35478701292/job/105992555139

Class: test-failure. Raw SHA256: `ee01652dfd73b471a39ee11fa1cec4adecc279847770cc4c301053e5a14a8487`.

```text
2026-09-20T00:26:28.8021616Z     thread 'parameterized_callees_resolve_to_the_pre_parameterization_cache_keys' (2598) panicked at tests/cache_keys.rs:258:13:
2026-09-20T00:26:28.8024037Z       left: "velnor-docker-seed-v3-7e67216c9e23-${{ runner.os }}-${{ runner.arch }}-github-hosted-linux-x64-trusted-only-docker-${{ hashFiles('Cargo.lock', 'Dockerfile', 'docker/build-mise.lock', 'docker/build-mise.toml', 'rust-toolchain.toml') }}-${{ hashFiles('Cargo.lock', 'deny.toml') }}"
2026-09-20T00:26:28.8026211Z      right: "velnor-docker-seed-v3-743cc362f16c-${{ runner.os }}-${{ runner.arch }}-github-hosted-linux-x64-trusted-only-docker-${{ hashFiles('Cargo.lock', 'Dockerfile', 'docker/build-mise.lock', 'docker/build-mise.toml', 'rust-toolchain.toml') }}-${{ hashFiles('Cargo.lock', 'deny.toml') }}"
2026-09-20T00:26:28.8038182Z error: test run failed
2026-09-20T00:26:29.4814910Z error: CI command failed for unit rust-velnor-workflow-contract with exit status: 100
2026-09-20T00:26:29.4863989Z ##[error]Process completed with exit code 1.
```

### 35478701292 / job 105993383718 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35478701292/job/105993383718

Class: unclassified. Raw SHA256: `b25e2207b16f285210340969e48d49d8cf8602a459288816ff2b4e17017dd5d7`.

```text
2026-09-20T00:32:56.3460016Z ##[error]Process completed with exit code 1.
```

### 35478701292 / job 105993396052 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35478701292/job/105993396052

Class: unclassified. Raw SHA256: `01a606b4dc5b95d78415c50af7750e210126bb98500e057405faad65997f231f`.

```text
2026-09-20T00:33:02.4999297Z ##[error]Process completed with exit code 1.
```

### 35490082715 / job 106023417881 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35490082715/job/106023417881

Class: candidate-product. Raw SHA256: `f84b50d73f411205fc262b175975ce3bccd0bcc31b318b587ebe640cbe89e141`.

```text
2026-09-20T04:49:13.2539512Z error: invalid generation config /home/runner/work/velnor/velnor/policy-checkout/.github-gen/velnor-workflow.toml: TOML parse error at line 75, column 1
2026-09-20T05:04:22.6364170Z ##[error]no candidate product velnor-workflow-candidate-0f79a34337312447-Linux-X64 was published within 15 minutes
2026-09-20T05:04:22.6371300Z ##[error]Process completed with exit code 1.
```

### 35475920826 / job 105985041123 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35475920826/job/105985041123

Class: generated-tree;candidate-product. Raw SHA256: `e08e3521ec1d838f5f6664c3c20b2900541e48db1e2741c62e2a459a661aee3d`.

```text
2026-09-19T23:22:56.9271825Z error: generated files differ: .github/actionlint.yaml, .github/workflows/ci-runtime-products.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-19T23:38:06.5674398Z ##[error]no candidate product velnor-workflow-candidate-5071a483c40de579-Linux-X64 was published within 15 minutes
2026-09-19T23:38:06.5683890Z ##[error]Process completed with exit code 1.
```

### 35475920826 / job 105986940290 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35475920826/job/105986940290

Class: unclassified. Raw SHA256: `b265367fe57d53d804f431510421a41671df6804ce9d436183bc57fa33661bbd`.

```text
2026-09-19T23:38:12.9756164Z ##[error]Process completed with exit code 1.
```

### 35475920826 / job 105986948707 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35475920826/job/105986948707

Class: unclassified. Raw SHA256: `719cce0c638b59c4f385cc4c50ac0bb6b2aae0f443bb0de12228ad641ba8b411`.

```text
2026-09-19T23:38:17.5366101Z ##[error]Process completed with exit code 1.
```

### 35469976817 / job 105969034918 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35469976817/job/105969034918

Class: generated-tree;candidate-product. Raw SHA256: `62a953c2cf6d591a7d4ae80c6589c945ce8509ba1656c51ffd640647129de99b`.

```text
2026-09-19T21:21:19.3744861Z error: workflow policy failed: generated-tree
2026-09-19T21:21:19.3752818Z FAIL generated-tree         could not regenerate the tree with velnor-workflow at fdeed261bd2247a38db6922a7726cd45d3d6f31e
2026-09-19T21:21:19.3769013Z ##[error]Process completed with exit code 1.
```

### 34739692833 / job 103677393320 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34739692833/job/103677393320

Class: unclassified. Raw SHA256: `ca0b1eb221be62e370b2326d9aa2ecf3337e7be838363337e25de06fd5766939`.

```text
2026-09-13T05:13:43.0000000Z error: CI command failed for unit docker with exit status: 1
```

### 34739692833 / job 103678523811 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34739692833/job/103678523811

Class: unclassified. Raw SHA256: `362cdf4a1b07ebf8c048601b2983bfe2d4feb39433279fa47cb08b2301c8966b`.

```text
2026-09-13T05:24:11.3006498Z ##[error]Process completed with exit code 1.
```

### 35141275001 / job 104946126554 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35141275001/job/104946126554

Class: unclassified. Raw SHA256: `d3d4e61f5578bb99b9caafc10e4384a5af9a5d24e5b1ec7c3211b369d325bf71`.

```text
2026-09-16T19:33:50.2752027Z ##[error]no runtime product for revision 4798d4398cb21b3cd6541c3d1d3df079295dc857 (closure e5ad6f4f923cd154); the mainline runtime-product publisher builds it after merge
2026-09-16T19:33:50.2755055Z ##[error]Process completed with exit code 1.
```

### 35141275001 / job 104946223951 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35141275001/job/104946223951

Class: unclassified. Raw SHA256: `5438e288e3bfb728aa0c49641801f119eb217a183907160ac799761071b518b9`.

```text
2026-09-16T19:33:57.3115809Z ##[error]Process completed with exit code 1.
```

### 35141275001 / job 104946261815 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35141275001/job/104946261815

Class: unclassified. Raw SHA256: `ae22a6b07c2290844aed5d7236431d554b0aecaf6526756ff3ab40e2b2182746`.

```text
2026-09-16T19:34:03.5187782Z ##[error]Process completed with exit code 1.
```

### 35141275001 / job 104948063423 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35141275001/job/104948063423

Class: unclassified. Raw SHA256: `82859883473e1ff3eb2d4a6979f81401a43a399c893b8c498a0a7c40fcbfdfd9`.

```text
2026-09-16T19:40:26.1743325Z ##[error]Velnor rejected this job before workflow execution.
```

### 35141275001 / job 104948064327 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35141275001/job/104948064327

Class: unclassified. Raw SHA256: `bd5581afc11a3a1a6665cfadab29c83863b89bf07cdb8794455648b9d1aefa8a`.

```text
2026-09-16T19:39:25.9783124Z ##[error]Velnor rejected this job before workflow execution.
```

### 35141275001 / job 104948065143 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35141275001/job/104948065143

Class: unclassified. Raw SHA256: `153b0d7511b832412a0222fd1d71f9923e7f79625b781244d1107eb5d43c442c`.

```text
2026-09-16T19:42:32.6842020Z ##[error]candidate reports closure b5eee5cd0e582e6c1fb01ca1b005bfdb763e13505d778a955a0f6f3eee29a394, head 23ae8b1a7d050255709efa34c594d43d7c63522e declares e3f6ab8566650fbbed5c527668938ae095f1542180142aec49337e18576f8cb2
2026-09-16T19:42:32.8345655Z ##[error]Process completed with exit code 1.
```

### 35141275001 / job 104949704863 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35141275001/job/104949704863

Class: unclassified. Raw SHA256: `259fe1b702f91cc7911bb617cf32c0d89e2e8b10259e36957cb572666fa275b7`.

```text
2026-09-16T19:44:17.2625120Z ##[error]Process completed with exit code 1.
```

### 35141275001 / job 104949743066 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35141275001/job/104949743066

Class: unclassified. Raw SHA256: `7dafb447c707a23b6166dad3754607a35584a9c9a1a7887ab3ebc7f9247f8128`.

```text
2026-09-16T19:44:23.7845056Z ##[error]Process completed with exit code 1.
```

### 35141275001 / job 104952075559 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/35141275001/job/104952075559

Class: unclassified. Raw SHA256: `f76810fcede3aa296ef4be5f13af53d4fa368d0d5876527e31adad3ebb134629`.

```text
2026-09-16T19:51:19.5879584Z ##[error]Velnor rejected this job before workflow execution.
```

### 35141275001 / job 104952075728 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/35141275001/job/104952075728

Class: unclassified. Raw SHA256: `468dfa00b38084b53eecc19536db73b5c9e1eccfc7f160082d04b2354996a2f7`.

```text
2026-09-16T19:52:19.8982181Z ##[error]Velnor rejected this job before workflow execution.
```

### 35141275001 / job 104952076463 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/35141275001/job/104952076463

Class: unclassified. Raw SHA256: `a5d4c3172ca2efa37b9eed3aaf4f02cd0093492b00d492817c74b75b8e860c87`.

```text
2026-09-16T19:54:43.9854341Z ##[error]candidate reports closure b5eee5cd0e582e6c1fb01ca1b005bfdb763e13505d778a955a0f6f3eee29a394, head 23ae8b1a7d050255709efa34c594d43d7c63522e declares e3f6ab8566650fbbed5c527668938ae095f1542180142aec49337e18576f8cb2
2026-09-16T19:54:44.1126524Z ##[error]Process completed with exit code 1.
```

### 35141275001 / job 104953249865 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/35141275001/job/104953249865

Class: unclassified. Raw SHA256: `1c645d57c272d0958dfe8c833e658574f990f2027142f1a37b7b24e6ffc8ae72`.

```text
2026-09-16T19:54:51.3924613Z ##[error]Process completed with exit code 1.
```

### 35141275001 / job 104953276193 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/35141275001/job/104953276193

Class: unclassified. Raw SHA256: `0a4bd1c960e009006edf3d6b4201fc27bac63557a1c28d22a8539384c2949124`.

```text
2026-09-16T19:54:55.9121794Z ##[error]Process completed with exit code 1.
```

### 31267258788 / job 93127313233 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/31267258788/job/93127313233

Class: unclassified. Raw SHA256: `5a1ef547600344fc3a03c629b6f615c6b4b38d3f40147e6dc79cae502071803d`.

```text
2026-08-08T16:34:08.1947670Z error: No such remote: 'origin'
```

### 31266372784 / job 93125091746 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/31266372784/job/93125091746

Class: unclassified. Raw SHA256: `c2df5f6a8dddfb6adb4a482956c72930cb32953df6c78da408c881a9a065d122`.

```text
2026-08-08T16:12:37.4413080Z error: No such remote: 'origin'
```

### 33289993420 / job 99200229977 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33289993420/job/99200229977

Class: unclassified. Raw SHA256: `b5cfc6bdaec2444a531af25b3290ea8235f242eb9de1a0fff6f31df2f9b56ae2`.

```text
2026-08-30T03:23:14.8297831Z ##[error]Process completed with exit code 1.
```

### 33289993420 / job 99200238814 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33289993420/job/99200238814

Class: unclassified. Raw SHA256: `40db119682150275a6142c5e4f37c0c664fc6d26d40e09473d99a48fbc37bafb`.

```text
2026-08-30T03:23:20.1817279Z ##[error]Process completed with exit code 1.
```

### 33289993420 / job 99200632746 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33289993420/job/99200632746

Class: unclassified. Raw SHA256: `70e335f100780ee44252c05c2218a37958170a1a1cb8017d35e18562371bdbe9`.

```text
2026-08-30T03:27:13.8801836Z ##[error]Process completed with exit code 1.
```

### 33289993420 / job 99200642157 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33289993420/job/99200642157

Class: unclassified. Raw SHA256: `81c43e84d8ea14bef7825f5292e5e3146657ca4dd1fa49e98c2fde2f56b28ae3`.

```text
2026-08-30T03:27:18.5658344Z ##[error]Process completed with exit code 1.
```

### 32827742941 / job 97739443546 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32827742941/job/97739443546

Class: unclassified. Raw SHA256: `b7f71f698bba69eda011b69e2066d028212e281e2e332793e193a03dab9ac322`.

```text
2026-08-25T08:39:35.9925063Z error: No such remote: 'origin'
2026-08-25T08:39:39.0000000Z error: No such remote: 'origin'
```

### 32827742941 / job 97741823753 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/32827742941/job/97741823753

Class: unclassified. Raw SHA256: `00407a2fae647b157a9c8b011ec4cd5ba08719383bcc6bcada7949868ccb9c93`.

```text
2026-08-25T08:48:28.8897032Z error: No such remote: 'origin'
2026-08-25T08:48:31.0000000Z error: No such remote: 'origin'
```

### 35190212625 / job 105100993152 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35190212625/job/105100993152

Class: unclassified. Raw SHA256: `ef143ab9f231b8b73a2686c6c920992eb2b43d7900590f3c99611c9e63aac8ee`.

```text
2026-09-17T06:32:15.5635637Z ##[error]Velnor rejected this job before workflow execution.
```

### 35190212625 / job 105100993173 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35190212625/job/105100993173

Class: unclassified. Raw SHA256: `5aba05f2c338448dc681c8462ee34d8edf36566eb328fab86ae6094daecb493b`.

```text
2026-09-17T06:32:13.9827833Z ##[error]Velnor rejected this job before workflow execution.
```

### 35190212625 / job 105100993231 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35190212625/job/105100993231

Class: unclassified. Raw SHA256: `ec9e4d60e362ed153e3164bb9aac46773761c5223a133f6b450afd6bfba84831`.

```text
2026-09-17T06:32:01.8288982Z ##[error]Velnor rejected this job before workflow execution.
```

### 35190212625 / job 105100993278 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35190212625/job/105100993278

Class: unclassified. Raw SHA256: `6dbef347e965c440a31e37be94e5152e84a9b4f2e98a58bf1d4ed43b9abf1a53`.

```text
2026-09-17T06:32:03.5657723Z ##[error]Velnor rejected this job before workflow execution.
```

### 35190212625 / job 105100993507 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35190212625/job/105100993507

Class: unclassified. Raw SHA256: `eb17a24e4f0f817891a42b8404313fa10bffab671bf2f36580916c255d8da316`.

```text
2026-09-17T06:32:04.0437140Z ##[error]Velnor rejected this job before workflow execution.
```

### 35190212625 / job 105101969745 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35190212625/job/105101969745

Class: unclassified. Raw SHA256: `36e9d2e74ca29ff01789453c59f5f54ab241f8562cd5a665d08a169451dafc36`.

```text
2026-09-17T06:36:17.5208619Z ##[error]Process completed with exit code 1.
```

### 35190212625 / job 105101987104 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35190212625/job/105101987104

Class: unclassified. Raw SHA256: `96b6564448e082d70f93846e42bfeb092356054a95086c8be8c6caff613e74e4`.

```text
2026-09-17T06:36:57.8268272Z ##[error]Process completed with exit code 1.
```

### 35190212625 / job 105102962372 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35190212625/job/105102962372

Class: unclassified. Raw SHA256: `e5e728820321ec5c22ce296eb6e77724995ec32a5c9e14ddc18a6b7359ca5526`.

```text
2026-09-17T06:40:50.0113583Z ##[error]Velnor rejected this job before workflow execution.
```

### 35190212625 / job 105102962395 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35190212625/job/105102962395

Class: unclassified. Raw SHA256: `e08d6b11c1b1a1e52be66c55d726c217ca8d12f3553f3af07ea302de9640e580`.

```text
2026-09-17T06:40:38.2938289Z ##[error]Velnor rejected this job before workflow execution.
```

### 35190212625 / job 105102962566 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35190212625/job/105102962566

Class: unclassified. Raw SHA256: `7bd524f24ef51508b6be01bf7d0572a1d429053bafcb34fbdf1b212e5737268f`.

```text
2026-09-17T06:40:38.2381812Z ##[error]Velnor rejected this job before workflow execution.
```

### 35190212625 / job 105102962767 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35190212625/job/105102962767

Class: unclassified. Raw SHA256: `8516f35cadb1468622c76f79e2a74bb075aef276477a7f89a2be1ea0897127d4`.

```text
2026-09-17T06:40:49.9669057Z ##[error]Velnor rejected this job before workflow execution.
```

### 35190212625 / job 105102962838 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35190212625/job/105102962838

Class: unclassified. Raw SHA256: `c59ce80f03cc8201da61ab8dea217ce5b7094a2e97abf3bff65580e51942d339`.

```text
2026-09-17T06:40:38.1846296Z ##[error]Velnor rejected this job before workflow execution.
```

### 35190212625 / job 105103025091 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35190212625/job/105103025091

Class: unclassified. Raw SHA256: `f907d2a1add135f83d21c8c5ad92d74b88eb0fafdf4c1d5a0c9d9c7304c9421a`.

```text
2026-09-17T06:40:54.5010596Z ##[error]Process completed with exit code 1.
```

### 35190212625 / job 105103043777 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35190212625/job/105103043777

Class: unclassified. Raw SHA256: `989c02129bd40e3910f3c490bf841e01ee612b4eedea6bd504e55bd481ec7809`.

```text
2026-09-17T06:40:59.3206965Z ##[error]Process completed with exit code 1.
```

### 35483330604 / job 106005010912 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35483330604/job/106005010912

Class: generated-tree;candidate-product. Raw SHA256: `641ab4674828bcfd9e511af44201b153a1fb03fdfa01cce568dee3189a188991`.

```text
2026-09-20T02:11:51.0805507Z error: generated files differ: .github/actionlint.yaml, .github/workflows/ci-runtime-products.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T02:21:32.3460074Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-de4e2b77dcc86a1f-Linux-X64
2026-09-20T02:21:32.3469280Z ##[error]Process completed with exit code 1.
```

### 35471774816 / job 105973896897 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35471774816/job/105973896897

Class: generated-tree;candidate-product. Raw SHA256: `c70363a49536a208b640df58ef449be6c5c58b77303aca48348c4e51f9f602fb`.

```text
2026-09-19T21:54:18.0497927Z error: generated files differ: .github/actionlint.yaml, .github/workflows/ci-runtime-products.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-19T21:58:16.2090855Z error: workflow policy failed: trusted-runners
2026-09-19T21:58:16.2102401Z FAIL trusted-runners        1 finding
2026-09-19T21:58:16.2116775Z ##[error]Process completed with exit code 1.
```

### 35517540830 / job 106095898830 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35517540830/job/106095898830

Class: generated-tree;candidate-product. Raw SHA256: `3926554e2d7a6f3f412cf208a591342c8f100f0335e48d70c27a3bf84d2a6994`.

```text
2026-09-20T14:47:14.2508618Z error: generated files match but generation inputs changed: scan input changed from b096c93329fcc370 to 5691f3c8c8b8d479 in .github/ci/.github-actions-generator-state; regenerate to record the current generation inputs
2026-09-20T14:52:10.2573859Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-9e6bb04aed5e5a89-Linux-X64
2026-09-20T14:52:10.2583583Z ##[error]Process completed with exit code 1.
```

### 32818128018 / job 97711208710 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32818128018/job/97711208710

Class: packaging. Raw SHA256: `93b9623ae8483a00ff0d269d5f689df2d70df04b210e3a04883a850a762006f7`.

```text
2026-08-25T06:46:00.2279697Z ##[error]published binary digest != record (amd64)
2026-08-25T06:46:00.2289314Z ##[error]Process completed with exit code 1.
```

### 35493165389 / job 106031459740 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35493165389/job/106031459740

Class: generated-tree;candidate-product. Raw SHA256: `14b06412f2e45f3480a094d5fac13e26336cb4005c1d7f520d59a560bcaaf4ae`.

```text
2026-09-20T06:12:06.0095871Z error: workflow policy failed: generated-tree
2026-09-20T06:12:06.0101497Z FAIL generated-tree         could not regenerate the tree with velnor-workflow at 325719f1e05d3d46322c9fd3eeb9ad545e175638
2026-09-20T06:12:06.0116576Z ##[error]Process completed with exit code 1.
```

### 35480462500 / job 105997245792 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35480462500/job/105997245792

Class: generated-tree. Raw SHA256: `ae9aa5d747ae7864b36748d220a16c21670b3a2ca13d0da1afa5fd8ff3c00a88`.

```text
2026-09-20T01:08:05.7588405Z error: generated files match but generation inputs changed: scan input changed from b096c93329fcc370 to 4d9e40db14a88597 in .github/ci/.github-actions-generator-state; regenerate to record the current generation inputs
2026-09-20T01:08:05.7611490Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
2026-09-20T01:08:05.7661733Z ##[error]Process completed with exit code 1.
```

### 35480462500 / job 105998168614 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35480462500/job/105998168614

Class: unclassified. Raw SHA256: `e87a6cead30c9f66dda5f09d3759faedd5726320491760418c60850cd4837acc`.

```text
2026-09-20T01:13:20.0656090Z ##[error]Process completed with exit code 1.
```

### 35480462500 / job 105998178835 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35480462500/job/105998178835

Class: unclassified. Raw SHA256: `a2f9807111f0b46e436daf113bd3abe52b4fce52cfcbbac572dfcf9916c10cfb`.

```text
2026-09-20T01:13:25.0137537Z ##[error]Process completed with exit code 1.
```

### 35514378725 / job 106089090157 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35514378725/job/106089090157

Class: dirty-preview. Raw SHA256: `0882016b2d6e460c1c0489c4e5427aea2875e8b3c871dac84a1b3828924c32bd`.

```text
2026-09-20T13:59:04.5243266Z error: failed to run custom build command for `velnor-runner v0.1.277 (/home/runner/work/velnor/velnor/crates/velnor-runner)`
2026-09-20T13:59:04.5257899Z   thread 'main' (16661) panicked at crates/velnor-runner/build.rs:181:9:
2026-09-20T14:00:15.2689978Z ##[error]Process completed with exit code 101.
```

### 35514378725 / job 106089090297 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35514378725/job/106089090297

Class: cross-compiler. Raw SHA256: `b3ac8715870eca82869e26347ed7aca9672ed22d36d963c92f53e8cd8bd08f64`.

```text
2026-09-20T13:57:05.4423828Z error: failed to run custom build command for `aws-lc-sys v0.44.0`
2026-09-20T13:57:07.5137059Z error: failed to run custom build command for `openssl-sys v0.9.117`
2026-09-20T13:57:07.8367704Z ##[error]Process completed with exit code 101.
```

### 35467815794 / job 105963261538 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35467815794/job/105963261538

Class: candidate-product. Raw SHA256: `62c8c287c535bc8b2f0d443f78727709b8dca40d17ef72ea04ba3616a97d5d69`.

```text
2026-09-19T20:50:08.9183816Z ##[error]no candidate product velnor-workflow-candidate-5887398768e1af80-Linux-X64 was published within 15 minutes
2026-09-19T20:50:08.9194220Z ##[error]Process completed with exit code 1.
```

### 32814201190 / job 97699917555 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32814201190/job/97699917555

Class: unclassified. Raw SHA256: `5ff6449522244c94e2a4a3985cf8d492c8c1c21d8c726a6f96323979da92be2f`.

```text
2026-08-25T05:51:09.4244651Z error: No such remote: 'origin'
```

### 35518673495 / job 106098893545 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35518673495/job/106098893545

Class: test-failure. Raw SHA256: `46e02a83e611e92ad79d2920a0a0c1d6be9ff5faf44e13fe3d2ba9064e9b6f08`.

```text
2026-09-20T15:13:47.8767635Z     thread 'permit_guard::tests::concurrent_first_daemon_capacity_adopt_is_atomic' (26506) panicked at crates/velnor-runner/src/permit_guard.rs:876:9:
2026-09-20T15:13:47.8768544Z       left: 4
2026-09-20T15:13:47.8768734Z      right: 8
2026-09-20T15:13:50.9546542Z error: test run failed
2026-09-20T15:13:51.3609680Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-20T15:13:51.3699087Z ##[error]Process completed with exit code 1.
```

### 35518673495 / job 106099483967 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35518673495/job/106099483967

Class: unclassified. Raw SHA256: `5ef770bdf0b95d44ef153ff4d18d7c177260b521457b11839a1690c0b7717d3c`.

```text
2026-09-20T15:13:57.4868985Z ##[error]Process completed with exit code 1.
```

### 35518673495 / job 106099498045 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35518673495/job/106099498045

Class: unclassified. Raw SHA256: `607d796ee1be88f2e1929972243333166e374e1dcb4798cd3d1b74939d420de5`.

```text
2026-09-20T15:14:02.8311554Z ##[error]Process completed with exit code 1.
```

### 34729285765 / job 103649008445 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34729285765/job/103649008445

Class: test-failure. Raw SHA256: `293faf76239f0d686c716777fa045f5c292d187967d0888afaaeefb4beaf6429`.

```text
2026-09-13T01:01:30.9228574Z     thread 'runner::tests::admission_regression_missing_signal_downgrades_on_trusted_pool' (7909) panicked at crates/velnor-runner/src/runner.rs:14936:13:
2026-09-13T01:01:30.9231425Z       left: Trusted
2026-09-13T01:01:30.9231994Z      right: Unknown
2026-09-13T01:01:36.0856903Z error: test run failed
2026-09-13T01:01:36.0993086Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-13T01:01:36.1028573Z ##[error]Process completed with exit code 1.
```

### 34729285765 / job 103650331250 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34729285765/job/103650331250

Class: unclassified. Raw SHA256: `5085050ca3ef4c79f9303f15b35054ce019cf8ac2e2792dd429faff1e59ac267`.

```text
2026-09-13T01:08:49.7525926Z ##[error]Process completed with exit code 1.
```

### 34729285765 / job 103650724265 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34729285765/job/103650724265

Class: test-failure. Raw SHA256: `e1bf72573ec5895aa3682a2dbfb93275dc7ae102bdebdfe083e6f19864a1b490`.

```text
2026-09-13T01:16:14.2762401Z     thread 'runner::tests::admission_regression_missing_signal_downgrades_on_trusted_pool' (7870) panicked at crates/velnor-runner/src/runner.rs:14936:13:
2026-09-13T01:16:14.2764283Z       left: Trusted
2026-09-13T01:16:14.2764684Z      right: Unknown
2026-09-13T01:16:16.5389992Z error: test run failed
2026-09-13T01:16:16.5540079Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-13T01:16:16.5575001Z ##[error]Process completed with exit code 1.
```

### 34729285765 / job 103651222499 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34729285765/job/103651222499

Class: unclassified. Raw SHA256: `09d8c9fcd92da37ba3077adb7b8681badeae2d1e364b909104fa487b9b529806`.

```text
2026-09-13T01:16:25.4848652Z ##[error]Process completed with exit code 1.
```

### 35479731338 / job 105995245340 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35479731338/job/105995245340

Class: generated-tree;candidate-product. Raw SHA256: `aa35b6a30bcb90e6072ac8071d9b4350911eeafa38c67bca5462fbc5d19eaacd`.

```text
2026-09-20T00:48:37.3089918Z error: generated files differ: .github/actionlint.yaml, .github/workflows/ci-runtime-products.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T00:58:06.3582114Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-870e97199eaac1b4-Linux-X64
2026-09-20T00:58:06.3591154Z ##[error]Process completed with exit code 1.
```

### 34769409985 / job 103756131681 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34769409985/job/103756131681

Class: unclassified. Raw SHA256: `67d45e7d489b74f5f28f73d40bab5a545481709e5b481b56f7d75b9fe77acae3`.

```text
2026-09-13T16:43:54.0000000Z error: workflow policy rejected 3 finding(s):
```

### 34769409985 / job 103756480415 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34769409985/job/103756480415

Class: unclassified. Raw SHA256: `66ffd87cd79f9a2f187701b3479602d77f2227fc85846a183d9a3ffdbed52aee`.

```text
2026-09-13T16:46:30.0000000Z error: workflow policy rejected 3 finding(s):
```

### 32638155133 / job 97190980479 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32638155133/job/97190980479

Class: unclassified. Raw SHA256: `0aa5b6a903f212169f0acabb121d46b8ea917a104a41b6b338d4dcf97e781de0`.

```text
2026-08-23T12:01:15.3950185Z ##[error]Process completed with exit code 1.
```

### 32638155133 / job 97190993979 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32638155133/job/97190993979

Class: unclassified. Raw SHA256: `6fd75e09be7353c7823a40204dfafa601a6b6f65aa2f67d1a12696f3ff401b21`.

```text
2026-08-23T12:01:21.9243770Z ##[error]Process completed with exit code 1.
```

### 33572323906 / job 100069468838 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33572323906/job/100069468838

Class: unclassified. Raw SHA256: `a31cf9105f621ab2f9f449ef1cc2f9750b27696fa675582b13db15fafb58aaa6`.

```text
2026-09-01T23:48:51.1605856Z error: failed to run custom build command for `velnor-runner v0.1.250 (/home/runner/work/velnor/velnor/crates/velnor-runner)`
2026-09-01T23:48:51.1612954Z   thread 'main' (10894) panicked at crates/velnor-runner/build.rs:88:15:
2026-09-01T23:50:15.5999253Z ##[error]Process completed with exit code 1.
```

### 33572323906 / job 100070408091 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33572323906/job/100070408091

Class: unclassified. Raw SHA256: `a31cf9105f621ab2f9f449ef1cc2f9750b27696fa675582b13db15fafb58aaa6`.

```text
2026-09-01T23:48:51.1605856Z error: failed to run custom build command for `velnor-runner v0.1.250 (/home/runner/work/velnor/velnor/crates/velnor-runner)`
2026-09-01T23:48:51.1612954Z   thread 'main' (10894) panicked at crates/velnor-runner/build.rs:88:15:
2026-09-01T23:50:15.5999253Z ##[error]Process completed with exit code 1.
```

### 35484147185 / job 106007312195 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35484147185/job/106007312195

Class: unclassified. Raw SHA256: `bdd05edaf201b191b37d421bc8798e45662c3217f1904be4b1a396fa1f0d6021`.

```text
2026-09-20T02:32:11.1655756Z error: CI command failed for unit docs with exit status: 1
2026-09-20T02:32:11.1722868Z ##[error]Process completed with exit code 1.
```

### 35484147185 / job 106008570060 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35484147185/job/106008570060

Class: unclassified. Raw SHA256: `eb1517bf6b63107ac293522ee33ca7f8d7250c2476e0a1d5d1df94af7c2bab5d`.

```text
2026-09-20T02:40:48.7062214Z ##[error]Process completed with exit code 1.
```

### 35484147185 / job 106008578880 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35484147185/job/106008578880

Class: unclassified. Raw SHA256: `aabff6af4fb3545601d41c629d653c0fe242d1e74f9d02a8205f65c687365c56`.

```text
2026-09-20T02:40:52.9356117Z ##[error]Process completed with exit code 1.
```

### 34858729879 / job 104027813470 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34858729879/job/104027813470

Class: unclassified. Raw SHA256: `67855643773a08b220de7fed787c73e0d799fc2e11008c7e6e3f22c68a188281`.

```text
2026-09-14T15:04:36.1135184Z error: parse CI configuration .github/ci/project.toml: TOML parse error at line 47, column 1
2026-09-14T15:04:36.1148827Z ##[error]Process completed with exit code 1.
```

### 34858729879 / job 104028596375 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34858729879/job/104028596375

Class: unclassified. Raw SHA256: `164c4794b35be6d357784e99b904c09bd574f56ecddd5d3f43ad2f545ab29e76`.

```text
2026-09-14T15:04:45.1562007Z ##[error]Process completed with exit code 1.
```

### 34858729879 / job 104028636484 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34858729879/job/104028636484

Class: unclassified. Raw SHA256: `f6a7a08770840ec0de063bc3fe982ff32f38a7e65e38b7ae764810600af9e4b9`.

```text
2026-09-14T15:04:50.0467878Z ##[error]Process completed with exit code 1.
```

### 35469862042 / job 105968754027 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35469862042/job/105968754027

Class: generated-tree;candidate-product. Raw SHA256: `3c0828b17fe598733eb3fad3b3ce39af119737867fd96db0bda4189c0406f695`.

```text
2026-09-19T21:15:53.5087316Z error: generated files differ: .github/workflows/ci-runtime-products.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-19T21:19:23.8578816Z error: workflow policy failed: trusted-runners
2026-09-19T21:19:23.8589275Z FAIL trusted-runners        1 finding
2026-09-19T21:19:23.8603796Z ##[error]Process completed with exit code 1.
```

### 35519253921 / job 106100404598 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35519253921/job/106100404598

Class: test-failure. Raw SHA256: `278fba88b11a56c847c6828886a29f2aadb88b1b7e79b3f2b5588d442f98e937`.

```text
2026-09-20T15:26:19.6429829Z     thread 'thundering_herd_grants_exactly_one_per_permit' (29202) panicked at crates/velnor-runner/tests/scaleset_allocator.rs:103:5:
2026-09-20T15:26:19.6430769Z       left: 1
2026-09-20T15:26:19.6430988Z      right: 2
2026-09-20T15:26:33.6889152Z error: test run failed
2026-09-20T15:26:34.0020507Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-20T15:26:34.0105436Z ##[error]Process completed with exit code 1.
```

### 35519253921 / job 106101254390 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35519253921/job/106101254390

Class: unclassified. Raw SHA256: `756f57c78246cf82fb5904a90de913cad8889f1a0a231144b0953f4b1226af2f`.

```text
2026-09-20T15:26:40.2521484Z ##[error]Process completed with exit code 1.
```

### 35519253921 / job 106101266761 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35519253921/job/106101266761

Class: unclassified. Raw SHA256: `f40deba6d000fd5fced9d7218c1792441a29d7073a0cbb4560822d4c5ee65839`.

```text
2026-09-20T15:26:45.3761102Z ##[error]Process completed with exit code 1.
```

### 35061481798 / job 104683043409 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35061481798/job/104683043409

Class: unclassified. Raw SHA256: `df94395ce00087e624b028844a49ad7e00fe5980781dc979eb476f18e51e7bb4`.

```text
2026-09-16T05:58:12.9388807Z ##[error]Velnor rejected this job before workflow execution.
```

### 35061481798 / job 104684777110 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35061481798/job/104684777110

Class: unclassified. Raw SHA256: `22d87ae5a802feb7c803e06dab0de61b41c6a16e5dafcb2fa28603f943aa02a0`.

```text
2026-09-16T06:06:16.6975695Z ##[error]Process completed with exit code 1.
```

### 35061481798 / job 104684794732 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35061481798/job/104684794732

Class: unclassified. Raw SHA256: `80bfed4ed676e27c4d5c259cfd24657df20569eb8c4e6ea46d6bd69fee788d25`.

```text
2026-09-16T06:06:22.5200632Z ##[error]Process completed with exit code 1.
```

### 35061481798 / job 104686495493 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35061481798/job/104686495493

Class: unclassified. Raw SHA256: `a85885d93c65375561baab7d174f48cd439a5c2c64745bc0aace0cf980775996`.

```text
2026-09-16T06:14:03.9403853Z ##[error]Velnor rejected this job before workflow execution.
```

### 35061481798 / job 104686495599 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35061481798/job/104686495599

Class: unclassified. Raw SHA256: `2d5d8c758b1c92a95cd0997a321d78dac81c3eb15cd4a8468e0576f3c6b5f696`.

```text
2026-09-16T06:14:04.0450937Z ##[error]Velnor rejected this job before workflow execution.
```

### 35061481798 / job 104687581522 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35061481798/job/104687581522

Class: unclassified. Raw SHA256: `58295e5d11177c28e36ac7443aa2c3b8b850528d39f9d17fe04e41db3c9b62e2`.

```text
2026-09-16T06:18:53.1131445Z ##[error]Process completed with exit code 1.
```

### 35061481798 / job 104687603530 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35061481798/job/104687603530

Class: unclassified. Raw SHA256: `3dd5fe36daa011822c6e95762f2c2592d8b6e59bddccce33ae5fa2d84492bbc8`.

```text
2026-09-16T06:18:59.0274737Z ##[error]Process completed with exit code 1.
```

### 33349329549 / job 99360022191 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33349329549/job/99360022191

Class: unclassified. Raw SHA256: `b9cbde3049f32a4bf9c05e0df67d0fd8c77e34bfe24357538e7792910a1b55dd`.

```text
2026-08-31T02:04:47.7278865Z ##[error]Process completed with exit code 1.
```

### 33349329549 / job 99360034207 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33349329549/job/99360034207

Class: unclassified. Raw SHA256: `45894f6541d59cd5d84b0a2b469864cb55d462a3f8204b4ac02cd29d536a41de`.

```text
2026-08-31T02:04:52.2794234Z ##[error]Process completed with exit code 1.
```

### 33349329549 / job 99360387140 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33349329549/job/99360387140

Class: unclassified. Raw SHA256: `8d7b03e219442ed60b217a90c3930d887b0f909d7c6e3d5a5d8661d898b2eb3c`.

```text
2026-08-31T02:07:16.3332970Z ##[error]Process completed with exit code 1.
```

### 33349329549 / job 99360404041 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33349329549/job/99360404041

Class: unclassified. Raw SHA256: `f323154a72a2b25da9c886394ec237d1ec04a84bf20c583de268d686669d53d0`.

```text
2026-08-31T02:07:22.4247508Z ##[error]Process completed with exit code 1.
```

### 35473905614 / job 105979736152 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35473905614/job/105979736152

Class: generated-tree. Raw SHA256: `b849f1f4747ece75cae1a1528811d8b1979954f8bdb047004931502c8622cf3b`.

```text
2026-09-19T22:40:36.2240528Z error: generated files match but generation inputs changed: scan input changed from 8d96315cc857133b to f1f9ff652d60f12c in .github/ci/.github-actions-generator-state; regenerate to record the current generation inputs
2026-09-19T22:40:36.2260776Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
2026-09-19T22:40:36.2318574Z ##[error]Process completed with exit code 1.
```

### 35473905614 / job 105980885165 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35473905614/job/105980885165

Class: unclassified. Raw SHA256: `667143a6cfa6e5c319e5c145ce6cb67f4c964ead7e9639fa5127d573e3709317`.

```text
2026-09-19T22:48:02.8960762Z ##[error]Process completed with exit code 1.
```

### 35473905614 / job 105980893415 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35473905614/job/105980893415

Class: unclassified. Raw SHA256: `110d69c0fe3bd0855230a1c8274f198d7516dfe8573c0ed6aaeb19baf0f2b1ec`.

```text
2026-09-19T22:48:07.4909398Z ##[error]Process completed with exit code 1.
```

### 35445034780 / job 105923153322 / attempt 5

https://github.com/tailrocks/velnor/actions/runs/35445034780/job/105923153322

Class: test-failure. Raw SHA256: `3b3c258d7ce6d00fd50d8c90ce982099886fe1fe4bdcc54ba55d1298ce0e4201`.

```text
2026-09-19T15:48:43.7974234Z     thread 'parameterized_callees_resolve_to_the_pre_parameterization_cache_keys' (2880) panicked at tests/cache_keys.rs:258:13:
2026-09-19T15:48:43.7978466Z       left: "velnor-docker-seed-v3-7e67216c9e23-${{ runner.os }}-${{ runner.arch }}-github-hosted-linux-x64-trusted-only-docker-${{ hashFiles('Cargo.lock', 'Dockerfile', 'docker/build-mise.lock', 'docker/build-mise.toml', 'rust-toolchain.toml') }}-${{ hashFiles('Cargo.lock', 'deny.toml') }}"
2026-09-19T15:48:43.7982048Z      right: "velnor-docker-seed-v3-743cc362f16c-${{ runner.os }}-${{ runner.arch }}-github-hosted-linux-x64-trusted-only-docker-${{ hashFiles('Cargo.lock', 'Dockerfile', 'docker/build-mise.lock', 'docker/build-mise.toml', 'rust-toolchain.toml') }}-${{ hashFiles('Cargo.lock', 'deny.toml') }}"
2026-09-19T15:48:43.7992441Z error: test run failed
2026-09-19T15:48:43.8036775Z error: CI command failed for unit rust-velnor-workflow-contract with exit status: 100
2026-09-19T15:48:43.8100218Z ##[error]Process completed with exit code 1.
```

### 35139040893 / job 104938639245 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35139040893/job/104938639245

Class: unclassified. Raw SHA256: `8c8ebfc41953fbf8e609f196160dabe148a1cd0a10a09802619e40471055f381`.

```text
2026-09-16T19:11:40.0062309Z ##[error]no runtime product for revision d129fb893325d207ec2cdd64f1325f8a8efbf670 (closure 2bd48976b59bf084); the mainline runtime-product publisher builds it after merge
2026-09-16T19:11:40.0068274Z ##[error]Process completed with exit code 1.
```

### 35139040893 / job 104938721678 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35139040893/job/104938721678

Class: unclassified. Raw SHA256: `7f37aed7767b34d520879fa297f140c75845e037f847a492bd850ccbf0c04a20`.

```text
2026-09-16T19:11:47.0580656Z ##[error]Process completed with exit code 1.
```

### 35139040893 / job 104938761771 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35139040893/job/104938761771

Class: unclassified. Raw SHA256: `b9611b08f6f5a224396f3b6f45f6c207aeaded611582ab4f3992b2c592fc1a8c`.

```text
2026-09-16T19:11:54.9983153Z ##[error]Process completed with exit code 1.
```

### 35139040893 / job 104940477641 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35139040893/job/104940477641

Class: unclassified. Raw SHA256: `6e50910dd1f8ae58113aae6519ce616c2c3a8cb262c5364f7f5c8bdd21689ed1`.

```text
2026-09-16T19:16:49.5031559Z ##[error]Velnor rejected this job before workflow execution.
```

### 35139040893 / job 104940477797 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35139040893/job/104940477797

Class: unclassified. Raw SHA256: `2da8b1711348ba9de07d72d62853ef0f08ab6de1a681910220efe39ca0fd7230`.

```text
2026-09-16T19:17:49.9843959Z ##[error]Velnor rejected this job before workflow execution.
```

### 35139040893 / job 104940478885 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35139040893/job/104940478885

Class: unclassified. Raw SHA256: `2f9fbebcb4c0c1b0f20dc22427dca697134506899a400e7d18a779972720d944`.

```text
2026-09-16T19:18:02.2850616Z ##[error]Velnor rejected this job before workflow execution.
```

### 35139040893 / job 104940479161 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35139040893/job/104940479161

Class: unclassified. Raw SHA256: `45ef1dbf559e0f71a6b688ff55489d0da45553e20d482bad8e3469dbc4d958a1`.

```text
2026-09-16T19:19:13.0091768Z ##[error]candidate reports closure 1becce287d217f0f5ab7e6e86683f015331e4ca2ca40bacdd870240a5a8e8453, head 8e6edac1882a642d45100149c318a3270c85f64f declares aa89d76c7230ecf4808ff8bb1f45f34c830a9b5b9d3354e8d0820dce238f01b0
2026-09-16T19:19:13.0104327Z ##[error]Process completed with exit code 1.
```

### 35139040893 / job 104940546162 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35139040893/job/104940546162

Class: unclassified. Raw SHA256: `383f7d10ecdd71630a56496f9a237455953f3fe7666044ee5585e9ecf34cedca`.

```text
2026-09-16T19:17:01.6941767Z ##[error]Velnor rejected this job before workflow execution.
```

### 35139040893 / job 104940546325 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35139040893/job/104940546325

Class: unclassified. Raw SHA256: `0c6deee7fd2dcd47bc551e1e82ef466d7801e9ff7ba9f761564f7a78147b76ea`.

```text
2026-09-16T19:17:13.2288418Z ##[error]Velnor rejected this job before workflow execution.
```

### 35139040893 / job 104940688328 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35139040893/job/104940688328

Class: unclassified. Raw SHA256: `f9f56b4414e3978cfdd7f5a87ffedfc30a201d6b23ac0a04db0aa999dee62240`.

```text
2026-09-16T19:17:25.6130036Z ##[error]Velnor rejected this job before workflow execution.
```

### 35139040893 / job 104940688407 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35139040893/job/104940688407

Class: unclassified. Raw SHA256: `2924dac7a1d805e6c93b1983474440532d7bb6ef17e9d74a5b1ae6f5eb3ed746`.

```text
2026-09-16T19:17:38.6319777Z ##[error]Velnor rejected this job before workflow execution.
```

### 35139040893 / job 104942721668 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35139040893/job/104942721668

Class: unclassified. Raw SHA256: `ba733b24b4fe1019f6fcac2bd6b6cc6f9bf9ecdcd9b3a97d58309a5531c618f1`.

```text
2026-09-16T19:23:28.8377331Z ##[error]Process completed with exit code 1.
```

### 35139040893 / job 104942757787 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35139040893/job/104942757787

Class: unclassified. Raw SHA256: `7c2c3da1b144f7b7c4cfba18e958aba88bc5d5317a176452469a2cd1980f06cd`.

```text
2026-09-16T19:23:35.6644214Z ##[error]Process completed with exit code 1.
```

### 35192164244 / job 105107097910 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35192164244/job/105107097910

Class: unclassified. Raw SHA256: `48a3385a31c5323fd9377f18da255d2db97619460f8c0c6ddf6acda3c20f8183`.

```text
2026-09-17T06:58:47.0568010Z error: CI command failed for unit docker with exit status: 1
2026-09-17T06:58:47.0634680Z ##[error]Process completed with exit code 1.
```

### 35192164244 / job 105107098211 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35192164244/job/105107098211

Class: unclassified. Raw SHA256: `5aff826fdaf9b176e1100ea3bf9bc38ca30fcd163174af3ad662856b6199395b`.

```text
2026-09-17T06:57:51.9675186Z ##[error]Velnor rejected this job before workflow execution.
```

### 35192164244 / job 105107098750 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35192164244/job/105107098750

Class: unclassified. Raw SHA256: `51f63105f5a066dca17a8b9afbc97bf8affa86ba665565935427e07a9f82e8c4`.

```text
2026-09-17T06:57:52.0351990Z ##[error]Velnor rejected this job before workflow execution.
```

### 35192164244 / job 105107098764 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35192164244/job/105107098764

Class: unclassified. Raw SHA256: `2d6c00ea82f0dad7198d055999b00cfe07339a676f44dbff0e7d7c1ff2f9a799`.

```text
2026-09-17T06:57:51.9739268Z ##[error]Velnor rejected this job before workflow execution.
```

### 35192164244 / job 105107098905 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35192164244/job/105107098905

Class: unclassified. Raw SHA256: `4942324e3af74367761597871d147b0337864f07574ad98727ae00b76602e89a`.

```text
2026-09-17T06:58:03.9785905Z ##[error]Velnor rejected this job before workflow execution.
```

### 35192164244 / job 105107099108 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35192164244/job/105107099108

Class: unclassified. Raw SHA256: `1e71f0fe5fb5a73293d4f32ac3aadfd4b9db06a0880fe2ea6d803feafdfb196b`.

```text
2026-09-17T06:58:03.9852410Z ##[error]Velnor rejected this job before workflow execution.
```

### 35192164244 / job 105108134989 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35192164244/job/105108134989

Class: unclassified. Raw SHA256: `685365947e9ff6de48cfda3b1fa050c8ad27efd9fa28b1531ed3c7ba0918e62d`.

```text
2026-09-17T07:02:00.0472870Z ##[error]Process completed with exit code 1.
```

### 35192164244 / job 105108159513 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35192164244/job/105108159513

Class: unclassified. Raw SHA256: `54828df493e70888468e9c48c0ea44e5459b3db490d91624ffeb80c2e2adfc5e`.

```text
2026-09-17T07:02:06.1221918Z ##[error]Process completed with exit code 1.
```

### 35192164244 / job 105109355497 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35192164244/job/105109355497

Class: unclassified. Raw SHA256: `51f63105f5a066dca17a8b9afbc97bf8affa86ba665565935427e07a9f82e8c4`.

```text
2026-09-17T06:57:52.0351990Z ##[error]Velnor rejected this job before workflow execution.
```

### 35192164244 / job 105109355568 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35192164244/job/105109355568

Class: unclassified. Raw SHA256: `4942324e3af74367761597871d147b0337864f07574ad98727ae00b76602e89a`.

```text
2026-09-17T06:58:03.9785905Z ##[error]Velnor rejected this job before workflow execution.
```

### 35192164244 / job 105109356062 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35192164244/job/105109356062

Class: unclassified. Raw SHA256: `5aff826fdaf9b176e1100ea3bf9bc38ca30fcd163174af3ad662856b6199395b`.

```text
2026-09-17T06:57:51.9675186Z ##[error]Velnor rejected this job before workflow execution.
```

### 35192164244 / job 105109356469 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35192164244/job/105109356469

Class: unclassified. Raw SHA256: `1e71f0fe5fb5a73293d4f32ac3aadfd4b9db06a0880fe2ea6d803feafdfb196b`.

```text
2026-09-17T06:58:03.9852410Z ##[error]Velnor rejected this job before workflow execution.
```

### 35192164244 / job 105109356490 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35192164244/job/105109356490

Class: unclassified. Raw SHA256: `2d6c00ea82f0dad7198d055999b00cfe07339a676f44dbff0e7d7c1ff2f9a799`.

```text
2026-09-17T06:57:51.9739268Z ##[error]Velnor rejected this job before workflow execution.
```

### 35192164244 / job 105113988409 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35192164244/job/105113988409

Class: unclassified. Raw SHA256: `78e041bbdc69a0e0d44ee7b74c6b27bac020946b0342fcdf85ffedd4b1601f06`.

```text
2026-09-17T07:24:28.3013639Z ##[error]Process completed with exit code 1.
```

### 35192164244 / job 105114018864 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35192164244/job/105114018864

Class: unclassified. Raw SHA256: `8b38195a046d70373149c0c5812803d4433be22677c4a1c2bf74a14529a518ba`.

```text
2026-09-17T07:24:34.0900202Z ##[error]Process completed with exit code 1.
```

### 35055050632 / job 104665009374 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35055050632/job/104665009374

Class: unclassified. Raw SHA256: `aae813cfb997ce5bf895ff0e4de38cb1faaec28e65a3f7374d84a64352a061ae`.

```text
2026-09-16T04:26:28.0186918Z ##[error]Process completed with exit code 1.
```

### 35055050632 / job 104665022706 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35055050632/job/104665022706

Class: unclassified. Raw SHA256: `7649f42264c4f0cdb9e94328066de4fb98dc628527229ff28b188621fe6b039f`.

```text
2026-09-16T04:26:32.3613861Z ##[error]Process completed with exit code 1.
```

### 35055050632 / job 104666083457 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35055050632/job/104666083457

Class: unclassified. Raw SHA256: `7e63cb657ad21bc5aea0ceecce8b67fd0b4abaa91890b0f488e91e5b37edbcc5`.

```text
2026-09-16T04:31:55.2095132Z ##[error]Process completed with exit code 1.
```

### 35055050632 / job 104666104437 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35055050632/job/104666104437

Class: unclassified. Raw SHA256: `7297b5c1c7ca7714391a78c2716ca3f04db6abed853d64056510fa3d482919bd`.

```text
2026-09-16T04:32:00.8755376Z ##[error]Process completed with exit code 1.
```

### 34030154079 / job 101483252270 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34030154079/job/101483252270

Class: unclassified. Raw SHA256: `4aaf2dd9dd9b1360dea28206c6a707b36137501c6ce741481c772030ded29871`.

```text
2026-09-06T12:05:09.6083789Z ##[error]Process completed with exit code 1.
```

### 34030154079 / job 101485221548 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/34030154079/job/101485221548

Class: unclassified. Raw SHA256: `3bde42aa11fd841d704a60fdbd6fc54b028193f9b78daf11254135a721e6239e`.

```text
2026-09-06T12:19:56.2107812Z ##[error]Process completed with exit code 1.
```

### 35479417419 / job 105994420932 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35479417419/job/105994420932

Class: test-failure. Raw SHA256: `481a9cdc463f93390d91bd13797dc7c3b2745a9791ef6425257e24513854bbdc`.

```text
2026-09-20T00:46:42.3956428Z     thread 'runner::tests::microvm_job_rejects_incomplete_plan_before_backend_side_effects' (27783) panicked at crates/velnor-runner/src/runner.rs:18308:9:
2026-09-20T00:46:48.9131308Z error: test run failed
2026-09-20T00:46:49.2234601Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-20T00:46:49.2326022Z ##[error]Process completed with exit code 1.
```

### 35479417419 / job 105994420965 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35479417419/job/105994420965

Class: test-failure. Raw SHA256: `8197732b538d27f05896c6c35eba04e6aea0169c8782d9da3773b9315490d372`.

```text
2026-09-20T00:48:15.9727822Z     thread 'primitives::release::tests::default_rows_render_the_legacy_release_surface' (27190) panicked at crates/velnor-workflow/src/primitives/release.rs:5818:9:
2026-09-20T00:48:15.9795459Z error: test run failed
2026-09-20T00:48:16.2644836Z error: CI command failed for unit rust-velnor-workflow with exit status: 100
2026-09-20T00:48:16.2715346Z ##[error]Process completed with exit code 1.
```

### 35479417419 / job 105995260543 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35479417419/job/105995260543

Class: unclassified. Raw SHA256: `5af1d9ea844972a33ffff032fde48ce6f713713c2e0585d1a31b411fada03358`.

```text
2026-09-20T00:48:35.4874274Z ##[error]Process completed with exit code 1.
```

### 35479417419 / job 105995267939 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35479417419/job/105995267939

Class: unclassified. Raw SHA256: `c5f0bfe5f7611fcb054a2d4d746528e2436c2bff328a71d6dacea390818b9f3f`.

```text
2026-09-20T00:48:40.0453915Z ##[error]Process completed with exit code 1.
```

### 31230559863 / job 93033417818 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/31230559863/job/93033417818

Class: unclassified. Raw SHA256: `8a964ca91bcc5e0cf14f50d2dda5b7a4a72a1a3f41966a6bcd7114e9ab88e5cb`.

```text
2026-08-08T00:36:20.6841807Z error: No such remote: 'origin'
```

### 31230559863 / job 93033417828 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/31230559863/job/93033417828

Class: unclassified. Raw SHA256: `d2e2c2402a79ffe5b635fd23bb9a52a4f262372d4ecd5f9ce1fac24cabb760bc`.

```text
2026-08-08T00:36:20.2751245Z error: No such remote: 'origin'
```

### 31230559863 / job 93033417833 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/31230559863/job/93033417833

Class: unclassified. Raw SHA256: `cc3ba2312a582219092b42004bc35a3d7ead558844b1ce423ea691df1c05d9b3`.

```text
2026-08-08T00:36:18.8832643Z error: No such remote: 'origin'
```

### 31230559863 / job 93033417854 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/31230559863/job/93033417854

Class: unclassified. Raw SHA256: `6f59243a2908b5a853c8eb5cb6c8e179cfb5fcbf31473f8aeb82c32d005fb956`.

```text
2026-08-08T00:36:19.3352303Z error: No such remote: 'origin'
```

### 31230559863 / job 93033417859 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/31230559863/job/93033417859

Class: unclassified. Raw SHA256: `39e3d29a43da2190ddc2acfe403d5a78b39e07296918054829d60b9fe1470ef4`.

```text
2026-08-08T00:36:19.7976706Z error: No such remote: 'origin'
```

### 34930642603 / job 104278126447 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/34930642603/job/104278126447

Class: rust-lint. Raw SHA256: `501868f62097d977f801c508f806ce08b4220995dcf0ac3ec1cc1f8645775e1d`.

```text
2026-09-15T06:33:00.0000000Z error[E0063]: missing field `trust_scope` in initializer of `velnor_runner::args::ConfigureArgs`
2026-09-15T06:33:00.0000000Z error: could not compile `velnorctl` (lib) due to 1 previous error
2026-09-15T06:33:00.0000000Z error: CI command failed for unit rust-production-topology with exit status: 101
```

### 34930642603 / job 104289458421 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/34930642603/job/104289458421

Class: unclassified. Raw SHA256: `1213674c416d3a466734bea6a91928d966a46ee7e53086dcdeca3854f3ba49f5`.

```text
2026-09-15T07:18:11.2607958Z ##[error]Process completed with exit code 3.
```

### 34930642603 / job 104289487260 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/34930642603/job/104289487260

Class: unclassified. Raw SHA256: `600446f5fd7cdeaa8034f380de467ee3aae5a23b3bceeeb0661d208b68162691`.

```text
2026-09-15T07:18:17.8528563Z ##[error]Process completed with exit code 1.
```

### 34930642603 / job 104301473663 / attempt 5

https://github.com/tailrocks/velnor/actions/runs/34930642603/job/104301473663

Class: test-failure. Raw SHA256: `2d1b1c65965cbfc4bac061c9a696b1ff4d372990b6f18e42fb0fbe8bd78ff7dd`.

```text
2026-09-15T08:22:01.0000000Z     thread 'container::tests::builds_start_container_args_with_mounts' (29318) panicked at crates/velnor-runner/src/container.rs:2414:9:
2026-09-15T08:22:01.0000000Z error: test run failed
2026-09-15T08:22:01.0000000Z error: CI command failed for unit rust-velnor-runner with exit status: 100
```

### 34930642603 / job 104307349422 / attempt 5

https://github.com/tailrocks/velnor/actions/runs/34930642603/job/104307349422

Class: unclassified. Raw SHA256: `410536985880fa94230ed3fcc1846382b37ffbf0904a723678105633a6aa9b38`.

```text
2026-09-15T08:22:28.2102407Z ##[error]Process completed with exit code 3.
```

### 34930642603 / job 104307374798 / attempt 5

https://github.com/tailrocks/velnor/actions/runs/34930642603/job/104307374798

Class: unclassified. Raw SHA256: `cd8b0355b31b5b9f5dadd1d3caebe220c19a56fcfa27f1993c5b843b1aed106e`.

```text
2026-09-15T08:22:33.7157824Z ##[error]Process completed with exit code 1.
```

### 35136207272 / job 104929109627 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35136207272/job/104929109627

Class: unclassified. Raw SHA256: `e85115954daaa3c6ad6c611dfc236ca2019629b120149a701c161c96aed80963`.

```text
2026-09-16T18:44:08.9850808Z ##[error]no runtime product for revision 48a66ad7d56636f8bfa6069fbaf810d0089fef39 (closure f1f88c200e5b3b82); the mainline runtime-product publisher builds it after merge
2026-09-16T18:44:08.9854212Z ##[error]Process completed with exit code 1.
```

### 35136207272 / job 104929236136 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35136207272/job/104929236136

Class: unclassified. Raw SHA256: `3f479f711ba64339fde19a26c21f7f7e609bc1f1044d990d5cd39a284b72225b`.

```text
2026-09-16T18:44:15.9249223Z ##[error]Process completed with exit code 1.
```

### 35136207272 / job 104929270632 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35136207272/job/104929270632

Class: unclassified. Raw SHA256: `4025e0cc51bd7c36f11ffa4e85dfa8ee6b43e9b2acb9a80ec6bcc7b4db870451`.

```text
2026-09-16T18:44:23.7118129Z ##[error]Process completed with exit code 1.
```

### 35136207272 / job 104931563251 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35136207272/job/104931563251

Class: unclassified. Raw SHA256: `fa4b0e15d6ea3bc00bdbc729b7a34089cb531406e40175f749a0c06b11ae62e2`.

```text
2026-09-16T18:50:57.8701605Z ##[error]Velnor rejected this job before workflow execution.
```

### 35136207272 / job 104931564744 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35136207272/job/104931564744

Class: unclassified. Raw SHA256: `5348894c552c26f276d42e55898aadc8d3358928cc733812dded19705147d93a`.

```text
2026-09-16T18:51:57.9684627Z ##[error]Velnor rejected this job before workflow execution.
```

### 35136207272 / job 104931565302 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35136207272/job/104931565302

Class: unclassified. Raw SHA256: `38c26681c331e8f3127147baa751b7c906c093e399ff45fd51c025fb27921a0c`.

```text
2026-09-16T18:52:10.6373145Z error: revision 48a66ad7d56636f8bfa6069fbaf810d0089fef39 is not a commit of /home/runner/work/velnor/velnor
2026-09-16T18:52:10.7019702Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
2026-09-16T18:52:10.7089825Z ##[error]Process completed with exit code 1.
```

### 35136207272 / job 104933340151 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35136207272/job/104933340151

Class: unclassified. Raw SHA256: `78f86e2cbd44086a980fe40f3ef8d5b5dc52bac0c2633d2cce2ff5962980848e`.

```text
2026-09-16T18:56:06.2347140Z ##[error]Process completed with exit code 1.
```

### 35136207272 / job 104933365631 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35136207272/job/104933365631

Class: unclassified. Raw SHA256: `a957aad5cae1b73deecb21dfb198ac92d22d9628235b03d104d30a765a6d3c4d`.

```text
2026-09-16T18:56:11.1515712Z ##[error]Process completed with exit code 1.
```

### 35522583904 / job 106109107399 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35522583904/job/106109107399

Class: generated-tree. Raw SHA256: `77bb1063fd553b9b42f789f8bb54775317e337659174a19add44aceabddfb110`.

```text
2026-09-20T16:24:38.5425100Z error: workflow policy failed: generated-tree
2026-09-20T16:24:38.5436169Z FAIL generated-tree         the tree differs from the render of velnor-workflow at 38dbf85e0bbf278cee3ec39ab90a9acc9b5b67a9
2026-09-20T16:24:38.5461644Z ##[error]Process completed with exit code 1.
```

### 35487076653 / job 106015352830 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35487076653/job/106015352830

Class: generated-tree;candidate-product. Raw SHA256: `d436a59e589cf7d9dc7b53a43bee66578c6879936cb46887b7429d9cce5061af`.

```text
2026-09-20T03:48:35.9865114Z error: workflow policy failed: generated-tree
2026-09-20T03:48:35.9871614Z FAIL generated-tree         could not regenerate the tree with velnor-workflow at 325719f1e05d3d46322c9fd3eeb9ad545e175638
2026-09-20T03:48:35.9891083Z ##[error]Process completed with exit code 1.
```

### 35487937881 / job 106017632162 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35487937881/job/106017632162

Class: candidate-product. Raw SHA256: `9be12725b7f4ac9a5d223d544cef941316ed6f1aa7ac8be81bcb94f8667304f6`.

```text
2026-09-20T04:07:52.1656548Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-70fe7766c147da8c-Linux-X64
2026-09-20T04:07:52.1666265Z ##[error]Process completed with exit code 1.
```

### 35472351533 / job 105975486488 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35472351533/job/105975486488

Class: generated-tree;candidate-product. Raw SHA256: `bae3f7ae012f1850406d8faa71a93d5ba2950014c8f5ae73225ad0d0762947ad`.

```text
2026-09-19T22:06:28.2511526Z error: generated files match but generation inputs changed: scan input changed from 8d96315cc857133b to 6b45276e6221b217 in .github/ci/.github-actions-generator-state; regenerate to record the current generation inputs
2026-09-19T22:16:07.1023961Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-357845bacd21d340-Linux-X64
2026-09-19T22:16:07.1032581Z ##[error]Process completed with exit code 1.
```

### 35517543010 / job 106095932207 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35517543010/job/106095932207

Class: unclassified. Raw SHA256: `081161a8ec0d231992e262b11c1e0fe70c9efab2e730c37fcad37c598c0a6d24`.

```text
2026-09-20T14:49:32.3479791Z error: enum `AdoptMaxJobs` is never used
2026-09-20T14:49:32.3483935Z error: function `adopt_max_jobs` is never used
2026-09-20T14:49:32.3487656Z error: could not compile `velnor-runner` (lib) due to 2 previous errors
2026-09-20T14:49:32.3941120Z error: CI command failed for unit rust-velnorctl with exit status: 101
2026-09-20T14:49:32.4060117Z ##[error]Process completed with exit code 1.
```

### 35517543010 / job 106095932228 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35517543010/job/106095932228

Class: test-failure. Raw SHA256: `218be48f34114d35163c6128bb3821e75bbd02c006ae8cca689522608871c8a7`.

```text
2026-09-20T14:51:53.9607673Z     thread 'executor::tests::native_docker_adapters_invoke_docker_cli_without_node_sidecars' (24373) panicked at crates/velnor-runner/src/executor.rs:19529:9:
2026-09-20T14:51:53.9608926Z       left: 6
2026-09-20T14:51:53.9609185Z      right: 7
2026-09-20T14:51:54.5003322Z error: test run failed
2026-09-20T14:51:54.9876653Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-20T14:51:54.9959207Z ##[error]Process completed with exit code 1.
```

### 35517543010 / job 106095932250 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35517543010/job/106095932250

Class: unclassified. Raw SHA256: `538b076b509f5dea03c5f1433fce35e073bcbf1b77a008e9188431253675c6ab`.

```text
2026-09-20T14:48:53.4628390Z error: enum `AdoptMaxJobs` is never used
2026-09-20T14:48:53.4633599Z error: function `adopt_max_jobs` is never used
2026-09-20T14:48:53.4636316Z error: could not compile `velnor-runner` (lib) due to 2 previous errors
2026-09-20T14:48:53.5002126Z error: CI command failed for unit rust-velnor-bench with exit status: 101
2026-09-20T14:48:53.5062974Z ##[error]Process completed with exit code 1.
```

### 35517543010 / job 106095932269 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35517543010/job/106095932269

Class: test-failure. Raw SHA256: `c34a38e1b4674c83b943698ab3f45c616a3e345f25b05012b6d7de5ce3cb1a9f`.

```text
2026-09-20T14:48:05.7869757Z     thread 'permit_ledger::tests::startup_sweep_retains_uncertain_even_when_process_is_dead' (3364) panicked at crates/velnor-control/src/permit_ledger.rs:2012:9:
2026-09-20T14:48:05.7871072Z       left: ["dead"]
2026-09-20T14:48:05.7871315Z      right: []
2026-09-20T14:48:05.8595447Z error: test run failed
2026-09-20T14:48:05.8710491Z error: CI command failed for unit rust-velnor-control with exit status: 100
2026-09-20T14:48:05.8770946Z ##[error]Process completed with exit code 1.
```

### 35517543010 / job 106095932287 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35517543010/job/106095932287

Class: generated-tree. Raw SHA256: `e6763ecc898edbafb12d8ca616d78c49b90adbe92de590bf3337625141670866`.

```text
2026-09-20T14:48:30.7395946Z error: generated files match but generation inputs changed: scan input changed from b096c93329fcc370 to 5691f3c8c8b8d479 in .github/ci/.github-actions-generator-state; regenerate to record the current generation inputs
2026-09-20T14:48:30.7429386Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
2026-09-20T14:48:30.7491786Z ##[error]Process completed with exit code 1.
```

### 35517543010 / job 106096542113 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35517543010/job/106096542113

Class: unclassified. Raw SHA256: `f90c2ec0973bbcaf1e9d28bd649aba1f57b715f8da7547c65b5e9f151bca5c70`.

```text
2026-09-20T14:52:00.4556029Z ##[error]Process completed with exit code 1.
```

### 35517543010 / job 106096549941 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35517543010/job/106096549941

Class: unclassified. Raw SHA256: `23da21eaf331d8ac97e03ceade4fefa250490c0d648634e83bfa9efb972505e0`.

```text
2026-09-20T14:52:05.1630500Z ##[error]Process completed with exit code 1.
```

### 35479732671 / job 105995277491 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35479732671/job/105995277491

Class: unclassified. Raw SHA256: `0a26229925051f1ddd52e2c952ffb62a06fdc5def7fead0cfde8a03658d84a4f`.

```text
2026-09-20T00:51:47.6275009Z error: variables can be used directly in the `format!` string
2026-09-20T00:51:47.6283761Z error: could not compile `velnor-workflow` (lib test) due to 1 previous error
2026-09-20T00:51:47.6688721Z error: CI command failed for unit rust-velnor-workflow with exit status: 101
2026-09-20T00:51:47.6755296Z ##[error]Process completed with exit code 1.
```

### 35479732671 / job 105996322254 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35479732671/job/105996322254

Class: unclassified. Raw SHA256: `f37744bb3ad4bac6855b4b343554a8cc63b0819c1d1e36d2129a41742627d66e`.

```text
2026-09-20T00:57:45.8995683Z ##[error]Process completed with exit code 1.
```

### 35479732671 / job 105996330920 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35479732671/job/105996330920

Class: unclassified. Raw SHA256: `9720c1bf7ce9fda8927a0c18a543fe468f54225f28eef2a58f1396006a6e8d0f`.

```text
2026-09-20T00:57:50.2776723Z ##[error]Process completed with exit code 1.
```

### 35462720153 / job 105949366513 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35462720153/job/105949366513

Class: generated-tree;candidate-product. Raw SHA256: `e2467eae93b40c50ac291e2f96f54bc96ce4c3a16a6bb964184ffac6ddcd5e31`.

```text
2026-09-19T18:55:43.9229954Z error: generated files differ: .github/workflows/ci-unit-rust.yml, .github/workflows/preview.yml, .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-19T19:10:52.7478139Z ##[error]no candidate product velnor-workflow-candidate-28517ef7a1a6bfcf-Linux-X64 was published within 15 minutes
2026-09-19T19:10:52.7487523Z ##[error]Process completed with exit code 1.
```

### 32827508106 / job 97740350712 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32827508106/job/97740350712

Class: unclassified. Raw SHA256: `fe17227cbe8854c00e1cd9b9af0558000f52139573fd5b4715e8e2158357ba4a`.

```text
2026-08-25T08:43:01.8847984Z ##[error]Process completed with exit code 1.
```

### 32827508106 / job 97740382645 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32827508106/job/97740382645

Class: unclassified. Raw SHA256: `fd38439918586865b637685a9aef24b3b5b2168ef9965308fad3dfc7a0a91c0a`.

```text
2026-08-25T08:43:09.6817520Z ##[error]Process completed with exit code 1.
```

### 35485125749 / job 106010025464 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35485125749/job/106010025464

Class: unclassified. Raw SHA256: `87bccd1371e7ecde583fe372ae229a17249190bc5f1df069f9c7c0a2533484c7`.

```text
2026-09-20T02:57:36.6724685Z error: this function has too many lines (102/100)
2026-09-20T02:57:36.6731201Z error: could not compile `velnor-workflow` (lib) due to 1 previous error
2026-09-20T02:57:38.1370274Z error: CI command failed for unit rust-velnor-workflow with exit status: 101
2026-09-20T02:57:38.1430724Z ##[error]Process completed with exit code 1.
```

### 35485125749 / job 106010537601 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35485125749/job/106010537601

Class: unclassified. Raw SHA256: `1e8f3d16eadb7e6253357d4cac2622f61f990f7045b303de4df7dfb866fd960f`.

```text
2026-09-20T02:57:45.8191118Z ##[error]Process completed with exit code 1.
```

### 35485125749 / job 106010544357 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35485125749/job/106010544357

Class: unclassified. Raw SHA256: `5cfb394589113b7d7ed1fcb115b0c1bb547b8cee4904e34ea7e2ffb5784c6051`.

```text
2026-09-20T02:57:50.2941546Z ##[error]Process completed with exit code 1.
```

### 35467711588 / job 105962988435 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35467711588/job/105962988435

Class: generated-tree;candidate-product. Raw SHA256: `92a8d86ed04f4ef75d6df5aa597711052050597e8d8a8a264d061cc304ed4fef`.

```text
2026-09-19T20:33:00.9697143Z error: generated files differ: .github/workflows/ci-unit-rust.yml, .github/workflows/preview.yml, .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-19T20:48:07.9390164Z ##[error]no candidate product velnor-workflow-candidate-0c304c147d66fcdf-Linux-X64 was published within 15 minutes
2026-09-19T20:48:07.9399922Z ##[error]Process completed with exit code 1.
```

### 35467711588 / job 105965092265 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35467711588/job/105965092265

Class: unclassified. Raw SHA256: `f52f06a94879122934e14cca0711ca5bd62ccc53e19b0fef4d973deb3e238ee9`.

```text
2026-09-19T20:48:14.5628464Z ##[error]Process completed with exit code 1.
```

### 35467711588 / job 105965102272 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35467711588/job/105965102272

Class: unclassified. Raw SHA256: `58b2d3987e73939c806933ba605bd09d59719e5c7cfb6f7972d11f618d7c3f82`.

```text
2026-09-19T20:48:19.0451207Z ##[error]Process completed with exit code 1.
```

### 33550648096 / job 99998996202 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33550648096/job/99998996202

Class: test-failure. Raw SHA256: `0f624405d8e887f315343ec45b5c2e6fe009eddd5d99444342fc6de887ab34e9`.

```text
2026-09-01T19:41:10.8766446Z     thread 'tests::concurrent_opens_serialize_legacy_metadata_migration' (6527) panicked at crates/velnor-cache-service/src/lib.rs:1808:26:
2026-09-01T19:41:57.9099044Z error: test run failed
2026-09-01T19:41:57.9181111Z ##[error]Process completed with exit code 100.
```

### 33550648096 / job 100000199463 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33550648096/job/100000199463

Class: unclassified. Raw SHA256: `7958f0bc0c7a8fb43b934306c52e85c7892ff96017912d64284dbcf10e30e241`.

```text
2026-09-01T19:42:04.3997624Z ##[error]Process completed with exit code 1.
```

### 33550648096 / job 100000233499 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33550648096/job/100000233499

Class: unclassified. Raw SHA256: `15e61d8ba784d90a9c9947c0d848a91e2398564037fe4a83fd9dcea2842bcb24`.

```text
2026-09-01T19:42:11.4367126Z ##[error]Process completed with exit code 1.
```

### 35513671130 / job 106085868142 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35513671130/job/106085868142

Class: generated-tree. Raw SHA256: `4b1612d057ab61e67358316b9f6502b7cedab5d8ced1835575512fdad246ed82`.

```text
2026-09-20T13:30:02.2472662Z error: workflow policy failed: generated-tree
2026-09-20T13:30:02.2481708Z FAIL generated-tree         the tree differs from the render of velnor-workflow at 4fa7a3a85f141a6bb95bc9bdf0eef9e3ddde165d
2026-09-20T13:30:02.2499943Z ##[error]Process completed with exit code 1.
```

### 32858270677 / job 97838958783 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32858270677/job/97838958783

Class: unclassified. Raw SHA256: `ea86794ce2ed408c8ffb9740a233e6f2976883ea102e24d8c3ba9a9c0713380c`.

```text
2026-08-25T14:24:29.0038898Z ##[error]Process completed with exit code 1.
```

### 35478246445 / job 105991193467 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35478246445/job/105991193467

Class: unclassified. Raw SHA256: `5659dd4d3a24507739504323d61b12061077b65ed20bfbbebbabf02d6cfe57d3`.

```text
2026-09-20T00:15:23.0556500Z ##[error]no runtime product for revision 044ec732757f5d64259c4839e10161a5acb7fe23 (closure e0a19bd74d3d8bdb); the mainline runtime-product publisher builds it after merge
2026-09-20T00:15:23.0562201Z ##[error]Process completed with exit code 1.
```

### 35478246445 / job 105991295256 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35478246445/job/105991295256

Class: unclassified. Raw SHA256: `82fd9c73f01e1b3cd0b9425ef4c57eb4935bf41316da8100a92666e6d1864844`.

```text
2026-09-20T00:15:28.6197987Z ##[error]Process completed with exit code 1.
```

### 35478246445 / job 105991304549 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35478246445/job/105991304549

Class: unclassified. Raw SHA256: `74ade3bb87af4fd5fd7b4c9bdf816db32260d218dba37a56dfdbe921ebeeac9d`.

```text
2026-09-20T00:15:34.0100568Z ##[error]Process completed with exit code 1.
```

### 34767084746 / job 103749866272 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34767084746/job/103749866272

Class: unclassified. Raw SHA256: `21afd0c8f6d728f216884ad603699949b0a457d56c6a48d45f468ff4f094ff6d`.

```text
2026-09-13T15:57:57.0000000Z error: failed to clone into: /__t/velnor-workflow-cargo-home/git/db/velnor-09f3d470aa1f0308
```

### 34767084746 / job 103750138210 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34767084746/job/103750138210

Class: unclassified. Raw SHA256: `8c075e6cf3c02ed756ee8b8165103acfeebfe398b29481fe646375b83b701795`.

```text
2026-09-13T16:00:08.0000000Z error: failed to clone into: /__t/velnor-workflow-cargo-home/git/db/velnor-09f3d470aa1f0308
```

### 35513671171 / job 106085870747 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35513671171/job/106085870747

Class: generated-tree;candidate-product. Raw SHA256: `9744f9184579cb6573ed9a690ae4ac334ae2f2b3b83fd4af1d1118b573ed9589`.

```text
2026-09-20T13:30:09.8009705Z error: generated files differ: .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T13:45:18.0638767Z ##[error]no candidate product velnor-workflow-candidate-9e6bb04aed5e5a89-Linux-X64 was published within 15 minutes
2026-09-20T13:45:18.0647878Z ##[error]Process completed with exit code 1.
```

### 35513671171 / job 106087855255 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35513671171/job/106087855255

Class: unclassified. Raw SHA256: `4e4fbf18c1c1b2547d9886cdfe7438a74c6d2427429615cea6a00dc169720fb9`.

```text
2026-09-20T13:45:25.9281939Z ##[error]Process completed with exit code 1.
```

### 35513671171 / job 106087863646 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35513671171/job/106087863646

Class: unclassified. Raw SHA256: `bbf2159357a22c8c83f51a67f25c37acfe31b6cd79950033f79de8fa783c426b`.

```text
2026-09-20T13:45:30.4041759Z ##[error]Process completed with exit code 1.
```

### 32642268104 / job 97201118053 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32642268104/job/97201118053

Class: unclassified. Raw SHA256: `ef9ce0ccf7db5ca58809c032eaa92a03a5779361ee8a444d66026b54d0348f38`.

```text
2026-08-23T13:25:14.5684493Z ##[error]Process completed with exit code 1.
```

### 32642268104 / job 97201129245 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32642268104/job/97201129245

Class: unclassified. Raw SHA256: `be89fe3251057873d606851439e17f03299faa3575683e943e6e8dd705c79660`.

```text
2026-08-23T13:25:20.1904664Z ##[error]Process completed with exit code 1.
```

### 35484148349 / job 106007310957 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35484148349/job/106007310957

Class: test-failure. Raw SHA256: `41ac61d2153edaf3a65e0e4f9d7eae9559ca5301f71ff39d4265c913794863a1`.

```text
2026-09-20T02:34:19.1319507Z     thread 's2::primitives::package_release::tests::typed_draft_cleanup_refuses_release_state_and_tag_drift' (10039) panicked at crates/velnor-workflow/src/s2/primitives/package_release.rs:3112:13:
2026-09-20T02:34:23.9596442Z error: test run failed
2026-09-20T02:34:23.9699740Z error: CI command failed for unit rust-velnor-workflow with exit status: 100
2026-09-20T02:34:23.9756537Z ##[error]Process completed with exit code 1.
```

### 35484148349 / job 106007794538 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35484148349/job/106007794538

Class: unclassified. Raw SHA256: `8fad0e44307d9084648b4461213457b2c3a39117c2ea2b834ca56ab880c708bc`.

```text
2026-09-20T02:34:31.2083399Z ##[error]Process completed with exit code 1.
```

### 35484148349 / job 106007808639 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35484148349/job/106007808639

Class: unclassified. Raw SHA256: `d8d92b794c606c571c35af26979da484ccb4bca8a694105198a7093bb8af4490`.

```text
2026-09-20T02:34:36.7368758Z ##[error]Process completed with exit code 1.
```

### 35483626262 / job 106005805483 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35483626262/job/106005805483

Class: generated-tree;candidate-product. Raw SHA256: `d96867a3cb5d460293be25b235a9f90a414619ab2fb834c9172a1f38ec80a45c`.

```text
2026-09-20T02:23:10.4947853Z error: workflow policy failed: generated-tree
2026-09-20T02:23:10.4955678Z FAIL generated-tree         could not regenerate the tree with velnor-workflow at 325719f1e05d3d46322c9fd3eeb9ad545e175638
2026-09-20T02:23:10.4974467Z ##[error]Process completed with exit code 1.
```

### 35499213737 / job 106047830762 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35499213737/job/106047830762

Class: generated-tree;candidate-product. Raw SHA256: `d4f2ff1cd67e8ce94f75f163e88a8a47b79add31de9ca908b069d53f035b1c20`.

```text
2026-09-20T08:19:02.6842508Z error: generated files differ: .github/actionlint.yaml, .github/ci/project.toml, .github/workflows/ci-main.yml, .github/workflows/ci-pr.yml, .github/workflows/ci-runtime-products.yml, .github/workflows/ci-unit-bun.yml, .github/workflows/ci-unit-docker.yml, .github/workflows/ci-unit-docs.yml, .github/workflows/ci-unit-opentofu.yml, .github/workflows/ci-unit-rust.yml, .github/workflows/preview.yml, .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T08:34:04.5741601Z ##[error]no candidate product velnor-workflow-candidate-52e54c00051de431-Linux-X64 was published within 15 minutes
2026-09-20T08:34:04.5751342Z ##[error]Process completed with exit code 1.
```

### 35499213737 / job 106049715182 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35499213737/job/106049715182

Class: unclassified. Raw SHA256: `5d0d2f8909f8f6316f5dae9096329aa89b5a0f3fbe5a5f257947454a9cba839c`.

```text
2026-09-20T08:34:10.8892333Z ##[error]Process completed with exit code 1.
```

### 35499213737 / job 106049725329 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35499213737/job/106049725329

Class: unclassified. Raw SHA256: `c12072f58bc6a76831e389907fe81c9fb33663c96a16809534a277998f50ce92`.

```text
2026-09-20T08:34:15.3331187Z ##[error]Process completed with exit code 1.
```

### 35484350008 / job 106008630982 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35484350008/job/106008630982

Class: unclassified. Raw SHA256: `c283828857510c81cc95534cad1e88dc751f8bd4cbc76581688b6df4b2bbd1d7`.

```text
2026-09-20T02:41:33.0416845Z error: CI command failed for unit docs with exit status: 1
2026-09-20T02:41:33.0466812Z ##[error]Process completed with exit code 1.
```

### 35484350008 / job 106009715710 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35484350008/job/106009715710

Class: unclassified. Raw SHA256: `30136682d3b37981a8809593dcd379b11fcbd71301f5fea0708d885b85052dcb`.

```text
2026-09-20T02:50:34.4030998Z ##[error]Process completed with exit code 1.
```

### 35484350008 / job 106009730068 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35484350008/job/106009730068

Class: unclassified. Raw SHA256: `f9209ed7f05f3540ba48e0d94fa37398436b267c728ecc2246bead1f073b02ce`.

```text
2026-09-20T02:50:40.8193653Z ##[error]Process completed with exit code 1.
```

### 35489959146 / job 106023512511 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35489959146/job/106023512511

Class: rust-lint. Raw SHA256: `85db2ec4036ccdb8b9d016726a5610415796786e0e1c1ae850b5a39477ab967f`.

```text
2026-09-20T04:53:31.0303276Z error: unused imports: `SystemTime` and `UNIX_EPOCH`
2026-09-20T04:53:31.0305884Z error: could not compile `velnor-workflow` (lib) due to 1 previous error
2026-09-20T04:53:33.0755141Z error: CI command failed for unit rust-velnor-workflow with exit status: 101
2026-09-20T04:53:33.0808337Z ##[error]Process completed with exit code 1.
```

### 35489959146 / job 106024387909 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35489959146/job/106024387909

Class: unclassified. Raw SHA256: `13e075dc2643bb2400f5f954d9af26f5184c6fa474437624d26553a21e39453d`.

```text
2026-09-20T04:58:09.7443818Z ##[error]Process completed with exit code 1.
```

### 35489959146 / job 106024394426 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35489959146/job/106024394426

Class: unclassified. Raw SHA256: `311d3cda97c15ca0767e9a45514f1c849e09a266e151581df2c42404e7fd4f73`.

```text
2026-09-20T04:58:13.7165966Z ##[error]Process completed with exit code 1.
```

### 35151363172 / job 104980295127 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35151363172/job/104980295127

Class: unclassified. Raw SHA256: `88c5c06c7ef978ff97a44bcddd7a532b49684af6b196a9c1b691a364dd898636`.

```text
2026-09-16T21:15:57.9887903Z ##[error]Velnor rejected this job before workflow execution.
```

### 35151363172 / job 104981474344 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35151363172/job/104981474344

Class: unclassified. Raw SHA256: `1983f4bc31b0545ae80deffc4b7c5886211b6dc923290675ceb0e20dba830cd5`.

```text
2026-09-16T21:19:40.4475476Z ##[error]Process completed with exit code 1.
```

### 35151363172 / job 104981517209 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35151363172/job/104981517209

Class: unclassified. Raw SHA256: `f47b38fe8f2decaf0195755c8212c1d6029f5876d697f6645bbc8496ff40c34a`.

```text
2026-09-16T21:19:47.1208710Z ##[error]Process completed with exit code 1.
```

### 35151363172 / job 104987113974 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35151363172/job/104987113974

Class: unclassified. Raw SHA256: `3911fdd2318dd09a7eccc045893cd567eb9b30cfaeaba85aa4554121c23c7a9a`.

```text
2026-09-16T21:37:59.6314665Z ##[error]Velnor rejected this job before workflow execution.
```

### 35151363172 / job 104987150025 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35151363172/job/104987150025

Class: unclassified. Raw SHA256: `21b4aad160531f76bddfce2f6c4e8c9599a652d13ae1bfb5726ce4a3595a407a`.

```text
2026-09-16T21:38:06.0423046Z ##[error]Process completed with exit code 1.
```

### 35151363172 / job 104987176987 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35151363172/job/104987176987

Class: unclassified. Raw SHA256: `8dae21dde472c0ad4a1557a7f7bd72216bb1b5e1001f30f2f0dabb798959bf71`.

```text
2026-09-16T21:38:11.4629419Z ##[error]Process completed with exit code 1.
```

### 32774303044 / job 97583080133 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32774303044/job/97583080133

Class: unclassified. Raw SHA256: `ad1e78b991ce0266407ea6656e6425eeeccd8bf79f55609a9b2d87ade16c3178`.

```text
2026-08-24T20:35:28.6876925Z error: No such remote: 'origin'
```

### 32774303044 / job 97583080156 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32774303044/job/97583080156

Class: unclassified. Raw SHA256: `261399afe559a1051ebcac4f9e19c9193662e03b29ca4daa83795d04cf2b7e86`.

```text
2026-08-24T20:35:29.2172592Z error: No such remote: 'origin'
```

### 32774303044 / job 97583080217 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32774303044/job/97583080217

Class: unclassified. Raw SHA256: `a11e362640c8897d201d4a7e37bafd93d6db73dc9d7ca15dd2f817b2619142d9`.

```text
2026-08-24T20:35:57.4757053Z error: No such remote: 'origin'
```

### 32774303044 / job 97585630660 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/32774303044/job/97585630660

Class: unclassified. Raw SHA256: `0af98bc26424278a51525dcf50e53cb6a1b21e035a515f137a315b9b648c84af`.

```text
2026-08-24T20:43:56.1554692Z error: No such remote: 'origin'
2026-08-24T20:47:43.0000000Z ##[error]deb missing usr/bin/velnorctl
```

### 32774303044 / job 97585630766 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/32774303044/job/97585630766

Class: unclassified. Raw SHA256: `8da3e9388f8d9bf3ad97f187b869ac9eff31fac5519db6ba58eb4e8f15677e0b`.

```text
2026-08-24T20:43:55.6719480Z error: No such remote: 'origin'
2026-08-24T20:47:42.0000000Z ##[error]deb missing usr/bin/velnorctl
```

### 35517158916 / job 106094955634 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35517158916/job/106094955634

Class: unclassified. Raw SHA256: `dda3c79761fc3e49532546ac8396cdccd33c2e8725e8c2b5343a0d4cf8dd771d`.

```text
2026-09-20T14:42:11.0648890Z error: enum `AdoptMaxJobs` is never used
2026-09-20T14:42:11.0651408Z error: function `adopt_max_jobs` is never used
2026-09-20T14:42:11.0655404Z error: could not compile `velnor-runner` (lib) due to 2 previous errors
2026-09-20T14:42:11.1008767Z error: CI command failed for unit rust-velnorctl with exit status: 101
2026-09-20T14:42:11.1062324Z ##[error]Process completed with exit code 1.
```

### 35517158916 / job 106094955793 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35517158916/job/106094955793

Class: test-failure. Raw SHA256: `efb3432f8b3ef495273e59b1a1fcd5147914948ad13ea6643b3603f1b63cd778`.

```text
2026-09-20T14:45:07.3401168Z     thread 'executor::tests::native_docker_adapters_invoke_docker_cli_without_node_sidecars' (24798) panicked at crates/velnor-runner/src/executor.rs:19529:9:
2026-09-20T14:45:07.3403049Z       left: 6
2026-09-20T14:45:07.3403599Z      right: 7
2026-09-20T14:45:09.1236419Z error: test run failed
2026-09-20T14:45:09.6755123Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-20T14:45:09.6848842Z ##[error]Process completed with exit code 1.
```

### 35517158916 / job 106094955814 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35517158916/job/106094955814

Class: unclassified. Raw SHA256: `3a917fe0ff65c5eff689a8ebcab8d9a2cd51663815ee33728a3e19f86f9f523d`.

```text
2026-09-20T14:41:40.2230715Z error: enum `AdoptMaxJobs` is never used
2026-09-20T14:41:40.2235068Z error: function `adopt_max_jobs` is never used
2026-09-20T14:41:40.2238432Z error: could not compile `velnor-runner` (lib) due to 2 previous errors
2026-09-20T14:41:40.2637073Z error: CI command failed for unit rust-velnor-bench with exit status: 101
2026-09-20T14:41:40.2699475Z ##[error]Process completed with exit code 1.
```

### 35517158916 / job 106094955815 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35517158916/job/106094955815

Class: generated-tree. Raw SHA256: `ee23f718b6c0f1c58338e976bd8b7129b2dcaf15bc07c62b8cb893977782eebc`.

```text
2026-09-20T14:41:30.8662405Z error: generated files match but generation inputs changed: scan input changed from b096c93329fcc370 to 5691f3c8c8b8d479 in .github/ci/.github-actions-generator-state; regenerate to record the current generation inputs
2026-09-20T14:41:30.8691658Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
2026-09-20T14:41:30.8750750Z ##[error]Process completed with exit code 1.
```

### 35517158916 / job 106095659948 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35517158916/job/106095659948

Class: unclassified. Raw SHA256: `47a8bb5e76ac9a4d2ac08cfe97ff05c269b1bc9fe590818dfc6a88762cb44128`.

```text
2026-09-20T14:45:17.6816358Z ##[error]Process completed with exit code 1.
```

### 35517158916 / job 106095670769 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35517158916/job/106095670769

Class: unclassified. Raw SHA256: `9d24c7e44b7284218152b972c7c13c4a3135f2dfc9903bfe687067865249ea99`.

```text
2026-09-20T14:45:21.6611095Z ##[error]Process completed with exit code 1.
```

### 32828029321 / job 97742306703 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32828029321/job/97742306703

Class: unclassified. Raw SHA256: `55b68c8687bd8a75ca93a10671244597b7e9c945e710656617f31f38be779449`.

```text
2026-08-25T08:50:15.2486554Z ##[error]Process completed with exit code 1.
```

### 32828029321 / job 97742327836 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32828029321/job/97742327836

Class: unclassified. Raw SHA256: `e820f41ba8db257db76bc62436994b8a8122074a68835e4d9d230d641b6ed8bd`.

```text
2026-08-25T08:50:19.5299697Z ##[error]Process completed with exit code 1.
```

### 35486422681 / job 106014284917 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35486422681/job/106014284917

Class: generated-tree. Raw SHA256: `21f9a7d9c750a03b7a7185a1d8ea636f5a55bceeb340918b5d84f598a30734ad`.

```text
2026-09-20T03:31:04.9663396Z error: generated files differ: .github/actionlint.yaml, .github/workflows/ci-main.yml, .github/workflows/ci-pr.yml, .github/workflows/ci-runtime-products.yml, .github/workflows/ci-unit-bun.yml, .github/workflows/ci-unit-docker.yml, .github/workflows/ci-unit-docs.yml, .github/workflows/ci-unit-opentofu.yml, .github/workflows/ci-unit-rust.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T03:31:04.9691095Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
2026-09-20T03:31:04.9758243Z ##[error]Process completed with exit code 1.
```

### 35486422681 / job 106015375475 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35486422681/job/106015375475

Class: unclassified. Raw SHA256: `02c9e66b50dd49fa73246f6044f154a5ada6984d56af40c847f63d7ecca23312`.

```text
2026-09-20T03:38:29.8753894Z ##[error]Process completed with exit code 1.
```

### 35486422681 / job 106015383535 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35486422681/job/106015383535

Class: unclassified. Raw SHA256: `c05105c0ee105a861162edb1caf72c4361dd621ba3053ac389458b596d892d3e`.

```text
2026-09-20T03:38:35.9974574Z ##[error]Process completed with exit code 1.
```

### 34026985573 / job 101469635789 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34026985573/job/101469635789

Class: test-failure. Raw SHA256: `a6c62c59be7ee8664e302ca9eaa239e251a34f75a6e1824eb4c08c79d16a2078`.

```text
2026-09-06T10:19:47.9962001Z     thread 'supervised_controller_capacity_is_exact_for_one_and_four' (8472) panicked at crates/velnor-runner/tests/node_arch.rs:788:63:
2026-09-06T10:20:02.9763102Z error: test run failed
2026-09-06T10:20:02.9859673Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-06T10:20:02.9875044Z ##[error]Process completed with exit code 1.
```

### 35143815148 / job 104954688541 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35143815148/job/104954688541

Class: unclassified. Raw SHA256: `c63ee782c9071f2b312dfc2ff5f5be9a0501efab0461c0f8c3d6eb70aaffd384`.

```text
2026-09-16T19:59:26.5423903Z ##[error]no runtime product for revision cea85658ea7e7046445e69e84808b315f7658016 (closure d39cbf21e351b410); the mainline runtime-product publisher builds it after merge
2026-09-16T19:59:26.5427115Z ##[error]Process completed with exit code 1.
```

### 35143815148 / job 104954771489 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35143815148/job/104954771489

Class: unclassified. Raw SHA256: `9c1cee94e2bf4fa11c5fd5455adc0781f5c26e0d3cb787ffae8d104cc5148a59`.

```text
2026-09-16T19:59:33.3301349Z ##[error]Process completed with exit code 1.
```

### 35143815148 / job 104954794136 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35143815148/job/104954794136

Class: unclassified. Raw SHA256: `87577c1ff7f8d4554516bbf04387314f6c36f8b9e9c542df05efe9149516a0f2`.

```text
2026-09-16T19:59:38.0486271Z ##[error]Process completed with exit code 1.
```

### 35143815148 / job 104956522789 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35143815148/job/104956522789

Class: unclassified. Raw SHA256: `39a7c7c7cf3d14eb597cb3a095a535482213c863c7b23cece52da558d4649827`.

```text
2026-09-16T20:04:43.0633543Z ##[error]Velnor rejected this job before workflow execution.
```

### 35143815148 / job 104956524211 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35143815148/job/104956524211

Class: unclassified. Raw SHA256: `e46ef44793b6cd642621da0ab3dd89a64f643bb5795c8174bb66c36b7fc31b9c`.

```text
2026-09-16T20:05:43.2041393Z ##[error]Velnor rejected this job before workflow execution.
```

### 35143815148 / job 104957966309 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35143815148/job/104957966309

Class: unclassified. Raw SHA256: `14ef7bcf8c48833e361c758984b062b0e889c5fc4ec7d7e11ad921dfedbf7eb0`.

```text
2026-09-16T20:09:01.4055434Z ##[error]Process completed with exit code 1.
```

### 35143815148 / job 104958000608 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35143815148/job/104958000608

Class: unclassified. Raw SHA256: `e77ca25ff74596db253df4c19e27f2c5246088298328bdbce5c47bddf006a22d`.

```text
2026-09-16T20:09:08.8978596Z ##[error]Process completed with exit code 1.
```

### 35143815148 / job 104959435571 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/35143815148/job/104959435571

Class: unclassified. Raw SHA256: `f2ba81d27bba7a3ecea0176fdbcc6a892a288d46619175f872b82f2268167b86`.

```text
2026-09-16T20:13:20.2821395Z ##[error]Velnor rejected this job before workflow execution.
```

### 35143815148 / job 104959435866 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/35143815148/job/104959435866

Class: unclassified. Raw SHA256: `030ffb64552e16e13d15bdab995a4f8e1e6de08c5d1e266841a511351bf41c6a`.

```text
2026-09-16T20:13:32.4429806Z ##[error]Velnor rejected this job before workflow execution.
```

### 35143815148 / job 104959524605 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/35143815148/job/104959524605

Class: unclassified. Raw SHA256: `bd5e7a6048bbb8b609a9e08b20bc15327e56e02eec899635d33b56623a330eb9`.

```text
2026-09-16T20:13:44.1700262Z ##[error]Velnor rejected this job before workflow execution.
```

### 35143815148 / job 104959524734 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/35143815148/job/104959524734

Class: unclassified. Raw SHA256: `7d4c78bc0c8928cd9beecc34592e98c1bf9cb33944f6e9421bb2db88a4e5f44e`.

```text
2026-09-16T20:13:56.1704738Z ##[error]Velnor rejected this job before workflow execution.
```

### 35143815148 / job 104960498239 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/35143815148/job/104960498239

Class: unclassified. Raw SHA256: `b18a2814e5e805a66c44651f9070dbeb8b7e4eb54a48152d7a3fe097ad06b9f4`.

```text
2026-09-16T20:16:25.0987120Z ##[error]Process completed with exit code 1.
```

### 35143815148 / job 104960523755 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/35143815148/job/104960523755

Class: unclassified. Raw SHA256: `eb8bc31dc2a0a8915b7ea146bb4458341b85a053181cb3f6f34fb80a153e5580`.

```text
2026-09-16T20:17:05.4829140Z ##[error]Process completed with exit code 1.
```

### 35143815148 / job 104962424542 / attempt 4

https://github.com/tailrocks/velnor/actions/runs/35143815148/job/104962424542

Class: unclassified. Raw SHA256: `030ffb64552e16e13d15bdab995a4f8e1e6de08c5d1e266841a511351bf41c6a`.

```text
2026-09-16T20:13:32.4429806Z ##[error]Velnor rejected this job before workflow execution.
```

### 35143815148 / job 104962426771 / attempt 4

https://github.com/tailrocks/velnor/actions/runs/35143815148/job/104962426771

Class: unclassified. Raw SHA256: `bd5e7a6048bbb8b609a9e08b20bc15327e56e02eec899635d33b56623a330eb9`.

```text
2026-09-16T20:13:44.1700262Z ##[error]Velnor rejected this job before workflow execution.
```

### 35143815148 / job 104962427501 / attempt 4

https://github.com/tailrocks/velnor/actions/runs/35143815148/job/104962427501

Class: unclassified. Raw SHA256: `7d4c78bc0c8928cd9beecc34592e98c1bf9cb33944f6e9421bb2db88a4e5f44e`.

```text
2026-09-16T20:13:56.1704738Z ##[error]Velnor rejected this job before workflow execution.
```

### 35143815148 / job 104962549619 / attempt 4

https://github.com/tailrocks/velnor/actions/runs/35143815148/job/104962549619

Class: unclassified. Raw SHA256: `879e063f2e327351d5679751350271fad6b9fcd3e6bd3d384f849f35a8ad7cef`.

```text
2026-09-16T20:22:06.5298903Z ##[error]Process completed with exit code 1.
```

### 35143815148 / job 104962587345 / attempt 4

https://github.com/tailrocks/velnor/actions/runs/35143815148/job/104962587345

Class: unclassified. Raw SHA256: `ec0cba6cfa33b9370f0bd9932143c71ac043f5e8167d7e7d4726349e119d3aa0`.

```text
2026-09-16T20:22:12.2025187Z ##[error]Process completed with exit code 1.
```

### 35151021952 / job 104979066779 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35151021952/job/104979066779

Class: candidate-product. Raw SHA256: `de5f92769e0d9c95413a236f4288e5c0c40327cd819f84dcbb5704831584ff06`.

```text
2026-09-16T21:12:19.7210654Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-da8b155f2289b7b4-Linux-X64
2026-09-16T21:12:19.7218239Z ##[error]Process completed with exit code 1.
```

### 35151021952 / job 104981216310 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35151021952/job/104981216310

Class: candidate-product. Raw SHA256: `f308236335542df9025da1e817c64cec5038c06711ec0daad46b1b5426f18e72`.

```text
2026-09-16T21:19:02.5457544Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-da8b155f2289b7b4-Linux-X64
2026-09-16T21:19:02.5466524Z ##[error]Process completed with exit code 1.
```

### 35471682523 / job 105973647422 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35471682523/job/105973647422

Class: unclassified. Raw SHA256: `9be56c00de8268056ad345a3c89c683839f46b9ad875870414648abca9cde279`.

```text
2026-09-19T21:52:17.0672565Z ##[error]no runtime product for revision 5937b2698ac40aff4f9e5b6b34213a6b44371c78 (closure 2d07a97cf2a85257); the mainline runtime-product publisher builds it after merge
2026-09-19T21:52:17.0676654Z ##[error]Process completed with exit code 1.
```

### 35471682523 / job 105973670657 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35471682523/job/105973670657

Class: unclassified. Raw SHA256: `9add5a3a85f7dbbd9b0db9654a647b6264b936a402c7b7ea15b2920f08ab9af0`.

```text
2026-09-19T21:52:22.3743208Z ##[error]Process completed with exit code 1.
```

### 35471682523 / job 105973679652 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35471682523/job/105973679652

Class: unclassified. Raw SHA256: `735679fe0b32ce6762e8d21789e6080776f4d8aca8dcabbbe24ee8436eccd277`.

```text
2026-09-19T21:52:27.0091491Z ##[error]Process completed with exit code 1.
```

### 32818599515 / job 97711882774 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32818599515/job/97711882774

Class: rust-lint. Raw SHA256: `07cbec5d085a95e4dbf7736a4f04312513f18fe1c3fd69ad3faa9df29ae3a8e0`.

```text
2026-08-25T06:48:50.4749676Z error: No such remote: 'origin'
2026-08-25T06:48:52.0000000Z error: No such remote: 'origin'
2026-08-25T06:53:33.0000000Z error[E0432]: unresolved import `crate::service::INSTALLED_BINARY_PATH`
2026-08-25T06:53:33.0000000Z error: could not compile `velnor-runner` (lib) due to 1 previous error
2026-08-25T06:53:33.0000000Z error: could not compile `velnor-runner` (lib test) due to 1 previous error
2026-08-25T06:53:33.0000000Z error: command `/root/.rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu/bin/cargo test --no-run --message-format json-render-diagnostics --workspace --locked` exited with code 101
2026-08-25T06:53:42.0000000Z error[E0432]: unresolved import `crate::service::INSTALLED_BINARY_PATH`
2026-08-25T06:53:42.0000000Z error: could not compile `velnor-runner` (lib) due to 1 previous error
2026-08-25T06:53:42.0000000Z error: could not compile `velnor-runner` (lib test) due to 1 previous error
```

### 35492701269 / job 106030250282 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35492701269/job/106030250282

Class: generated-tree;candidate-product. Raw SHA256: `d0fe2e30de17a33d50ac0786c2ba297ff6232ec774533b0af2ad8503b57d6c04`.

```text
2026-09-20T06:00:34.2006808Z error: workflow policy failed: generated-tree
2026-09-20T06:00:34.2012438Z FAIL generated-tree         could not regenerate the tree with velnor-workflow at 325719f1e05d3d46322c9fd3eeb9ad545e175638
2026-09-20T06:00:34.2030915Z ##[error]Process completed with exit code 1.
```

### 35051490717 / job 104653338036 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35051490717/job/104653338036

Class: unclassified. Raw SHA256: `6a4d4133378da3eb0ccd9427f6c47baf8f5c2b8122b98050ca5de478217f82be`.

```text
2026-09-16T03:33:16.6015415Z ##[error]Error: mbx cache export exited with code 1
```

### 35051490717 / job 104656721135 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35051490717/job/104656721135

Class: unclassified. Raw SHA256: `5e3323c761da8cc81bb8fb1d29f825bfeda31f3a511e6a4bc533b042779c22e1`.

```text
2026-09-16T03:42:56.8633239Z ##[error]Process completed with exit code 1.
```

### 35051490717 / job 104656734690 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35051490717/job/104656734690

Class: unclassified. Raw SHA256: `3982bf1042eca4b6847455376e6a2eaa5c271600887beaf1544d7eb7b650130b`.

```text
2026-09-16T03:43:00.8072938Z ##[error]Process completed with exit code 1.
```

### 35051490717 / job 104676238365 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35051490717/job/104676238365

Class: unclassified. Raw SHA256: `c7332401a413df65c159dd9d4d2816c2b3023a1daf8d9f6a3a087cfe11b0cbf3`.

```text
2026-09-16T05:32:37.3590982Z ##[error]Error: mbx cache export exited with code 1
```

### 35051490717 / job 104677906832 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35051490717/job/104677906832

Class: unclassified. Raw SHA256: `760235c9461fb35074a32755eccf8555d80e6b23a5982509853203bbbe5388b3`.

```text
2026-09-16T05:32:42.7047302Z ##[error]Process completed with exit code 1.
```

### 35051490717 / job 104677923918 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35051490717/job/104677923918

Class: unclassified. Raw SHA256: `71b025507d1799852e2574d8b15c7319cf0c7e26a70001bb3b48d7aeafe7a810`.

```text
2026-09-16T05:32:48.7172288Z ##[error]Process completed with exit code 1.
```

### 32787419715 / job 97623864618 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32787419715/job/97623864618

Class: unclassified. Raw SHA256: `2efab632328926264aca7fe36d0e70db0fc6b4b0776cd9e6747e05a0da0a0b5b`.

```text
2026-08-24T23:09:20.6637738Z ##[error]Process completed with exit code 1.
```

### 32787419715 / job 97623887337 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32787419715/job/97623887337

Class: unclassified. Raw SHA256: `96259df0c456f098c7b860fb5ad0a037fba5293ff9cbbd87113fbfa9c3dd2948`.

```text
2026-08-24T23:09:28.1737213Z ##[error]Process completed with exit code 1.
```

### 32674243667 / job 97279670338 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32674243667/job/97279670338

Class: unclassified. Raw SHA256: `16e6e800d9607c46133d9ab8171c6fcd457abe43dd3f4887c1f3dc4880d9ad77`.

```text
2026-08-23T23:39:29.5303590Z ##[error]Process completed with exit code 1.
```

### 32674243667 / job 97281177935 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/32674243667/job/97281177935

Class: unclassified. Raw SHA256: `ccda5c48bf7916f31c0f26a54794ace77eae80d4fff7f3e2e509898aaa496bf0`.

```text
2026-08-23T23:51:55.6364159Z ##[error]Process completed with exit code 1.
```

### 35468737767 / job 105965710686 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35468737767/job/105965710686

Class: generated-tree;candidate-product. Raw SHA256: `bdb5d301f79ea649bbe9ebbf4d4bec6068cde789a868578808d62004cbbaad68`.

```text
2026-09-19T20:53:03.4386130Z error: generated files differ: .github/workflows/ci-unit-rust.yml, .github/workflows/preview.yml, .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-19T20:53:35.3991106Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-0c304c147d66fcdf-Linux-X64
2026-09-19T20:53:35.4000124Z ##[error]Process completed with exit code 1.
```

### 35482339365 / job 106002312575 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35482339365/job/106002312575

Class: generated-tree. Raw SHA256: `e80d29cc910dac3c4be9035c122b11d7c1740c4786651fa89c775b39d6c77601`.

```text
2026-09-20T01:50:36.6604167Z error: generated files match but generation inputs changed: generator input changed from 53 to 54 in .github/ci/.github-actions-generator-state; regenerate to record the current generation inputs
2026-09-20T01:50:36.6632464Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
2026-09-20T01:50:36.6699624Z ##[error]Process completed with exit code 1.
```

### 35482339365 / job 106002312607 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35482339365/job/106002312607

Class: test-failure. Raw SHA256: `c3a6e1502a2a0e6718e7a9a85b2e706cc643c190b9c1047eec2d82b3d6576e5f`.

```text
2026-09-20T01:53:48.1167791Z     thread 'protocol::tests::artifact_overwrite_deletes_only_this_jobs_rows' (26603) panicked at crates/velnor-runner/src/protocol.rs:8869:10:
2026-09-20T01:53:49.9621903Z error: test run failed
2026-09-20T01:53:50.6160513Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-20T01:53:50.6257889Z ##[error]Process completed with exit code 1.
```

### 35482339365 / job 106002972833 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35482339365/job/106002972833

Class: unclassified. Raw SHA256: `5939ad70a40322e3fb4e022986531a63715d00f738dc87401190bad37e278663`.

```text
2026-09-20T01:54:41.7607868Z ##[error]Process completed with exit code 1.
```

### 35482339365 / job 106002980880 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35482339365/job/106002980880

Class: unclassified. Raw SHA256: `624f5f5b684bf1c850260e010ffedc69675e87df554edcccd2de58fd1ed3ba19`.

```text
2026-09-20T01:54:46.2499596Z ##[error]Process completed with exit code 1.
```

### 32867632779 / job 97866776760 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32867632779/job/97866776760

Class: rust-lint. Raw SHA256: `878c95364aaa11814bdc764e3180a1f54bcfe2b0d0c3cdccd9a3b0248599e785`.

```text
2026-08-25T15:44:28.0428237Z error: No such remote: 'origin'
2026-08-25T15:44:45.0000000Z error: No such remote: 'origin'
2026-08-25T15:48:52.0000000Z error: unused import: `JoinSet`
2026-08-25T15:48:52.0000000Z error: could not compile `velnor-runner` (lib) due to 1 previous error
2026-08-25T15:48:52.0000000Z error: could not compile `velnor-runner` (lib test) due to 1 previous error
```

### 32777595302 / job 97592180471 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32777595302/job/97592180471

Class: rust-lint. Raw SHA256: `8f795cdc2b5767321e2043d41e7a14723bdf481441111af66b8e924e5cc72d53`.

```text
2026-08-24T21:06:01.4114021Z error: No such remote: 'origin'
2026-08-24T21:06:03.0000000Z error: No such remote: 'origin'
2026-08-24T21:09:07.0000000Z error: large size difference between variants
2026-08-24T21:09:07.0000000Z error: could not compile `velnorctl` (lib test) due to 1 previous error
2026-08-24T21:09:07.0000000Z error: could not compile `velnorctl` (lib) due to 1 previous error
```

### 34746797141 / job 103700601427 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34746797141/job/103700601427

Class: unclassified. Raw SHA256: `a4d71ddba7511f9bb64e0949225822d01812c026507e90125b229d5631cf62a7`.

```text
2026-09-13T08:48:50.8963339Z ##[error]Process completed with exit code 1.
```

### 34746797141 / job 103703423890 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/34746797141/job/103703423890

Class: unclassified. Raw SHA256: `6e1d36c8b3f7bca7c9407b1a4671bbdeaaa410a452758a1204765a46c81792d3`.

```text
2026-09-13T09:28:20.9956817Z ##[error]live preview 0.1.274~preview.47+e5da614 is newer than candidate 0.1.274~preview.46+fa6d2de; refusing to move the rolling preview backward — re-run the LATEST preview run instead
2026-09-13T09:28:20.9964934Z ##[error]Process completed with exit code 1.
```

### 35461921990 / job 105949219866 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35461921990/job/105949219866

Class: test-failure. Raw SHA256: `2405919ea1940b44ebd68a043445703b7b6ff2f99f035f5b34d1ff911edc611a`.

```text
2026-09-19T18:55:16.9809467Z     thread 'parameterized_callees_resolve_to_the_pre_parameterization_cache_keys' (2832) panicked at tests/cache_keys.rs:258:13:
2026-09-19T18:55:16.9812311Z       left: "velnor-docker-seed-v3-743cc362f16c-${{ runner.os }}-${{ runner.arch }}-github-hosted-linux-x64-trusted-only-docker-${{ hashFiles('Cargo.lock', 'Dockerfile', 'docker/build-mise.lock', 'docker/build-mise.toml', 'rust-toolchain.toml') }}-${{ hashFiles('Cargo.lock', 'deny.toml') }}"
2026-09-19T18:55:16.9815073Z      right: "velnor-docker-seed-v3-7e67216c9e23-${{ runner.os }}-${{ runner.arch }}-github-hosted-linux-x64-trusted-only-docker-${{ hashFiles('Cargo.lock', 'Dockerfile', 'docker/build-mise.lock', 'docker/build-mise.toml', 'rust-toolchain.toml') }}-${{ hashFiles('Cargo.lock', 'deny.toml') }}"
2026-09-19T18:55:16.9845466Z error: test run failed
2026-09-19T18:55:16.9881019Z error: CI command failed for unit rust-velnor-workflow-contract with exit status: 100
2026-09-19T18:55:16.9937715Z ##[error]Process completed with exit code 1.
```

### 35461921990 / job 105949219937 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35461921990/job/105949219937

Class: unclassified. Raw SHA256: `531576924bb2fa401c83f29fb565c0ba1ddecb3cac604ccd2570021995555e0f`.

```text
2026-09-19T18:57:59.0450747Z error: this function has too many lines (143/100)
2026-09-19T18:57:59.0462598Z error: could not compile `velnor-workflow` (lib) due to 1 previous error
2026-09-19T18:58:02.1747384Z error: CI command failed for unit rust-velnor-workflow with exit status: 101
2026-09-19T18:58:02.1801123Z ##[error]Process completed with exit code 1.
```

### 35484147225 / job 106007264082 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35484147225/job/106007264082

Class: generated-tree;candidate-product. Raw SHA256: `9f11a2e258f41f86756f87ef19bc76fe8dcd14b405f34e1a1cc12179c8f18b52`.

```text
2026-09-20T02:30:21.0714746Z error: generated files differ: .github/actionlint.yaml, .github/workflows/ci-runtime-products.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T02:34:49.2181524Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-29b26d8e9bfc3477-Linux-X64
2026-09-20T02:34:49.2190476Z ##[error]Process completed with exit code 1.
```

### 34715851903 / job 103613135286 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103613135286

Class: unclassified. Raw SHA256: `f3cdda8752bbc619c0f72c0c4ce835ee8da79ea5151b76ec0673e64ef44e209d`.

```text
2026-09-12T20:04:29.1983900Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103613135375 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103613135375

Class: unclassified. Raw SHA256: `c1a25d5202b1488dd24238900b953c6cc6a0f939c2ba3834c2c62149e31a3656`.

```text
2026-09-12T20:04:11.9832013Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103613135468 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103613135468

Class: unclassified. Raw SHA256: `791b7ec043df4c632197a2c38ae65db573c8e470443f38e602233505899b03b0`.

```text
2026-09-12T20:04:27.8013381Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103613135486 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103613135486

Class: unclassified. Raw SHA256: `ef14f488e998eafbcbf47baa4293781c5bd614d399ef28464a40fdaa2239d34d`.

```text
2026-09-12T20:04:06.7090227Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103613135592 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103613135592

Class: unclassified. Raw SHA256: `68f420a99d66c37ba449fa6143c560083734b0fb24676ec50be326fdb6becd2d`.

```text
2026-09-12T20:04:04.4279117Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103613135654 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103613135654

Class: unclassified. Raw SHA256: `f46b684d0dbe4da878f955b369444a609bd066d557abd8fdfa44436a2b021243`.

```text
2026-09-12T20:03:52.3556023Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103613135666 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103613135666

Class: unclassified. Raw SHA256: `6aeb41e1c726e0da19125be45f4a6af7be78d04c330622a858f010fe848f8625`.

```text
2026-09-12T20:04:18.6069387Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103613135693 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103613135693

Class: unclassified. Raw SHA256: `6fa828735fdd3a8421cb555deb07d90a372cd2ad5abf26ec6ca407721308fe38`.

```text
2026-09-12T20:03:54.9017071Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103613135711 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103613135711

Class: unclassified. Raw SHA256: `275ac1a6cb169ad031b8b3492a49f52daea6a5f8d0dad59b8c93ef6281ac73df`.

```text
2026-09-12T20:04:30.7558146Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103613135744 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103613135744

Class: unclassified. Raw SHA256: `cb95742842e007c6bc02ab8fdd0c6203f4c8730933ae3894f14c6bd8e3476df0`.

```text
2026-09-12T20:04:00.1717561Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103613135798 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103613135798

Class: unclassified. Raw SHA256: `5faa59eaf3f583260d9c4e3be6c57550dfc1b8a871287ee2be266a534fb69897`.

```text
2026-09-12T20:04:16.6388619Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103613135841 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103613135841

Class: unclassified. Raw SHA256: `73fb8591beb081f4cb033db71c72a78f0aa5c14ff92c37951702b4c3830c3ef5`.

```text
2026-09-12T20:04:23.2588065Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103614956123 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103614956123

Class: unclassified. Raw SHA256: `e96b0d178f0cd2a96137c360f32779b7d18ea29c2e9bf5f9dee575b0ecd753fe`.

```text
2026-09-12T20:17:06.8301195Z ##[error]Process completed with exit code 1.
```

### 34715851903 / job 103619389918 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103619389918

Class: unclassified. Raw SHA256: `b2d907ade68325f64298eeb5109300c09f56c5782ce7ac1fe8dfa72c124309f2`.

```text
2026-09-12T20:51:49.2961504Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103619390025 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103619390025

Class: unclassified. Raw SHA256: `a32855c2839e9f1c829b6c6c6844ae2b6deac660103a05afd337890be66b1498`.

```text
2026-09-12T20:51:49.2009726Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103619390026 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103619390026

Class: unclassified. Raw SHA256: `2a8b8ddd325a2967c96c4ef8b058707a7eda0620e9e127471943b337ac7cbdc4`.

```text
2026-09-12T20:52:25.9991929Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103619390071 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103619390071

Class: unclassified. Raw SHA256: `4cb0b6072a28d2c3d9a8053911668b95d32e4f59f6489edb7b01cf0625a8ea12`.

```text
2026-09-12T20:51:49.6865503Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103619390080 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103619390080

Class: unclassified. Raw SHA256: `30e6a6596220d0f8441cb98849f9ec79f3312c7df86e9fd7fe0be8b72318ecc7`.

```text
2026-09-12T20:52:44.5043327Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103619390125 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103619390125

Class: unclassified. Raw SHA256: `cf4a49ff865329737f1d075cbafcf9ddda5c90d9e2944aa163854d0a817f1acf`.

```text
2026-09-12T20:52:44.7508414Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103619390150 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103619390150

Class: unclassified. Raw SHA256: `075ffd4e9ba60a97ae704603786f67709b345189d1d17bad75a9389bb9e8d561`.

```text
2026-09-12T20:52:22.4521782Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103619390166 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103619390166

Class: unclassified. Raw SHA256: `d4ff9a6a411b644b0b490ae546f98615fd487c35951591eb79627f7173dba267`.

```text
2026-09-12T20:51:49.6633929Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103619390210 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103619390210

Class: unclassified. Raw SHA256: `538d44735c62889f8cff3ff4ac20e7ff282c96770001ff7289df29ae72fa2b56`.

```text
2026-09-12T20:52:25.1667659Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103619390221 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103619390221

Class: unclassified. Raw SHA256: `5db15ea04553398d75b49a107db212f775b1ce5ecf1934fa686f2b1bfde4ab9f`.

```text
2026-09-12T20:52:44.7884930Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103619390261 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103619390261

Class: unclassified. Raw SHA256: `0f60b4d4553036e896512d4675047e518224c9cad5eac77d6291b3fb73eb9712`.

```text
2026-09-12T20:52:45.8007642Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103619390374 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103619390374

Class: unclassified. Raw SHA256: `6cb19f9a18369cc4c906cf2137acae123624c7e48809b0efdc3daa8ecb39c7a5`.

```text
2026-09-12T20:52:22.7700037Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103619390381 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103619390381

Class: unclassified. Raw SHA256: `11598d73974115d8f2b3c80a5fa457afcbc4c3a36c6e60adcf6def02ee21b0e9`.

```text
2026-09-12T20:51:50.1644564Z ##[error]Velnor rejected this job before workflow execution.
```

### 34715851903 / job 103619529166 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/34715851903/job/103619529166

Class: unclassified. Raw SHA256: `0ff4c30170150626754ab0c686ab53e5c55427fa841bf765af40b41ce767da66`.

```text
2026-09-12T20:52:51.2568572Z ##[error]Process completed with exit code 1.
```

### 35478463351 / job 105991794951 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35478463351/job/105991794951

Class: unclassified. Raw SHA256: `6bcf4a61ce3a264ff8d24955dae2ee7b3733eadca9ad432e86aef968193726fd`.

```text
2026-09-20T00:25:23.5348224Z error: function `include_str_paths` is never used
2026-09-20T00:25:23.5352362Z error: could not compile `velnor-workflow` (lib) due to 1 previous error
2026-09-20T00:25:34.2578993Z error: CI command failed for unit rust-velnor-workflow with exit status: 101
2026-09-20T00:25:34.2641926Z ##[error]Process completed with exit code 1.
```

### 35478463351 / job 105992997700 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35478463351/job/105992997700

Class: unclassified. Raw SHA256: `0667b2b74a5d6e0ec794925cdf1659af3d41a6c1b330b0d6965740f00f80b268`.

```text
2026-09-20T00:29:50.5024169Z ##[error]Process completed with exit code 1.
```

### 35478463351 / job 105993008817 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35478463351/job/105993008817

Class: unclassified. Raw SHA256: `59df16c6014a4a212c90365f88f1450605be3e499ed8ca8fa304bca94444dc19`.

```text
2026-09-20T00:29:54.8332499Z ##[error]Process completed with exit code 1.
```

### 32780601214 / job 97601652753 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32780601214/job/97601652753

Class: unclassified. Raw SHA256: `8e7b5959dbb19307d11d1e67087f828b7f5cbf77c3ab14030a0b319d94f2f0dd`.

```text
2026-08-24T21:39:04.4784637Z error: No such remote: 'origin'
2026-08-24T21:41:49.0000000Z error: unrecognized subcommand 'release'
```

### 32861791940 / job 97847461437 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32861791940/job/97847461437

Class: rust-lint. Raw SHA256: `6fcdbca37fdea4a3317df24e4aa3b1289823b6ca3b07f844ffdacb1622885e6f`.

```text
2026-08-25T14:48:41.9800488Z error: No such remote: 'origin'
2026-08-25T14:48:52.0000000Z error: No such remote: 'origin'
2026-08-25T14:52:14.0000000Z error: unused import: `Path`
2026-08-25T14:52:14.0000000Z error: unused import: `AsyncReadExt`
2026-08-25T14:52:14.0000000Z error: unused import: `AsyncReadExt`
2026-08-25T14:52:14.0000000Z error: variable does not need to be mutable
2026-08-25T14:52:14.0000000Z error: variable does not need to be mutable
2026-08-25T14:52:14.0000000Z error: variable does not need to be mutable
2026-08-25T14:52:14.0000000Z error: variable does not need to be mutable
2026-08-25T14:52:14.0000000Z error: variable does not need to be mutable
2026-08-25T14:52:14.0000000Z error: unused variable: `key`
2026-08-25T14:52:14.0000000Z error: this expression creates a reference which is immediately dereferenced by the compiler
2026-08-25T14:52:14.0000000Z error: this expression creates a reference which is immediately dereferenced by the compiler
2026-08-25T14:52:14.0000000Z error: this expression creates a reference which is immediately dereferenced by the compiler
2026-08-25T14:52:14.0000000Z error: this expression creates a reference which is immediately dereferenced by the compiler
2026-08-25T14:52:14.0000000Z error: this expression creates a reference which is immediately dereferenced by the compiler
2026-08-25T14:52:14.0000000Z error: this expression creates a reference which is immediately dereferenced by the compiler
2026-08-25T14:52:14.0000000Z error: this expression creates a reference which is immediately dereferenced by the compiler
2026-08-25T14:52:14.0000000Z error: the following explicit lifetimes could be elided: 'a
2026-08-25T14:52:14.0000000Z error: could not compile `velnor-runner` (lib) due to 16 previous errors
2026-08-25T14:52:14.0000000Z error: could not compile `velnor-runner` (lib test) due to 15 previous errors
```

### 32821862026 / job 97721544235 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32821862026/job/97721544235

Class: rust-lint. Raw SHA256: `259594279edb91ffd6805273fb807d3d5e7e34538d5504e9291c81f10a7da6a9`.

```text
2026-08-25T07:29:54.0316210Z error: No such remote: 'origin'
2026-08-25T07:29:56.0000000Z error: No such remote: 'origin'
2026-08-25T07:33:00.0000000Z error: useless conversion to the same type: `args::CapabilitiesArgs`
2026-08-25T07:33:00.0000000Z error: could not compile `velnor-runner` (lib) due to 1 previous error
2026-08-25T07:33:00.0000000Z error: could not compile `velnor-runner` (lib test) due to 1 previous error
```

### 33101458123 / job 98623512240 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33101458123/job/98623512240

Class: unclassified. Raw SHA256: `37aec0e7cd3e1d15ba87bfcf02d2f93f1b6b4c361dd3953f5cabd06d9fac8580`.

```text
2026-08-27T18:14:28.4007231Z ##[error]Process completed with exit code 1.
```

### 33101458123 / job 98623547998 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33101458123/job/98623547998

Class: unclassified. Raw SHA256: `0186e4299c8ea78a36afad5b6c478a4e1ddb0949bbc665fad59d8fa632daa1ea`.

```text
2026-08-27T18:14:34.3629217Z ##[error]Process completed with exit code 1.
```

### 35484349032 / job 106007857121 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35484349032/job/106007857121

Class: candidate-product. Raw SHA256: `d3b6508b9e088a1ec39209f68f6a2244a9e75bd537f5bf6b6438a6ac76ed6660`.

```text
2026-09-20T02:50:09.4239821Z ##[error]no candidate product velnor-workflow-candidate-b510e2700de75668-Linux-X64 was published within 15 minutes
2026-09-20T02:50:09.4248484Z ##[error]Process completed with exit code 1.
```

### 35473052923 / job 105977467962 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35473052923/job/105977467962

Class: candidate-product. Raw SHA256: `0e3aa053eb2bb39ebc23c12388cf44129240edd74a0003b269f027531cb594bf`.

```text
2026-09-19T22:26:28.7187446Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-cdab06f87a6610ee-Linux-X64
2026-09-19T22:26:28.7195910Z ##[error]Process completed with exit code 1.
```

### 35307866687 / job 105483668527 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35307866687/job/105483668527

Class: generated-tree;candidate-product. Raw SHA256: `004deadf0b9d3d7a031d03ddeaf6ef0baebecc515a4b5a4cb12841ab4c789f19`.

```text
2026-09-18T04:40:46.9620285Z error: generated files differ: .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-18T04:50:07.6963883Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-385a1c86ca129ce4-Linux-X64
2026-09-18T04:50:07.6974150Z ##[error]Process completed with exit code 1.
```

### 35307866687 / job 105486000349 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/35307866687/job/105486000349

Class: generated-tree;candidate-product. Raw SHA256: `43d145193de9e73126108f84c9db1270650aa07e9713dd2b90a031d4b6ad7729`.

```text
2026-09-18T04:53:30.9746959Z error: generated files differ: .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-18T04:53:31.7888360Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-385a1c86ca129ce4-Linux-X64
2026-09-18T04:53:31.7897368Z ##[error]Process completed with exit code 1.
```

### 35497921432 / job 106044300154 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35497921432/job/106044300154

Class: generated-tree. Raw SHA256: `f104c1f2cde43efe1841ab07ea62b15dcbeca109e69e1dbd56b381be90cabcb9`.

```text
2026-09-20T07:50:05.4675380Z error: workflow policy failed: generated-tree
2026-09-20T07:50:05.4690454Z FAIL generated-tree         the tree differs from the render of velnor-workflow at 0dc79895ff1c5e88be7c3822c437e1c5b5282e12
2026-09-20T07:50:05.4712167Z ##[error]Process completed with exit code 1.
```

### 33376355245 / job 99438643798 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33376355245/job/99438643798

Class: test-failure. Raw SHA256: `fc53c9e400b38d70d81d031ba9bc90d70c5cf2bce4d8f7097f845b1fabfced75`.

```text
2026-08-31T09:13:15.6471909Z     thread 'tests::concurrent_opens_serialize_legacy_metadata_migration' (6562) panicked at crates/velnor-cache-service/src/lib.rs:1207:26:
2026-08-31T09:14:02.5116275Z error: test run failed
2026-08-31T09:14:02.5197218Z ##[error]Process completed with exit code 100.
```

### 33376355245 / job 99439528120 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33376355245/job/99439528120

Class: unclassified. Raw SHA256: `7779cf96d59dda5d3fba63bd79025dc001b82c67bbee2027bf67026be318414e`.

```text
2026-08-31T09:14:08.4906269Z ##[error]Process completed with exit code 1.
```

### 33376355245 / job 99439552817 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33376355245/job/99439552817

Class: unclassified. Raw SHA256: `ce2f79aeccc0f055174d9e1ec59bbf4c2c072adff2ab7c705b8d5cd22352d280`.

```text
2026-08-31T09:14:13.9622267Z ##[error]Process completed with exit code 1.
```

### 33376355245 / job 99439946809 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33376355245/job/99439946809

Class: unclassified. Raw SHA256: `c3fbf147cef02689a3cbcbb82e6ab1164f3c6429f85910297ff249723fdf26af`.

```text
2026-08-31T09:15:48.0844972Z ##[error]Process completed with exit code 1.
```

### 33376355245 / job 99439977753 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33376355245/job/99439977753

Class: unclassified. Raw SHA256: `1beae6c82c72f80472d19e945c1f5a346bd1de5077368bbeab24d35311b1e153`.

```text
2026-08-31T09:15:56.4263838Z ##[error]Process completed with exit code 1.
```

### 34927400328 / job 104250427119 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34927400328/job/104250427119

Class: unclassified. Raw SHA256: `73ec4766848e25059e88e5f6cb9102a69ee4f8d9f9d11bcecf18a7131315b398`.

```text
2026-09-15T04:15:33.3046250Z ##[error]Velnor rejected this job before workflow execution.
```

### 35465276419 / job 105956357885 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35465276419/job/105956357885

Class: generated-tree;candidate-product. Raw SHA256: `5c7893a31b6d861a9b0fab41e5b44cdcf81d5f6a8be0bc72ad52bc266d1f1d81`.

```text
2026-09-19T19:44:53.1336477Z error: generated files differ: .github/workflows/ci-unit-rust.yml, .github/workflows/preview.yml, .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-19T19:54:06.3884871Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-0befa3d926820155-Linux-X64
2026-09-19T19:54:06.3894792Z ##[error]Process completed with exit code 1.
```

### 35490605836 / job 106024779967 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35490605836/job/106024779967

Class: candidate-product. Raw SHA256: `3fb927e76f1ad9e87930d3a5d5feac289e4ac10631b360d0132441e32a21e1d4`.

```text
2026-09-20T05:12:11.3439777Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-fafa74973fd17c52-Linux-X64
2026-09-20T05:12:11.3447642Z ##[error]Process completed with exit code 1.
```

### 35478460681 / job 105991795743 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35478460681/job/105991795743

Class: generated-tree. Raw SHA256: `a65ff3a45be14c91a5949ee5e7936536a3632e1a3d2e6c49b9c697fd34149d02`.

```text
2026-09-20T00:21:59.7216426Z error: generated files differ: .github/ci/project.toml, .github/workflows/ci-main.yml, .github/workflows/ci-pr.yml, .github/workflows/ci-unit-rust.yml, .github/workflows/preview.yml, .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T00:21:59.7240680Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
2026-09-20T00:21:59.7309074Z ##[error]Process completed with exit code 1.
```

### 35478460681 / job 105991795755 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35478460681/job/105991795755

Class: test-failure. Raw SHA256: `a56b60bd82cadb76db9a523dec2fe05dff48cf20f9bf010bc2693212aba10e70`.

```text
2026-09-20T00:25:29.3839495Z     thread 'manifest::tests::compiled_manifest_is_version_fourteen_and_structurally_immutable' (26703) panicked at crates/velnor-runner/src/manifest.rs:1960:9:
2026-09-20T00:25:29.3841624Z       left: 15
2026-09-20T00:25:29.3842421Z      right: 14
2026-09-20T00:25:29.4277500Z error: test run failed
2026-09-20T00:25:29.7359548Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-20T00:25:29.7434886Z ##[error]Process completed with exit code 1.
```

### 35478460681 / job 105992509246 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35478460681/job/105992509246

Class: unclassified. Raw SHA256: `dcc0301d4b46477a66be4a3b5b7cdcf8c66bd2b890672ff33bf0de7c79c679f7`.

```text
2026-09-20T00:25:37.4154741Z ##[error]Process completed with exit code 1.
```

### 35478460681 / job 105992521160 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35478460681/job/105992521160

Class: unclassified. Raw SHA256: `0c93feba5b18c6746ae06f96fcadf5426a3972626dd5c0dc58517d7813471226`.

```text
2026-09-20T00:25:42.8478396Z ##[error]Process completed with exit code 1.
```

### 35491806616 / job 106027921410 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35491806616/job/106027921410

Class: candidate-product. Raw SHA256: `46c5dceacce64ecb09e88d0f243a5907ff9313f8a9dd4cd796920e98d8aa5c93`.

```text
2026-09-20T05:29:41.5503446Z error: invalid generation config /home/runner/work/velnor/velnor/policy-checkout/.github-gen/velnor-workflow.toml: TOML parse error at line 75, column 1
2026-09-20T05:44:44.4096304Z ##[error]no candidate product velnor-workflow-candidate-2a6c634fb420ff03-Linux-X64 was published within 15 minutes
2026-09-20T05:44:44.4106226Z ##[error]Process completed with exit code 1.
```

### 35502093975 / job 106055555749 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35502093975/job/106055555749

Class: generated-tree;candidate-product. Raw SHA256: `9fe7ab5b63fe0b2b2203bd694095202d4ae3b6f363ab02b14b9a29276d3fb4c3`.

```text
2026-09-20T09:22:02.6445871Z error: generated files differ: .github/actionlint.yaml, .github/ci/project.toml, .github/workflows/ci-main.yml, .github/workflows/ci-pr.yml, .github/workflows/ci-runtime-products.yml, .github/workflows/ci-unit-bun.yml, .github/workflows/ci-unit-docker.yml, .github/workflows/ci-unit-docs.yml, .github/workflows/ci-unit-opentofu.yml, .github/workflows/ci-unit-rust.yml, .github/workflows/preview.yml, .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T09:37:11.7417929Z ##[error]no candidate product velnor-workflow-candidate-f939cd8f39e79f7d-Linux-X64 was published within 15 minutes
2026-09-20T09:37:11.7427703Z ##[error]Process completed with exit code 1.
```

### 35502093975 / job 106057489421 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35502093975/job/106057489421

Class: unclassified. Raw SHA256: `efe59fcb51c66a4b4c66c981da3257201dc76f7ded4fa851fc68fe1bb4715c68`.

```text
2026-09-20T09:37:19.2794426Z ##[error]Process completed with exit code 1.
```

### 35502093975 / job 106057498045 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35502093975/job/106057498045

Class: unclassified. Raw SHA256: `e6d5f027b8a710323a651c93411466fa7ead9244d86a653265d43b99fdb50053`.

```text
2026-09-20T09:37:23.7775655Z ##[error]Process completed with exit code 1.
```

### 35463725240 / job 105953856453 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35463725240/job/105953856453

Class: unclassified. Raw SHA256: `17cd74e30402b5a586853e1f5fec0a63a91efcdba35e9c8983e35a14b80773c2`.

```text
2026-09-19T19:29:49.8438966Z error: invalid generated ownership state: /home/runner/work/velnor/velnor/.github/ci/.github-actions-generator-state expected the generator input
2026-09-19T19:29:49.8459095Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
2026-09-19T19:29:49.8515482Z ##[error]Process completed with exit code 1.
```

### 35463725240 / job 105953856614 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35463725240/job/105953856614

Class: test-failure. Raw SHA256: `6470bb9a3add153ce09360dd364fde3f839d03b59763a26b9af98a6ff2995f5e`.

```text
2026-09-19T19:27:26.8511497Z     thread 'parameterized_callees_resolve_to_the_pre_parameterization_cache_keys' (2867) panicked at tests/cache_keys.rs:258:13:
2026-09-19T19:27:26.8514044Z       left: "velnor-docker-seed-v3-743cc362f16c-${{ runner.os }}-${{ runner.arch }}-github-hosted-linux-x64-trusted-only-docker-${{ hashFiles('Cargo.lock', 'Dockerfile', 'docker/build-mise.lock', 'docker/build-mise.toml', 'rust-toolchain.toml') }}-${{ hashFiles('Cargo.lock', 'deny.toml') }}"
2026-09-19T19:27:26.8515989Z      right: "velnor-docker-seed-v3-7e67216c9e23-${{ runner.os }}-${{ runner.arch }}-github-hosted-linux-x64-trusted-only-docker-${{ hashFiles('Cargo.lock', 'Dockerfile', 'docker/build-mise.lock', 'docker/build-mise.toml', 'rust-toolchain.toml') }}-${{ hashFiles('Cargo.lock', 'deny.toml') }}"
2026-09-19T19:27:26.8565089Z error: test run failed
2026-09-19T19:27:26.8603602Z error: CI command failed for unit rust-velnor-workflow-contract with exit status: 100
2026-09-19T19:27:26.8665604Z ##[error]Process completed with exit code 1.
```

### 35463725240 / job 105955162004 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35463725240/job/105955162004

Class: unclassified. Raw SHA256: `d9854dc37c7a5dcf8a1322d348a60cf459a10aaa8230425db9e3bd922b1bf2c8`.

```text
2026-09-19T19:35:57.3874373Z ##[error]Process completed with exit code 1.
```

### 35463725240 / job 105955175263 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35463725240/job/105955175263

Class: unclassified. Raw SHA256: `213f72e40c752582ec15337283e515e910dc29c3b0c583c884e0e7777a3fee18`.

```text
2026-09-19T19:36:02.5693172Z ##[error]Process completed with exit code 1.
```

### 33283645083 / job 99184000327 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33283645083/job/99184000327

Class: unclassified. Raw SHA256: `5af19e8e14bbe531b7836a6c71c1e6159f5d7918b733ca893c2190b81dff3095`.

```text
2026-08-30T00:44:53.3438965Z ##[error]Process completed with exit code 1.
```

### 33283645083 / job 99184013391 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33283645083/job/99184013391

Class: unclassified. Raw SHA256: `030491e7b84dbdcbd77114132455c88ea32c7851c7cbeaa1eba950005be9a92f`.

```text
2026-08-30T00:44:59.3194736Z ##[error]Process completed with exit code 1.
```

### 33283645083 / job 99184544956 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33283645083/job/99184544956

Class: unclassified. Raw SHA256: `d46a5c427c8f28b76ddd5ee91a8710a7f5f46349f29de2bd217c99c50560b07d`.

```text
2026-08-30T00:50:08.8132240Z ##[error]Process completed with exit code 1.
```

### 33283645083 / job 99184559700 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33283645083/job/99184559700

Class: unclassified. Raw SHA256: `b6d6b89aaee41fa5fce27792d647108dff226e6e2c1cf2570c94d6ea9c5551f0`.

```text
2026-08-30T00:50:15.0744752Z ##[error]Process completed with exit code 1.
```

### 35498407618 / job 106045609022 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35498407618/job/106045609022

Class: candidate-product. Raw SHA256: `c4262dacd9ac17761bbc9fee10c620ef61e84a05c81546777a659819892e221a`.

```text
2026-09-20T08:01:19.8722019Z error: invalid generation config /home/runner/work/velnor/velnor/policy-checkout/.github-gen/velnor-workflow.toml: TOML parse error at line 75, column 1
2026-09-20T08:16:22.3950886Z ##[error]no candidate product velnor-workflow-candidate-7bd39c4639e18738-Linux-X64 was published within 15 minutes
2026-09-20T08:16:22.3959120Z ##[error]Process completed with exit code 1.
```

### 35477443172 / job 105989017895 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35477443172/job/105989017895

Class: candidate-product. Raw SHA256: `6b3867b830affe321bcaab1b4c84aecb6c70f09116af4d8651736a5f1db0d78c`.

```text
2026-09-19T23:56:40.7731182Z error: invalid generation config /home/runner/work/velnor/velnor/policy-checkout/.github-gen/velnor-workflow.toml: TOML parse error at line 75, column 1
2026-09-20T00:05:55.1530304Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-dcc98c15e651208f-Linux-X64
2026-09-20T00:05:55.1537912Z ##[error]Process completed with exit code 1.
```

### 35479860400 / job 105995594899 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35479860400/job/105995594899

Class: generated-tree. Raw SHA256: `bf6b37f12eae7a391f23c6319d79957df2ee2c6439248a935402d115c5f289f1`.

```text
2026-09-20T00:51:35.8726356Z error: workflow policy failed: generated-tree
2026-09-20T00:51:35.8735185Z FAIL generated-tree         the tree differs from the render of velnor-workflow at 0dc79895ff1c5e88be7c3822c437e1c5b5282e12
2026-09-20T00:51:35.8752397Z ##[error]Process completed with exit code 1.
```

### 31721855783 / job 94520585509 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/31721855783/job/94520585509

Class: unclassified. Raw SHA256: `0d1ad75e8de11453b95b970a1f5d2569e3323d61ce672e49bc80b983ceef5d2d`.

```text
2026-08-13T16:40:39.3969218Z error: No such remote: 'origin'
```

### 31721855783 / job 94521567572 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/31721855783/job/94521567572

Class: unclassified. Raw SHA256: `d787ce179d26d7d2c042922f4f9db5804cfe44b0933dd5fa6fe14121af31cc36`.

```text
2026-08-13T16:44:18.4645970Z ##[error]Process completed with exit code 1.
```

### 31721855783 / job 94521626601 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/31721855783/job/94521626601

Class: unclassified. Raw SHA256: `69bf8bb07a7ce1819b1e16a6ba03e8712cfb6f7c7ddff085f412dd22aceb4d13`.

```text
2026-08-13T16:44:23.9073590Z ##[error]Process completed with exit code 1.
```

### 34771294535 / job 103763940092 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/34771294535/job/103763940092

Class: unclassified. Raw SHA256: `7e14e6844887110a429ef78a62e914bfe3aed4df53c66a0b5b85291ce7651336`.

```text
2026-09-13T17:40:38.5399598Z ##[error]Process completed with exit code 1.
```

### 35501999104 / job 106055289392 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35501999104/job/106055289392

Class: candidate-product. Raw SHA256: `86b06bf57749db9992a0bf568af1af1d49c70a36270da032f64d6253fff35d44`.

```text
2026-09-20T09:34:57.4113483Z ##[error]no candidate product velnor-workflow-candidate-a67d55386f0034c7-Linux-X64 was published within 15 minutes
2026-09-20T09:34:57.4122537Z ##[error]Process completed with exit code 1.
```

### 35484968732 / job 106009550596 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35484968732/job/106009550596

Class: generated-tree. Raw SHA256: `559317de63892de5ecdd077fcd539efd401fa5171bd470ab7fa20733f84f800f`.

```text
2026-09-20T02:49:15.3612007Z error: workflow policy failed: generated-tree
2026-09-20T02:49:15.3619067Z FAIL generated-tree         the tree differs from the render of velnor-workflow at 0dc79895ff1c5e88be7c3822c437e1c5b5282e12
2026-09-20T02:49:15.3647005Z ##[error]Process completed with exit code 1.
```

### 33378299273 / job 99446006826 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33378299273/job/99446006826

Class: unclassified. Raw SHA256: `74a7c1e40f11168c7d643e888b19cf36aaecdcfbb6eb1452477fd0f43ea8d515`.

```text
2026-08-31T09:39:20.3996757Z ##[error]Process completed with exit code 1.
```

### 33378299273 / job 99446028406 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33378299273/job/99446028406

Class: unclassified. Raw SHA256: `ec7d9afad67a2a29cd9acd56fdadf65c02f14f36028352ba4a52c38fcc0772aa`.

```text
2026-08-31T09:39:24.9109252Z ##[error]Process completed with exit code 1.
```

### 33378299273 / job 99448978346 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33378299273/job/99448978346

Class: unclassified. Raw SHA256: `278062c44c88d3a6dd755df24f3745c91beb90d84f13f4e65e3d82b3041bf098`.

```text
2026-08-31T09:51:09.6697821Z ##[error]Process completed with exit code 1.
```

### 33378299273 / job 99449003678 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33378299273/job/99449003678

Class: unclassified. Raw SHA256: `cc7402d51f32c44a45de3834b2a88f740a323fb5f9d00a95bff9cae186c84975`.

```text
2026-08-31T09:51:15.8767028Z ##[error]Process completed with exit code 1.
```

### 33378299273 / job 99450149618 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/33378299273/job/99450149618

Class: unclassified. Raw SHA256: `f2220100aad6d793df975ac009a03e97d8d8b6d874b8aa81d3c5f11bae886360`.

```text
2026-08-31T09:55:58.1132770Z ##[error]Process completed with exit code 1.
```

### 33378299273 / job 99450175938 / attempt 3

https://github.com/tailrocks/velnor/actions/runs/33378299273/job/99450175938

Class: unclassified. Raw SHA256: `d4323ae05007391089c84f5a616fd06636eb4ddafe313b4ba060b3473c8a5e3c`.

```text
2026-08-31T09:56:04.6266290Z ##[error]Process completed with exit code 1.
```

### 33378299273 / job 99451814302 / attempt 4

https://github.com/tailrocks/velnor/actions/runs/33378299273/job/99451814302

Class: unclassified. Raw SHA256: `873de9155a0310ee26d749f81e2cad39b10ce78136b263bac6e090c40e9876eb`.

```text
2026-08-31T10:02:53.6403997Z ##[error]Process completed with exit code 1.
```

### 33354876110 / job 99376642187 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33354876110/job/99376642187

Class: unclassified. Raw SHA256: `e86bc7a9b57b7c4407e9145dcf5d18f55850ef1937d2fc4691c7a8ca20d8f8d0`.

```text
2026-08-31T03:57:17.1036916Z ##[error]Process completed with exit code 1.
```

### 33354876110 / job 99376656927 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33354876110/job/99376656927

Class: unclassified. Raw SHA256: `e85a5f2a588fcc0d3efb46a540307f2ebbe44fa60f1e834c8f79f1621d2d1eda`.

```text
2026-08-31T03:57:23.7380266Z ##[error]Process completed with exit code 1.
```

### 33354876110 / job 99377342745 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33354876110/job/99377342745

Class: unclassified. Raw SHA256: `ae7fc34b6eb0ed5351c037a14040f03fa4eb09bb4d3e9deed19f20251e850601`.

```text
2026-08-31T04:02:07.4926817Z ##[error]Process completed with exit code 1.
```

### 33354876110 / job 99377361248 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/33354876110/job/99377361248

Class: unclassified. Raw SHA256: `5c1f173694f4d130820a56828215abd6a43541491500c31767d728d96d420d1e`.

```text
2026-08-31T04:02:14.5766047Z ##[error]Process completed with exit code 1.
```

### 33056323591 / job 98470574697 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/33056323591/job/98470574697

Class: unclassified. Raw SHA256: `ef48244d30828d2f0eea004e0cf546daaaae3cc5b87c924416c99efcd194cdee`.

```text
2026-08-27T09:26:16.0189198Z ##[error]Process completed with exit code 1.
```

### 35499213813 / job 106047828834 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35499213813/job/106047828834

Class: generated-tree. Raw SHA256: `9da5ea38cc67f1fd283d6a5e48aa998fa5419a2fe7be53b623919533958517f6`.

```text
2026-09-20T08:19:02.2389263Z error: workflow policy failed: generated-tree
2026-09-20T08:19:02.2396655Z FAIL generated-tree         the tree differs from the render of velnor-workflow at 0dc79895ff1c5e88be7c3822c437e1c5b5282e12
2026-09-20T08:19:02.2419700Z ##[error]Process completed with exit code 1.
```

### 35491246891 / job 106026442984 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35491246891/job/106026442984

Class: generated-tree;candidate-product. Raw SHA256: `5892e3df0b5c310cb614aea9c89ed123284a27e943339cd329663a3283678c87`.

```text
2026-09-20T05:23:33.6016167Z error: workflow policy failed: generated-tree
2026-09-20T05:23:33.6022447Z FAIL generated-tree         could not regenerate the tree with velnor-workflow at 325719f1e05d3d46322c9fd3eeb9ad545e175638
2026-09-20T05:23:33.6042666Z ##[error]Process completed with exit code 1.
```

### 35480462376 / job 105997215244 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35480462376/job/105997215244

Class: generated-tree;candidate-product. Raw SHA256: `dd3cd6e82ed818b345dbdbd7d1e282bf7c57600f4027e61ea90f667526afd62e`.

```text
2026-09-20T01:05:19.0752196Z error: generated files differ: .github/actionlint.yaml, .github/workflows/ci-runtime-products.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T01:13:30.5713127Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-f9a281911e33f8f1-Linux-X64
2026-09-20T01:13:30.5719445Z ##[error]Process completed with exit code 1.
```

### 35463512802 / job 105951484532 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35463512802/job/105951484532

Class: generated-tree;candidate-product. Raw SHA256: `58fc4260f5e8e037d2a5a2a0fba32072be61dffbaff0670f704a82dfd75bcd8c`.

```text
2026-09-19T19:10:46.1703577Z error: generated files differ: .github/workflows/ci-unit-rust.yml, .github/workflows/preview.yml, .github/workflows/release.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-19T19:25:50.4480949Z ##[error]no candidate product velnor-workflow-candidate-5887398768e1af80-Linux-X64 was published within 15 minutes
2026-09-19T19:25:50.4487201Z ##[error]Process completed with exit code 1.
```

### 35463512802 / job 105953678238 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35463512802/job/105953678238

Class: unclassified. Raw SHA256: `c65c7ac2b215ba5879a1af39b0aa00dadd010c92708f69d8cbd15bb9d9e8f96a`.

```text
2026-09-19T19:25:56.8700501Z ##[error]Process completed with exit code 1.
```

### 35463512802 / job 105953691642 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35463512802/job/105953691642

Class: unclassified. Raw SHA256: `b6d15b0f5a4a801944cdcd0f703787baa06602471ec42ba419834e4fc58b1889`.

```text
2026-09-19T19:26:01.6833458Z ##[error]Process completed with exit code 1.
```

### 32822578080 / job 97723705868 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32822578080/job/97723705868

Class: lockfile. Raw SHA256: `8f2483120576f69c0749544162de29ea50a27307581b9663064fdc272f303713`.

```text
2026-08-25T07:38:43.7874404Z error: No such remote: 'origin'
2026-08-25T07:38:46.0000000Z error: No such remote: 'origin'
2026-08-25T07:38:59.0000000Z error: cannot update the lock file /__w/Cargo.lock because --locked was passed to prevent this
2026-08-25T07:38:59.0000000Z error: command `/root/.rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu/bin/cargo metadata '--format-version=1' --all-features --filter-platform x86_64-unknown-linux-gnu --locked` failed with exit status: 101
2026-08-25T07:38:59.0000000Z error: cannot update the lock file /__w/Cargo.lock because --locked was passed to prevent this
```

### 35472352909 / job 105975533821 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35472352909/job/105975533821

Class: generated-tree. Raw SHA256: `903742492f75b0ee3f688da4f0f78c92fb49dd09adb84ba7f7d911a47076e316`.

```text
2026-09-19T22:08:44.0798777Z error: generated files match but generation inputs changed: scan input changed from 8d96315cc857133b to 6b45276e6221b217 in .github/ci/.github-actions-generator-state; regenerate to record the current generation inputs
2026-09-19T22:08:44.0824117Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
2026-09-19T22:08:44.0892035Z ##[error]Process completed with exit code 1.
```

### 35472352909 / job 105976810666 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35472352909/job/105976810666

Class: unclassified. Raw SHA256: `8b37238d0e7cd7d8187992710bdf6990ac9c6b87f1458a39956f278794281b30`.

```text
2026-09-19T22:15:59.2556630Z ##[error]Process completed with exit code 1.
```

### 35472352909 / job 105976823048 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35472352909/job/105976823048

Class: unclassified. Raw SHA256: `af0c8656f5dcee80f42999858e0c3b840dd36dce8ba6e4a58f839250a4329c7c`.

```text
2026-09-19T22:16:03.9407396Z ##[error]Process completed with exit code 1.
```

### 35506628393 / job 106067477910 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35506628393/job/106067477910

Class: unclassified. Raw SHA256: `e5c2c4cd84c0c1e18c06a22689a851823d36026d86a8cefd2d5538e702b3cbfd`.

```text
2026-09-20T11:03:15.8571886Z ##[error]The runner has received a shutdown signal. This can happen when the runner service is stopped, or a manually started runner is canceled.
2026-09-20T11:03:15.8573569Z ##[error]Process completed with exit code 143.
```

### 35506628393 / job 106068585837 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35506628393/job/106068585837

Class: unclassified. Raw SHA256: `7bf349da883a335fcf2520f4ca029f8851d1d3f200cec3b90eb0d56f565f90ff`.

```text
2026-09-20T11:10:06.4258767Z ##[error]Process completed with exit code 1.
```

### 35506628393 / job 106068599347 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35506628393/job/106068599347

Class: unclassified. Raw SHA256: `538c3fcbd63a953a74bd5edd4598ac04d19136aec6ea56fa2e64c3d2c0446435`.

```text
2026-09-20T11:10:12.1994913Z ##[error]Process completed with exit code 1.
```

### 35487076383 / job 106015320665 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35487076383/job/106015320665

Class: candidate-product. Raw SHA256: `cf44ce8e72d09de7fb5abaa8b1c6dc44e54e49aec5e5e2616f877bc4ee548997`.

```text
2026-09-20T03:39:14.7197934Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-80b494b6f8ee0dbf-Linux-X64
2026-09-20T03:39:14.7205992Z ##[error]Process completed with exit code 1.
```

### 35490579796 / job 106024714418 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35490579796/job/106024714418

Class: generated-tree;candidate-product. Raw SHA256: `fdc9791dc3f79ff03e9ac8539201c4bc3adb93f397d8a631cd9dee2bb46d6f1b`.

```text
2026-09-20T05:01:11.8939913Z error: generated files differ: .github/actionlint.yaml, .github/workflows/ci-main.yml, .github/workflows/ci-pr.yml, .github/workflows/ci-runtime-products.yml, .github/workflows/ci-unit-bun.yml, .github/workflows/ci-unit-docker.yml, .github/workflows/ci-unit-docs.yml, .github/workflows/ci-unit-opentofu.yml, .github/workflows/ci-unit-rust.yml, .github/ci/.github-actions-generator-state; rerun generate
2026-09-20T05:16:13.3367527Z ##[error]no candidate product velnor-workflow-candidate-fb8e530bad415def-Linux-X64 was published within 15 minutes
2026-09-20T05:16:13.3375811Z ##[error]Process completed with exit code 1.
```

### 29939927201 / job 88993117410 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/29939927201/job/88993117410

Class: unclassified. Raw SHA256: `98bbdab53286f4557fafc027e80e67d45c11761dde4f60dceed37889cf483ead`.

```text
2026-07-22T17:01:44.0000000Z error: No such remote: 'origin'
```

### 32780784409 / job 97602210258 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32780784409/job/97602210258

Class: test-failure. Raw SHA256: `d5098dd66658db1f45e84932f1278902cf89d118ebc4f188ffe4679f587ba459`.

```text
2026-08-24T21:41:07.5355029Z error: No such remote: 'origin'
2026-08-24T21:41:09.0000000Z error: No such remote: 'origin'
2026-08-24T21:44:24.0000000Z [test]     thread 'executor::tests::target_docker_action_inputs_match_current_workflows' (30823) panicked at crates/velnor-runner/src/executor.rs:17842:13:
2026-08-24T21:44:24.0000000Z [test]     thread 'executor::tests::target_docker_javascript_actions_receive_socket_and_cli_mounts' (30825) panicked at crates/velnor-runner/src/executor.rs:17482:13:
2026-08-24T21:44:28.0000000Z     thread 'executor::tests::target_docker_action_inputs_match_current_workflows' (32158) panicked at crates/velnor-runner/src/executor.rs:17842:13:
2026-08-24T21:44:28.0000000Z     thread 'executor::tests::target_docker_javascript_actions_receive_socket_and_cli_mounts' (32161) panicked at crates/velnor-runner/src/executor.rs:17482:13:
2026-08-24T21:44:28.0000000Z error: test run failed
```

### 35485091730 / job 106009973183 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35485091730/job/106009973183

Class: unclassified. Raw SHA256: `08345362539a6a90d3a3d83d743a28f166d75161ea41181e023f3a9c564d7a17`.

```text
2026-09-20T02:52:47.5058430Z ##[error]Process completed with exit code 1.
```

### 35485091730 / job 106009986922 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35485091730/job/106009986922

Class: unclassified. Raw SHA256: `e6eae9eb9e762206a3c1af96ca45c06e6722dee756e8cb328e83cd9da81d70ec`.

```text
2026-09-20T02:52:55.0650965Z ##[error]Process completed with exit code 1.
```

### 31685148231 / job 94399393121 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/31685148231/job/94399393121

Class: unclassified. Raw SHA256: `4c8110d8eaba5f73fab2b389b1882dbec6987966e4725bc758f28cb6a776f0a7`.

```text
2026-08-13T09:07:36.1962696Z ##[error]Process completed with exit code 1.
```

### 31685148231 / job 94399411490 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/31685148231/job/94399411490

Class: unclassified. Raw SHA256: `ecc77d57dd4308a47511252e0087a685a2225829de68b71fcd038a194d58b533`.

```text
2026-08-13T09:07:41.8919673Z ##[error]Process completed with exit code 1.
```

### 31685148231 / job 94402393019 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/31685148231/job/94402393019

Class: unclassified. Raw SHA256: `f3a23aa1d08a11d7ea440f92f6f21627306e9199c281b07d1e3452032f4c2e3b`.

```text
2026-08-13T09:20:02.5445374Z ##[error]Process completed with exit code 1.
```

### 31685148231 / job 94402422033 / attempt 2

https://github.com/tailrocks/velnor/actions/runs/31685148231/job/94402422033

Class: unclassified. Raw SHA256: `872dec72f11455f3505e3a06b0d51dd995dd2c9bfc851a2146df0c190b9d55c8`.

```text
2026-08-13T09:20:08.2833554Z ##[error]Process completed with exit code 1.
```

### 32826487359 / job 97737026480 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32826487359/job/97737026480

Class: packaging. Raw SHA256: `ce9751022471101279a994bc6c22bf022c90fcc73f2510803018f6b82f791238`.

```text
2026-08-25T08:36:54.8201491Z ##[error]deb still ships the deleted velnor-runner binary
2026-08-25T08:36:54.8210794Z ##[error]Process completed with exit code 1.
```

### 32826487359 / job 97737026737 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32826487359/job/97737026737

Class: packaging. Raw SHA256: `eed49e1909f3e69ff722d042b7ef21c92b528cb8eb5d6890f261d491899cda93`.

```text
2026-08-25T08:37:24.3295231Z ##[error]deb still ships the deleted velnor-runner binary
2026-08-25T08:37:24.3306002Z ##[error]Process completed with exit code 1.
```

### 35493480986 / job 106032284742 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35493480986/job/106032284742

Class: candidate-product. Raw SHA256: `51ed41b01f09e74b94b93e793c9c16e27e17fdf4cc5eedfa1b78eb6f87ef2cff`.

```text
2026-09-20T06:09:22.7707821Z error: invalid generation config /home/runner/work/velnor/velnor/policy-checkout/.github-gen/velnor-workflow.toml: TOML parse error at line 75, column 1
2026-09-20T06:24:25.6527012Z ##[error]no candidate product velnor-workflow-candidate-23799d14e812bde9-Linux-X64 was published within 15 minutes
2026-09-20T06:24:25.6536440Z ##[error]Process completed with exit code 1.
```

### 35490258957 / job 106023966065 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35490258957/job/106023966065

Class: test-failure. Raw SHA256: `90061d1a7d8ae75ae08a1f38331790f41f4fc9c9687b9f513bfcacdc70aab0d0`.

```text
2026-09-20T05:00:06.2829487Z     thread 'an_unknown_event_stops_generation' (34922) panicked at crates/velnor-workflow/tests/scheduled_check_profiles.rs:331:5:
2026-09-20T05:00:06.3610015Z error: test run failed
2026-09-20T05:00:06.6562398Z error: CI command failed for unit rust-velnor-workflow with exit status: 100
2026-09-20T05:00:06.6625206Z ##[error]Process completed with exit code 1.
```

### 35490258957 / job 106024868745 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35490258957/job/106024868745

Class: unclassified. Raw SHA256: `9bfb4b60c6164c48012dfaa2e14b83a59541fdcb60f197999a563bec624f84b7`.

```text
2026-09-20T05:02:24.6220583Z ##[error]Process completed with exit code 1.
```

### 35490258957 / job 106024879938 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35490258957/job/106024879938

Class: unclassified. Raw SHA256: `c74f947562458d31f2b4aef65ea777145c051bf17e80c18c56d176960aa24d15`.

```text
2026-09-20T05:02:30.8521729Z ##[error]Process completed with exit code 1.
```

### 32789617516 / job 97629720621 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32789617516/job/97629720621

Class: unclassified. Raw SHA256: `4a43daaa4eb60da9690b358a5abb439e6feb5030d28484aec4f920e050914c3b`.

```text
2026-08-24T23:36:14.2619272Z ##[error]Process completed with exit code 1.
```

### 32789617516 / job 97629735339 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32789617516/job/97629735339

Class: unclassified. Raw SHA256: `f66efb55de3197fcd48bb909d01a73edc0ebfad6066ffda3438e45b5af26f7d5`.

```text
2026-08-24T23:36:18.5420684Z ##[error]Process completed with exit code 1.
```

### 31266809002 / job 93126172411 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/31266809002/job/93126172411

Class: unclassified. Raw SHA256: `641033c262c500650e2d80a6e8d3d86304f1ab330d795f33e84dfd6f442ab906`.

```text
2026-08-08T16:23:17.6722320Z error: No such remote: 'origin'
```

### 35463724236 / job 105952045933 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35463724236/job/105952045933

Class: candidate-product. Raw SHA256: `285618e713ac52454c87971014e0daf37f2ae716085ff77ee3ae25c676a329ee`.

```text
2026-09-19T19:14:40.2013113Z error: invalid generated ownership state: /home/runner/work/velnor/velnor/policy-checkout/.github/ci/.github-actions-generator-state expected the generator input
2026-09-19T19:29:41.9871403Z ##[error]no candidate product velnor-workflow-candidate-0befa3d926820155-Linux-X64 was published within 15 minutes
2026-09-19T19:29:41.9881110Z ##[error]Process completed with exit code 1.
```

### 35507168852 / job 106068839559 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35507168852/job/106068839559

Class: generated-tree;candidate-product. Raw SHA256: `f8caa373bb8658517094ea78e114e5e4aa33c3f69ac1d01ccb5b39855c66a50f`.

```text
2026-09-20T11:15:48.4526368Z error: workflow policy failed: generated-tree
2026-09-20T11:15:48.4530850Z FAIL generated-tree         could not regenerate the tree with velnor-workflow at 0dc79895ff1c5e88be7c3822c437e1c5b5282e12
2026-09-20T11:15:48.4549365Z ##[error]Process completed with exit code 1.
```

### 35517157322 / job 106094915473 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35517157322/job/106094915473

Class: generated-tree;candidate-product. Raw SHA256: `dbed2e968976ddd9dec21921cccdc4eb42416cc77be831052714e9071eb4224a`.

```text
2026-09-20T14:39:40.2572521Z error: generated files match but generation inputs changed: scan input changed from b096c93329fcc370 to 5691f3c8c8b8d479 in .github/ci/.github-actions-generator-state; regenerate to record the current generation inputs
2026-09-20T14:45:38.1825688Z ##[error]no same-repository PR run published candidate velnor-workflow-candidate-9e6bb04aed5e5a89-Linux-X64
2026-09-20T14:45:38.1835020Z ##[error]Process completed with exit code 1.
```

### 32790101256 / job 97631076992 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32790101256/job/97631076992

Class: unclassified. Raw SHA256: `e10096e70bcd64bf0a7e7dc7a52d7b7a3f5450a9753f817589f5394d4d109d0d`.

```text
2026-08-24T23:42:43.1728145Z ##[error]Process completed with exit code 1.
```

### 32790101256 / job 97631093778 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32790101256/job/97631093778

Class: unclassified. Raw SHA256: `dc9a2c279a2b514789809c7cbdae2a5237a6f9a0287cb061b7aa07b448dfeb08`.

```text
2026-08-24T23:42:52.8420186Z ##[error]Process completed with exit code 1.
```

### 32782055316 / job 97606232597 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/32782055316/job/97606232597

Class: rust-lint. Raw SHA256: `4ec9b8d504928364542e05454f91b9e5de822f4139d241f7cbd759b672a46e40`.

```text
2026-08-24T21:56:18.8881799Z error: No such remote: 'origin'
2026-08-24T21:56:21.0000000Z error: No such remote: 'origin'
2026-08-24T21:59:34.0000000Z error: large size difference between variants
2026-08-24T21:59:34.0000000Z error: could not compile `velnorctl` (lib) due to 1 previous error
2026-08-24T21:59:34.0000000Z error: could not compile `velnorctl` (lib test) due to 1 previous error
```

### 35521293443 / job 106105813547 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35521293443/job/106105813547

Class: protocol-expectation;test-failure. Raw SHA256: `b83e795570f2a65931f1d86f208661b6756446c5539e7d4b352b8bff92cc7312`.

```text
2026-09-20T16:08:58.2316390Z     thread 'scale_set_and_runner_reads_match_upstream_shapes' (44701) panicked at crates/velnor-runner/tests/scaleset_protocol.rs:516:5:
2026-09-20T16:08:58.2317307Z       left: Some(RunnerNotFound)
2026-09-20T16:08:58.2317884Z      right: Some(NotFound)
2026-09-20T16:09:11.3362942Z error: test run failed
2026-09-20T16:09:11.8310861Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-20T16:09:11.8409171Z ##[error]Process completed with exit code 1.
```

### 35521293443 / job 106107063229 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35521293443/job/106107063229

Class: unclassified. Raw SHA256: `808263919992847c46b21d0008c602ffa6d1f4d584bc516abc4cf6a0406f11de`.

```text
2026-09-20T16:09:18.1595676Z ##[error]Process completed with exit code 1.
```

### 35521293443 / job 106107074392 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35521293443/job/106107074392

Class: unclassified. Raw SHA256: `296ea6172f1ae0ebf7f22470d2a29cc0a7b1f1fecca7ba47c5b205f017fc80cc`.

```text
2026-09-20T16:09:23.3447533Z ##[error]Process completed with exit code 1.
```

### 35516406937 / job 106093038186 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35516406937/job/106093038186

Class: missing-event-fields;rust-lint. Raw SHA256: `36e5f552fbba5059a500062330a37c81c4303cbd986d9d9bf91906b33708a20a`.

```text
2026-09-20T14:26:25.7614769Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:26:25.7616426Z error[E0063]: missing fields `permit_lease` and `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:26:25.7617752Z error[E0063]: missing field `proof` in initializer of `velnor_control::journal::Event`
2026-09-20T14:26:25.7619403Z error: could not compile `velnor-runner` (lib) due to 3 previous errors
2026-09-20T14:26:25.7893071Z error: command `/home/runner/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/cargo test --no-run --message-format json-render-diagnostics --package velnor-bench --all-features --locked` exited with code 101
2026-09-20T14:26:25.8871849Z error: CI command failed for unit rust-velnor-bench with exit status: 101
2026-09-20T14:26:25.8921323Z ##[error]Process completed with exit code 1.
```

### 35516406937 / job 106093038219 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35516406937/job/106093038219

Class: missing-event-fields;rust-lint. Raw SHA256: `d54b6b205dcb90073d6ae2cf91e24f763780fef57bf60610b5fa9a347116dcdd`.

```text
2026-09-20T14:25:50.4246802Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:25:50.4249983Z error: could not compile `velnor-control` (test "journal_drain") due to 1 previous error
2026-09-20T14:25:52.4895132Z error: command `/home/runner/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/cargo test --no-run --message-format json-render-diagnostics --package velnor-control --all-features --locked` exited with code 101
2026-09-20T14:25:52.5008191Z error: CI command failed for unit rust-velnor-control with exit status: 101
2026-09-20T14:25:52.5068731Z ##[error]Process completed with exit code 1.
```

### 35516406937 / job 106093038233 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35516406937/job/106093038233

Class: missing-event-fields;rust-lint. Raw SHA256: `eea8a4515305a84e23e9f601ca26fc06400a0d6c988f4e51ec5be60a80114aad`.

```text
2026-09-20T14:28:53.9054120Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:28:53.9058592Z error[E0063]: missing fields `permit_lease` and `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:28:53.9062955Z error[E0063]: missing field `proof` in initializer of `velnor_control::journal::Event`
2026-09-20T14:28:53.9069182Z error: could not compile `velnor-runner` (lib) due to 3 previous errors
2026-09-20T14:29:02.7888514Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:29:02.7890925Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:29:02.7893008Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:29:02.7895039Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:29:02.7897307Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:29:02.7899340Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:29:02.7901580Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:29:02.7903573Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:29:02.7908062Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:29:02.7912903Z error: could not compile `velnor-runner` (lib test) due to 12 previous errors
2026-09-20T14:29:02.8219341Z error: command `/home/runner/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/cargo test --no-run --message-format json-render-diagnostics --package velnor-runner --all-features --locked` exited with code 101
2026-09-20T14:29:03.1286040Z error: CI command failed for unit rust-velnor-runner with exit status: 101
2026-09-20T14:29:03.1344004Z ##[error]Process completed with exit code 1.
```

### 35516406937 / job 106093038248 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35516406937/job/106093038248

Class: missing-event-fields;rust-lint. Raw SHA256: `c1861e27c0972367d665f873422fa42dff550af174fd2cdbb8114e2221ba7107`.

```text
2026-09-20T14:25:58.6097016Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:25:58.6121638Z error: could not compile `velnor-control` (test "journal_drain") due to 1 previous error
2026-09-20T14:26:08.1092679Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:26:08.1095187Z error[E0063]: missing fields `permit_lease` and `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:26:08.1097458Z error[E0063]: missing field `proof` in initializer of `velnor_control::journal::Event`
2026-09-20T14:26:08.1104006Z error: could not compile `velnor-runner` (lib) due to 3 previous errors
2026-09-20T14:26:17.8287647Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:26:17.8291076Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:26:17.8294060Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:26:17.8296796Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:26:17.8299686Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:26:17.8302408Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:26:17.8305114Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:26:17.8307775Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:26:17.8310784Z error: could not compile `velnor-runner` (lib test) due to 11 previous errors
2026-09-20T14:26:17.9382659Z error: CI command failed for unit rust-production-topology with exit status: 101
2026-09-20T14:26:17.9434834Z ##[error]Process completed with exit code 1.
```

### 35516406937 / job 106093038263 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35516406937/job/106093038263

Class: missing-event-fields;rust-lint. Raw SHA256: `05e0c72e98593c8698dc22dbdcaec3b74714b668870de8bf6b88ef1f2b57fada`.

```text
2026-09-20T14:26:47.2593244Z error[E0063]: missing field `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:26:47.2597022Z error[E0063]: missing fields `permit_lease` and `runner_request_id` in initializer of `velnor_control::journal::Event`
2026-09-20T14:26:47.2600006Z error[E0063]: missing field `proof` in initializer of `velnor_control::journal::Event`
2026-09-20T14:26:47.2604030Z error: could not compile `velnor-runner` (lib) due to 3 previous errors
2026-09-20T14:26:47.2912060Z error: command `/home/runner/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin/cargo test --no-run --message-format json-render-diagnostics --package velnorctl --all-features --locked` exited with code 101
2026-09-20T14:26:47.3337459Z error: CI command failed for unit rust-velnorctl with exit status: 101
2026-09-20T14:26:47.3393348Z ##[error]Process completed with exit code 1.
```

### 35516406937 / job 106093038282 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35516406937/job/106093038282

Class: generated-tree. Raw SHA256: `71be87a074a7084af73864e73cee28447bed36e6ba4cdb73b3bc6fa8713ab535`.

```text
2026-09-20T14:26:38.8836449Z error: generated files match but generation inputs changed: scan input changed from b096c93329fcc370 to 5691f3c8c8b8d479 in .github/ci/.github-actions-generator-state; regenerate to record the current generation inputs
2026-09-20T14:26:38.8871127Z error: CI command failed for unit rust-velnor-workflow with exit status: 1
2026-09-20T14:26:38.8942650Z ##[error]Process completed with exit code 1.
```

### 35516406937 / job 106093539739 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35516406937/job/106093539739

Class: unclassified. Raw SHA256: `100886dc672eb6a29786ecf0fc563587d453704a195c850bb260793836eb6752`.

```text
2026-09-20T14:29:27.7302558Z ##[error]Process completed with exit code 1.
```

### 35516406937 / job 106093593226 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35516406937/job/106093593226

Class: unclassified. Raw SHA256: `c607fdb3dece3d4e28e16fb16e8a05b954543239620fbd5275a66927dca7f279`.

```text
2026-09-20T14:29:32.9777566Z ##[error]Process completed with exit code 1.
```

### 35479501979 / job 105995308937 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35479501979/job/105995308937

Class: test-failure. Raw SHA256: `081d77f5d0860a00248dd1204c201a3dffaa2698fa1c4fe0f6078c1ee3c8a365`.

```text
2026-09-20T00:54:24.9799691Z     thread 'primitives::release::tests::identity_rows_render_the_pinned_native_surface' (26998) panicked at crates/velnor-workflow/src/primitives/release.rs:5929:9:
2026-09-20T00:54:24.9998370Z error: test run failed
2026-09-20T00:54:25.4316094Z error: CI command failed for unit rust-velnor-workflow with exit status: 100
2026-09-20T00:54:25.4370214Z ##[error]Process completed with exit code 1.
```

### 35479501979 / job 105995309095 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35479501979/job/105995309095

Class: test-failure. Raw SHA256: `3464dc605cacbcfffe3d0e75ed165f5c792e876e60a88e186a5eeae62027d860`.

```text
2026-09-20T00:54:59.3393541Z     thread 'runner::tests::microvm_job_rejects_incomplete_plan_before_backend_side_effects' (27733) panicked at crates/velnor-runner/src/runner.rs:18308:9:
2026-09-20T00:55:00.9603743Z error: test run failed
2026-09-20T00:55:01.2732496Z error: CI command failed for unit rust-velnor-runner with exit status: 100
2026-09-20T00:55:01.2838049Z ##[error]Process completed with exit code 1.
```

### 35479501979 / job 105996129070 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35479501979/job/105996129070

Class: unclassified. Raw SHA256: `851cb88cbdc2cce6d5ba19e6762fd56ae61098eed10215c041c2a2fba479931e`.

```text
2026-09-20T00:56:02.5682810Z ##[error]Process completed with exit code 1.
```

### 35479501979 / job 105996138569 / attempt 1

https://github.com/tailrocks/velnor/actions/runs/35479501979/job/105996138569

Class: unclassified. Raw SHA256: `675e26dbfca88692fb3f7522682e2e1303b1ef8be1f79fb093dc3838b47e10ec`.

```text
2026-09-20T00:56:06.5998598Z ##[error]Process completed with exit code 1.
```
