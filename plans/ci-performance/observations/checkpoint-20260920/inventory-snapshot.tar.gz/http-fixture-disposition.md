# HTTP mock body framing defect

Retained failure: run35482339365/job106002312607, head58447892; protocol::tests::artifact_overwrite_deletes_only_this_jobs_rows failed with `send artifact blob PUT: request transport failed` at protocol.rs8869.

Root: ad hoc server fixtures replied and closed after headers, leaving upload bytes unread. TCP segmentation can then produce reset/broken-pipe. Another reader treated Content-Length case-sensitively. HTTP field names are case-insensitive: https://httpwg.org/specs/rfc9110.html#fields.

Deterministic socket proof: http_fixture_probe.py; http_fixture_probe.json contains10/10 headers-only failures and10/10 full-body successes,262144-byte body, explicit synchronization controls headers/body segmentation.

Repair: shared test-only read_mock_http_request, used by13 mock request reads. Case-insensitive Content-Length, complete framed body, premature-EOF errors, explicit unsupported framing errors. Production prefix byte-identical to HEAD. PROBE sentinels retain their separate non-HTTP read path. No transport retries or production protocol changes.

Regression: exact helper/tests extracted into http_fixture_reader_tests.rs and compiled with rustc --edition=2024 --cfg feature=\"test-support\" --test.3/3pass. Cases:256KiB body split from fragmented headers, three header casings; header/body prematureEOF; bodyless request; malformed/conflicting/chunked framing. Removing body read in http_fixture_reader_mutant.rs causes two tests to fail. rustfmt and git diff --check passed. Parent completed actual crate validation: `rtk cargo test -p velnor-runner --locked --features test-support protocol::tests::`:131passed,2396filtered,18suites,9.36s test time, session96057 exit0.

Patch snapshot: http_fixture_reader.patch.gz. Standalone pass/mutation logs retained. Parent independently confirmed mechanism and authorized shared cfg(test)-only patch; Parent reviewed helper and13 migrated call sites, confirmed production unchanged. New hosted CI successor verification remains pending.
