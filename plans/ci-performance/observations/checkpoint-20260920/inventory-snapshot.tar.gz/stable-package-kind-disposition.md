# Stable package channel boundary repair

Source-derived defect discovered during native ARM emitter review, not attributed to an unobserved historical log. Stable renderer writes package.kind=stable; tagged build embeds identity.kind=release. Emitter admitted release builds then compared strings literally, making stable emission impossible. Existing preview-only acceptance test and an invalid stable-valued embedded identity test concealed the vocabulary mismatch.

Repair in isolated crates/velnor-runner/src/release.rs: one private typed PackageKind conversion from embedded identity (release→Stable, preview→Preview), explicit exclusion of development/unknown kinds/source, then compare canonical package channel. No wire schema changes. Existing commit/version/canonical record/digest checks and stable activation requirement remain.

Regression: every supported architecture × both actual build kinds × both record channels; matching pairs accepted, cross-kind pairs rejected with specific diagnostic. Invalid development/unknown/stable-aliased embedded kinds and development source remain rejected. Existing drift test now uses actual release build vocabulary.

rustfmt --edition2024 --check and git diff --check passed. No Cargo build/test yet because parent allocated compiler to another agent. Requested command: rtk cargo test -p velnor-runner --locked --features test-support release::tests::emit_package_record. Independent bootstrap author review passed: no findings; typed mapping, preservation checks and regression matrix verified. Parent independently reviewed and accepted mapping/tests. Cargo execution still queued behind generator correctness checks. Patch SHA256: 9e53f437b064ed5a34c1a0b4d6d5d1becae525b960ee7276fc19fa8193940dcf
