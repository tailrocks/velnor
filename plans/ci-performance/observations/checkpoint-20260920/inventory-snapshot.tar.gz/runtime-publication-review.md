# Runtime product publication review — 2026-09-20

Independent conclusion: the proposed published-record-before-assets race is disproven for the inspected GitHub CLI implementations. No evidence supports replacing `gh release create TAG assets...` with another staging transaction.

## Primary evidence

- Official manual https://cli.github.com/manual/gh_release_create documents draft creation, asset upload, then publication.
- Versioned source https://github.com/cli/cli/blob/v2.65.0/pkg/cmd/release/create/create.go#L430-L490 and https://github.com/cli/cli/blob/v2.101.0/pkg/cmd/release/create/create.go#L462-L520 implement that order. Upload/publication errors invoke draft deletion; deletion failure is reported. Process termination can bypass cleanup, but no such retained runtime-products survivor was established.
- Local CLI is `gh version 2.101.0 (2026-09-15)`. Retained job logs searched do not print a version; local version is not evidence of every runner version. The same behavior already exists in v2.65.0.
- https://github.com/cli/cli/blob/v2.101.0/pkg/cmd/release/shared/fetch.go distinguishes REST published-tag lookup from GraphQL draft lookup. `gh release view` intentionally includes drafts.
- https://docs.github.com/en/rest/releases/releases says draft listings require push access; published resources can be public. A contents-read consumer should not rely on draft visibility. No live draft experiment was performed; API use paused.

## Concrete source findings

Inspected isolated runtime_products.rs closure existence check (~334) and publisher recheck (~527). Both treat any successful `gh release view` as a completed product and every error as absence. With publisher contents-write, an abandoned draft is visible and causes successful exit without publishing. With closure contents-read, draft visibility differs; it may rebuild before the writer skips. Auth/rate/network errors are incorrectly treated as absence. Existing incomplete/corrupt published products also short-circuit without verifying the acceptance contract.

Current workflow serializes `runtime-products-${github.ref}`, cancellation disabled, and rejects refs other than configured default branch before building. Thus normal successful producer executions for this contract do not race each other on a closure. Manual external writers remain outside that serialization; do not introduce overwrite/adoption behavior for them.

## Minimal correct behavior

Keep the existing create-with-assets transaction. Resolve exact published state through one classified lookup, accept only actual 404 as absent, and propagate other failures. Do not call draft presence complete. A published product accepted as already complete must satisfy the same expected full closure, revision provenance, platform manifest and immutable asset acceptance checks used by its consumers; tag prefix alone is insufficient.

A detected draft must be an explicit incomplete state. The narrow safe behavior is a diagnostic failure naming its release ID and recovery requirement, never silent success. Automatic recovery needs separate proof of ownership/expected target and bytes before mutation; no concrete surviving draft evidence currently justifies implementing it. Never `--clobber`, delete a published release, or relabel unknown draft contents. If interruption recovery is added later, serialize under the existing producer contract, validate its provenance and complete asset set, and publish only after verifying the exact remote assets; do not adopt arbitrary same-tag drafts.

Protected origin remains the producer workflow ref guard, clean checked-out source closure, platform self-report and attestation source-ref/workflow validation. `--target HEAD_SHA` only controls creation of a missing tag; API docs say existing tags ignore target_commitish. Published acceptance must therefore not infer origin merely from that flag.

## Requested fixture coverage

Published valid → skip; exact 404 → build/create; HTTP403/429/500 or transport failure → fail before build; draft → explicit incomplete failure; published wrong closure/missing asset/invalid attestation → fail; normal asset-bearing create remains one CLI operation. No generic sleep/retry and no production publication was performed.
