# Required PR package preflight — bounded design review

Read-only source review; no repository edits or builds. Source: isolated bootstrap tree, 2026-09-20.

## Outcome

Add a typed read-only validation entrypoint for the existing native Debian contract, then call it from CI / PR and include its result as a required control obligation. Reuse the package step builders shared with Preview/release. Do not call the current publishing workflow with an assumed dry-run mode or string-remove publication jobs: Preview exposes no validation mode; stable verify requires release-tag identity and includes image/publication surfaces.

Active .github/ci/project.toml: release enabled, kind native, velnor-runner, amd64+arm64 Linux targets, consumer tailrocks/velnor-apt; scanner detects release-build, guest-agent and guest-image. `native_debian_release` (release.rs965–972) identifies this contract without repo-name exceptions. No emitted current PR packaging or install check was found. Existing rust-release-boundary unit only checks workspace/release-feature boundaries; it does not execute Debian/guest/metadata stages.

## Minimal typed entrypoint and graph

Expose `native_package_validation_content(config)` from release.rs, returning no workflow unless native_debian_release applies. Prefer one generated reusable `ci-release-validate.yml`, workflow_call with exact checked-out integration SHA, same-run runtime transport identity and source identity inputs. The root CI/PR caller has `needs: plan`, read-only permissions, no secrets inheritance, and an explicit result checked by `RequiredControl`/required_controls in primitives/ir.rs2732–2760,3900 onward. Initially make the declared contract an unconditional PR control obligation; skipping requires a separately proven package-input closure, not an arbitrary Rust-unit selection. Required gate must fail on failed/cancelled/unexpected skipped caller.

Typed internal context should replace overloaded `preview: bool` where needed: stable publication, preview publication, PR validation. Context owns source SHA, needs/job IDs, branch guard, artifact namespace and whether publication exists. Reuse concrete guest/metadata/Debian steps; never rewrite finished YAML to erase guards or credentials.

Graph:

plan/runtime → identity(exact integration SHA)
identity → metadata(single canonical build-identity/manifest)
identity → guest-payload(amd64,arm64 native)
metadata + guest-payload → debian(amd64,arm64 native)
debian → install(amd64,arm64 native)
all → required validation result → existing CI required gate

Runtime placement must match each actual executing host and reuse the bootstrap producer ownership design. A reusable called within CI shares the workflow run artifact namespace: do not create another Linux-X64 artifact with the same name as plan's upload. Either pass the existing plan product through its verified transport and separately produce missing platforms, or expose namespaced typed producer ownership. Exact producer job/run/attempt checks must remain intact.

## Existing implementation to reuse

- release.rs1177 render_guest_payload_job: detected guest bins, guest seed restore/build, exact five-file artifact upload; matrix native architecture. Cache saves already restricted to push on default branch, so PR only restores. Preserve those conditions.
- 1333 render_release_metadata_job: one release-build binary exports canonical metadata. Download destinations remain RUNNER_TEMP; the clean source identity gate must observe no artifacts.
- 1547 render_identity_debian_job: native ARM toolchain validation, release binary, sibling binaries, identity staging, exact guest checksum/staging, package-deb, empty-package/version/arch/record/binary digest guards.
- 1492 debian_guard_steps: useful archive-byte proof, but does not install or execute package maintainer scripts.
- Installed-package checks exist in runner release commands: `release export`, `capabilities export`, `release verify-record`, `release activate`, `release verify-installed`. VerifyInstalled accepts explicit record/deployed/binary/arch paths (service.rs368). Preview package activation requires no OCI release chain; stable activation does.

## PR identity and history differences

Current Preview identity is gated to refs/heads/default_branch and verifies checkout SHA equals event SHA (2036). PR validation must instead bind the actual synthetic integration checkout `${github.sha}` and keep it consistent through every job; using PR head SHA in one stage and merge SHA in another violates build.rs.

Preview-mode build identity already supports any exact clean checked-out SHA through VELNOR_PREVIEW_SOURCE_SHA; build.rs152–195 requires full lowercase SHA, HEAD equality, clean tree and crate/lockfile version equality. It does not require a main-branch commit or a release tag. Reuse this truthful preview identity for PR test packages; do not fabricate a stable vX.Y.Z tag or relax stable release-build coherence. Version can use existing crate~preview.run+shortSHA form under a validation-only artifact namespace.

Stable build.rs95–149 requires exactly one matching v* tag at HEAD plus crate/lockfile agreement; a normal PR cannot directly run that path. This preflight proves packaging under preview identity, not stable tag publication or APT/OCI credential behavior. Existing tag/record tests and protected release workflow retain those obligations.

Policy/runtime ancestry validation requires full checkout history. Plain preview binary identity itself needs HEAD/status/lockfile, not tag ancestry. Explicit exact-SHA checkout plus fetch-depth0 is the simplest shared contract, with persist-credentials false. No checkout of a moving branch after identity resolution.

## Install proof

Add an actual native install job using the exact produced architecture package in a disposable GitHub-hosted VM, then execute installed CLI metadata/record checks and verify packaged guest bytes. Merely dpkg-deb extraction is not installation proof: postinst validates installed binary/source and compiled manifest (debian/postinst215–231) and microvm checksums. It also manages the package cache-GC timer; fleet daemon activation is explicitly separate. No fleet secrets, no production host access.

For active Velnor preview contract, an isolated release store can exercise preview package activation then verify-installed with explicit paths, without starting fleet daemons. Do not universally invent Velnor CLI behavior for arbitrary native projects: only the already detected native identity contract supplies these commands, or add a typed validation capability for generic install commands. Package install dependencies and supported distro belong to the declared package contract.

## Newly found blocker

`render_release_metadata_job` exports `{binary}-release-tool` from the single X64 metadata runner; `debian_identity_steps` executes it in every Debian job. New native ARM placement makes this X64 ELF executable incompatible. Both stable and preview jobs already possess the correct native target runner before record emission, so use that verified target executable to emit its own package record; preserve the shared metadata bytes. Parent and bootstrap author notified. Do not add QEMU merely to hide a wrong executable handoff.

## Required proof before rollout

Golden/structural tests: validation graph contains no publication/signing/registry write jobs or elevated token permissions; source SHA is one exact value; both target architectures present; required gate rejects skipped/failed control; fixture projects without native Debian contract omit this capability; namespaced artifacts have no duplicate producers.

Real Linux CI: execute amd64 and arm64 guest→metadata→Debian→install path. Reintroducing workspace metadata pollution, wildcard rootfs upload, wrong architecture release tool, or missing ARM compiler must fail the premerge required check. Keep a failure visible; no `continue-on-error` or provider trust skip for this hosted read-only package validation.

## Follow-up emitter review

Author changed hosted Debian record emission to execute target/$TARGET/release/$binary; local cross-compiling provider keeps metadata's host tool. Source review passes for active hosted native placement. Regression now places exit99 poison at metadata release-tool and runnable stub in both target paths, executing stable/preview shell with amd64 and arm64 target substitutions. This proves executable selection once tests pass; it does not prove actual release CLI semantics.

Actual emitter semantics exposed a separate pre-existing stable package failure: renderer `kind=stable` (release.rs native identity Debian tuple); build.rs84 embeds `VELNOR_BUILD_KIND=release`; runner release.rs1411 compares package-record kind literally against embedded kind. Both are independently constrained vocabularies: PackageRecord::verify accepts stable/preview; emitter only admits embedded release/preview. Consequently no stable record can pass with any actual release binary. Parent notified. Correct semantic boundary maps embedded release→package stable and embedded preview→package preview, rejecting cross-kind/development. No retained failure log containing the kind mismatch was located; this is source proof, not an asserted historical cause. Add real emit_package_record regression; shell stand-ins cannot validate this contract.

## Matrix transport uniqueness

Source inspection found both native Debian matrix rows upload `debian-packages`, which the signer/publisher treat as one mutable multi-writer artifact. The pinned v7 primary README still forbids this: https://github.com/actions/upload-artifact/blob/v7/README.md#not-uploading-to-the-same-artifact. Parent authorized shared builder correction: per-architecture immutable names, exact signer lookup, publisher declared-set download/staging with duplicate path rejection. No overwrite workaround. No historical log is attributed to this source-proven failure without evidence.

## Concurrency follow-up (separate required increment)

Parent independently identified workflow-wide Preview group `preview-${github.repository}` with cancel-in-progress false. GitHub can replace pending runs; false is not a durable FIFO promise. It also serializes all deterministic builds. Runtime-products has the same whole-workflow issue. After preflight, retain only publication-resource serialization and enforce stale-source monotonicity at the publisher; let main validation/builds run independently. Original runtime publication review established ordinary writer mutual exclusion, not pending-run survival.
