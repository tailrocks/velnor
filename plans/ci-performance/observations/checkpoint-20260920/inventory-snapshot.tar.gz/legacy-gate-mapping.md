# Legacy schema gate mapping — do not mechanically port schema2 verdict

legacy src/runtime.rs1505 plan computes diff selection then selection_for_lanes; output units is comma-separated unit IDs, no per-provider obligations or digest/exclusion plan. plan_lanes_for_value1667 accepts github/velnor/both and absent means both. selection_for_lanes1688 only filters unit kinds the selected lane(s) can execute; it does not create expected unit×lane pairs.

legacy primitives/ir.rs3662 tests unit membership separately from LANE_ADMITTED_* predicates. Concrete supported path: runners=Both, dispatch runner=github, Rust unit selected in CSV. GitHub caller succeeds; Velnor caller is selected by unit ID yet admissionfalse and skipped. That is valid for this schema. VelnorTrusted also becomes event&&false when no trusted runner was online at generation(ir.rs5992); legacy planner does not encode this availability exclusion. Porting schema2 selected+unadmitted=>fail would break these supported paths.

Current other permissiveness: unselected success|skipped accepted. No evidence that an unselected unit caller should execute; assess prerequisite selected_by mapping before tightening. For full expected-set contract, freeze effective unit×lane obligations and explicit exclusions before execution, then compare strict exact results as schema2 does. Availability/authorization exclusions require deliberate semantics; no implicit removal of selected verification because a runner is offline.

Parent notified; read-only, no source edits or blanket claim that legacy final-gate requirement is complete. Source references are legacy paths, not s2 equivalents.
