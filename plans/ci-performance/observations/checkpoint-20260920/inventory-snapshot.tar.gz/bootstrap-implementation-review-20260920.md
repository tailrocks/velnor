# Independent bootstrap implementation review — 2026-09-20T17:05Z

Reviewed stable draft in /tmp/velnor-bootstrap-97bac4c: s2/primitives/runtime_bootstrap.rs; s2/mod.rs owner renderer adapter, policy validator capture, runtime download/upload; s2/policy.rs parity changes. Read-only review; author owns implementation/tests.

Earlier findings addressed in source:
- Pin reachable from checkout; full pin closure equals audited PR head and synthetic integration HEAD before normal root production.
- Trusted-validator bootstrap pins trusted base, disables candidate publication and compares its own source; clean worktree compile uses env-i, isolated CARGO_HOME/CARGO_TARGET_DIR and explicit PATH/HOME/RUSTUP_HOME.
- Published lookup permits fallback only on explicit HTTP404;401/403/500/network errors fail. A product that exists proceeds through attested setup, with no source fallback for bad manifest/digest/attestation.
- Candidate manifest remains debug/tui and source-bound for old-base adapter compatibility; first migration requires proving new sourceA closure is unpublished. New trusted adapter checks declared published renderer before candidate lookup.
- Transport is staged under RUNNER_TEMP, removing dirty-checkout packaging regression.
- Download verifies repository/run/attempt/platform/revision/profile/features, computes full closure from declared pin tree, compares both binary digests before any execution. Producer artifact names bind revision/platform/attempt within the current run.
- Absolute trusted validator path captured before installing declared renderer; renderer setup cannot silently replace validator authority via PATH.
- Both policy report and verify_declared_pin_renders_tree reject Candidate-only rendering on PR and main alike.

No additional concrete trust defect found in reviewed draft. This is not final acceptance: author-reported release generic root ownership/platform mapping and local Velnor pinned-policy publication race remain open; tests were still running during review. Need generated workflow graph validation, actual sourceA absence proof and PR/main successor evidence. Existing compiler-environment test asserts generated script text; negative transport test executes verification script and mutates each binding, source fixture exercises HTTP and closure branches. Whole generated root workflow not executed by this review.

## Permission concern disproven for current public repository

Initial documentation-based concern: policy cross-run candidate download uses gh run download/REST archive with contents:read-only GITHUB_TOKEN, while official REST docs list Actions(read). Parent supplied actual successful Policy job106112166861: token Contents:read+Metadata:read, explicit candidate-path fallthrough16:46:15Z, candidate paths exported16:50:32Z, generated-treePASS16:50:35Z. This directly proves current public-repository restricted-token download works; no migration blocker on this basis. Independent sampled jobs106108093299 and106095910945 likewise enter candidate path and succeed. Exact parent log gz, selected excerpts and SHA256 retained alongside this review.

Docs: https://docs.github.com/en/rest/actions/artifacts#download-an-artifact lists read Actions for installation tokens; public listing endpoint explicitly documents unauthenticated access, archive section lacks that sentence. Actual runtime behavior is stronger evidence for this repository. Generic private-repository compatibility would need separate test if claiming that scope; not reproduced or asserted broken here. Parent/author received correction promptly.
