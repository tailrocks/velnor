# Guest payload upload EACCES — source repair + hosted successors

Failure example Preview35192164083/job105107031052,2026-09-17T07:10:28Z: EACCES scandir dist/microvm/work/rootfs-tree/lib/ssl/private. Upload path dist/microvm/* traverses build scratch, including rootfs symlink into a root-only host directory.32 grouped failed guest upload jobs in current partial sweep; exact per-job signature must be checked before sharing this disposition.

Root fix e3a21bffdb3551bd86609bc22de2dd8dee8ea67b replaces wildcard with exactly five consumer deliverables (vmlinux,rootfs.ext4,rootfs.sha256,velnor-guest-agent,guest-agent.sha256); primitive contract regression plus regenerated Preview/release. Current s2/primitives/release.rs1261 and both generated workflows retain explicit list. Parent repo git merge-base confirms fix ancestor386a5b63.

Actual hosted successor Preview35515840346 head386a5b63: job106091539371 Guest payload x86_64 Upload guest payload success14:26:16Z; job106091539397 Guest payload aarch64 success14:22:20Z. Exact logs downloaded and SHA256/excerpts preserved. Overall Preview later fails distinct dirty-source and ARMcompiler defects; guest upload successor itself passed on both architectures. Current97bac4c Preview is blocked before guest jobs by policy, so no same-head full-pipeline success claim.
