import pathlib,json,gzip,hashlib,csv,re,collections,datetime
P=pathlib.Path('/tmp/velnor-failures');O=P/'deliverables';O.mkdir(exist_ok=True)
runs=json.loads((P/'runs.json').read_text());prior=[json.loads(p.read_text()) for p in (P/'attempts').glob('*.json')];rm={r['id']:r for r in runs};keys=['id','name','path','head_branch','head_sha','event','status','conclusion','run_number','run_attempt','created_at','updated_at','run_started_at','html_url','check_suite_id','referenced_workflows','pull_requests','head_commit']
compact=lambda r:{k:r[k] for k in keys if k in r}
catalog={'collected_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'collection':'unfiltered GET actions/runs?per_page=100, gh --paginate --slurp; all 76 pages, total_count=7594; attempts/{n} for every earlier attempt','latest_runs':[compact(r) for r in runs],'earlier_attempts':[compact(r) for r in prior]}
with gzip.open(O/'retained-runs-attempts-20260920.json.gz','wt') as f:json.dump(catalog,f,separators=(',',':'))
classes=[('generated-tree','generated-tree|generated files differ|generation inputs changed','Renderer/pin/scan-input identity mismatch','PR exact-tree generation policy, same prospective-main semantics','Current bootstrap/parity repair required; individual old revisions need successor evidence'),('candidate-product','no candidate product|no same-repository PR run published candidate','Candidate bootstrap lacks event-equivalent source-bound producer','Before planning, source-bound build-once product','Current main-only producer lookup defect; repair pending'),('cross-compiler','aarch64-linux-gnu-gcc.*(?:not found|No such file)|failed to find tool "aarch64-linux-gnu-gcc"','Target compiler not provided by selected runner','PR deterministic package build per target','Current ARM preview route remains wrong; open PR962 relevant'),('dirty-preview','preview-build: refusing to embed identity from a dirty tree','Generated metadata staged inside identity-sensitive source checkout','PR source-clean package preflight','Source repair57e7cafc present; Preview blocked before successor execution'),('dead-code','variant `Contended` is never constructed','Stale error variant after acquisition semantics changed','Staged Clippy and PR Clippy','Fixed7308307b; green successor PR35522028476; main CI pending'),('missing-event-fields','missing field.*initializer of.*Event','Schema expansion not propagated to test consumers','Staged Clippy/all-target compilation','Historical PR integration revisions; inspect successor source'),('superseded-diagnostics-deletion',"A.s logs were exported before deletion",'Historical candidate deletes state before unchanged test asserts diagnostics persist','Hermetic lifecycle test before merge','Superseded unmerged lifecycle implementation; current source omits deletion; same unchanged test PASS35522028476/job106107688847'),('protocol-expectation','left: Some\(RunnerNotFound\)','Changed error contract with stale expectation','PR tests','Fixedc24be56e; green successor PR35522028476'),('test-failure','test result: FAILED|test run failed','Test failure, root not yet classified','PR tests','Unresolved historical signature; successor/source inspection required'),('rust-lint','error: (?:unused|variable does not need|this expression creates|useless conversion|large size difference)|error\[E','Rust compile/lint failure, individual diagnostic retained','Staged canonical Clippy and PR equivalent','Unresolved historical signature; no blanket repaired claim'),('packaging','##\[error\].*(?:published binary digest != record|deb still ships|package-record)','Artifact construction/identity mismatch','PR package/install preflight','Historical publication/package failure; inspect current invariants'),('lockfile','cannot update the lock file.*--locked','Tracked lockfile inconsistent with build inputs','Staged locked validation and PR cold build','Historical; successor verification required')]
def missing_log_status(error):
 if not error.exists():return ('unclassified','Pending classification')
 message=error.read_text(errors='replace')
 if 'rate limit exceeded' in message.lower() or 'HTTP 429' in message:return ('deferred-quota','Quota response; deferred evidence gap, retry within allocated budget')
 if 'HTTP 404' in message or 'HTTP 410' in message:return ('unavailable-log','API404/410; retained log endpoint unavailable, exact stderr preserved')
 return ('deferred-api-error','API error; evidence deferred, inspect exact stderr; not classified unavailable')
jobs=[];perrun=collections.defaultdict(list)
for p in (P/'jobs').glob('*.json'):
 try:pages=json.loads(p.read_text())
 except Exception:continue
 for page in pages:
  for j in page['jobs']:jobs.append(j);perrun[j['run_id']].append(j)
jobs=list({j['id']:j for j in jobs}.values());jrows=[];excerpts=[]
for j in jobs:
 if j.get('conclusion') in ['success','skipped']:continue
 r=rm.get(j['run_id'],{});lf=P/'logs'/f"{j['id']}.log";err=lf.with_suffix('.err');raw=lf.read_bytes() if lf.exists() else b'';s=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',raw.decode(errors='replace'));hits=[x for x in classes if re.search(x[1],s,re.S)];missing_class,missing_disposition=missing_log_status(err);cid=';'.join(x[0] for x in hits) or missing_class;sig=[]
 for line in s.splitlines():
  if re.search(r'(##\[error\]|^\S+ error(?:\[|:)|panicked at|^\S+ FAIL |thread .*panicked|A.s logs were|left:|right:)',line):sig.append(line)
 sig=sig[:25]
 row={'run_id':j['run_id'],'attempt':j.get('run_attempt'),'job_id':j['id'],'event':r.get('event'),'branch':r.get('head_branch'),'head_sha':j.get('head_sha'),'workflow':r.get('path'),'job':j['name'],'conclusion':j.get('conclusion'),'runner':j.get('runner_name'),'runner_labels':','.join(j.get('labels',[])),'failed_steps':';'.join(x['name'] for x in j.get('steps',[]) if x.get('conclusion')=='failure'),'class':cid,'signature':' | '.join(sig),'root_cause':';'.join(dict.fromkeys(x[2] for x in hits)) or 'Unproven','earliest_prevention':';'.join(dict.fromkeys(x[3] for x in hits)) or 'Pending diagnosis','disposition':';'.join(dict.fromkeys(x[4] for x in hits)) or missing_disposition,'reproduction':'Exact checked-out revision + command in raw job log; current successor regression pending','fix':'See class disposition; no blanket fix claim','regression_check':'Pending independent verification unless exact successor stated','independent_review':'Pending','verification_run':'35522028476 only for PR977 repaired dead-code/protocol classes','url':j['html_url'],'raw_log':str(lf),'log_sha256':hashlib.sha256(raw).hexdigest() if raw else ''}
 jrows.append(row)
 if sig:excerpts.append(f"### {j['run_id']} / job {j['id']} / attempt {j.get('run_attempt')}\n\n{j['html_url']}\n\nClass: {cid}. Raw SHA256: `{row['log_sha256']}`.\n\n```text\n"+'\n'.join(sig)+"\n```\n")
if jrows:
 with (O/'inspected-failed-jobs.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(jrows[0]));w.writeheader();w.writerows(jrows)
with gzip.open(O/'failure-excerpts.md.gz','wt') as f:f.write('\n'.join(excerpts))
rows=[]
for r in runs+prior:
 if r.get('conclusion')=='success':continue
 js=[j for j in perrun.get(r['id'],[]) if j.get('run_attempt')==r['run_attempt']];bad=[j for j in js if j.get('conclusion') not in ['success','skipped']]
 rows.append({'run_id':r['id'],'attempt':r['run_attempt'],'event':r['event'],'branch':r['head_branch'],'head_sha':r['head_sha'],'workflow':r['path'],'created_at':r['created_at'],'conclusion':r['conclusion'],'status':r['status'],'job_ids':';'.join(str(j['id']) for j in bad),'jobs_inspected':len(js),'disposition':'See failed-job ledger; cancellation intentionality not assumed' if js else 'Metadata cataloged; detailed job/log classification still outstanding','url':r['html_url']})
with (O/'retained-nongreen-attempts.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
count=collections.Counter(r['conclusion'] for r in runs);prcount=collections.Counter(r['conclusion'] for r in prior);am={(r['id'],r['run_attempt']):r for r in prior};main=[r for r in runs if r['event']=='push' and r['head_branch']=='main'];first=[am.get((r['id'],1),r) for r in main];fc=collections.Counter(r['conclusion'] for r in first);mc=collections.Counter(r['conclusion'] for r in main)
summary=f'''# Retained CI failure inventory — 2026-09-20

Run/attempt metadata complete; detailed job/log sweep bounded and incomplete. All failures are NOT disposed.

- Retained runs: {len(runs)}, 76 unfiltered pages; API total_count reconciles exactly. Oldest 2026-06-04T22:42:50Z; newest 2026-09-20T16:23:53Z. Enumeration completed before 2026-09-20T16:31:45Z. Latest observed creation time is not a cutoff guarantee; refresh before integration/completion.
- Latest conclusions: {dict(count)}.
- All {len(prior)} earlier attempts retrieved across 182 rerun runs: {dict(prcount)}. 30 failed earlier attempts belong to currently successful runs. Two old attempt records report queued although later attempts exist; historical API snapshots do not prove live work.
- Jobs: filter=all, per_page100, all pages (initial gh pagination, subsequent explicit counted pages) for {len(perrun)} runs; {len(jobs)} unique jobs. Failed/nonterminal/cancelled job rows: {len(jrows)}. Log API errors: {len(list((P/'logs').glob('*.err')))}.
- Main-push first-attempt green: {fc['success']}/{len(first)-fc[None]} terminal workflow runs ({fc['success']/(len(first)-fc[None]):.6%}); latest green: {mc['success']}/{len(main)-mc[None]}. Cancellations and historical workflows included. Denominator counts workflow runs, NOT per-commit aggregate pipelines. {sum(r['run_attempt']>1 for r in main)} main-push runs retried. No inference of 99.9999% reliability justified.

## Collection semantics

[Workflow runs API](https://docs.github.com/en/rest/actions/workflow-runs): filtered searches cap at 1000; unfiltered all-pages enumeration returned 7594. Earlier attempts requested via /runs/ID/attempts/N. [Workflow jobs API](https://docs.github.com/en/rest/actions/workflow-jobs): default filter=latest hides prior jobs; filter=all and all pages explicitly collected.

Initial gh logs failed terminal-escape validation; --allow-escape-sequences recovered both user targets. Terminal missing job logs return HTTP404 or HTTP410. Quota403/429 and transient errors are deferred/requeued gaps, not unavailable evidence. Exact stderr retained under /tmp/velnor-failures/logs/*.err. Missing evidence is not a solved defect.

## Confirmed classes

| Class | Evidence | Disposition / required prevention |
|---|---|---|
| Renderer parity | Target 35520255573/job106102991421 main845d474; Preview35522583904/job106109107399 main97bac4c | generated-tree differs pin38dbf85; current s2/policy.rs448 admits Candidate on PR, rejects mainline. Exact pin/render + source-bound bootstrap parity required. |
| Candidate acquisition | Main35520255650/job106102994568 | 15minute PR-only lookup at merge SHA finds no product. Build-once candidate must precede planning and use eligible current event. |
| Clippy dead-code | Target35520875130/job106104648299, PR977 headb3f9f5d; checked-out merge0fdb6be8 | GuardError::Contended at permit_guard.rs474; fixed7308307b; PR successor35522028476 green. Overall cancelled run still contains genuine failed job. No target formatting failure. |
| Dirty preview source | Main35515840346/job106093233951,386a5b63 | Download to workspace/metadata dirties identity-sensitive source.57e7cafc moves to runner.temp; source repair present, successor Preview blocked at policy. |
| ARM compiler route | Same run/job106093233952 | aarch64-linux-gnu-gcc missing. Current ARM Debian row still ubuntu-24.04 x64. Open PR962 relevant. Require native/cross compiler policy + PR package preflight. |
| Diagnostic lifecycle | PR35520025700/job106102422435,7a94393b | scaleset_daemon::crash_with_dead_workers_fails_explicitly lacks runner.log. Historical tested merge b9f7e19f called release_owned_state before the unchanged assertion; final selective integration excludes that lifecycle code. Source comparison proves removal; same test PASS in35522028476/job106107688847. |
| Protocol expectation | PR35521293443/job106105813547,7308307b | RunnerNotFound vs NotFound fixedc24be56e; PR successor35522028476 green. |

## Artifacts / remaining gaps

retained-runs-attempts-20260920.json.gz contains complete compact run/attempt metadata. retained-nongreen-attempts.csv covers every non-success latest/earlier attempt. inspected-failed-jobs.csv preserves individual signatures/root/prevention/disposition and raw hashes; auto classes are labels, not completed diagnosis. failure-excerpts.md.gz preserves exact excerpts. Full originals remain /tmp/velnor-failures.

Remaining: older jobs beyond Sept20+rerun sweep; cancellation intent; startup annotation coverage complete for 26 attempts:24 suites no checks,2 suites16 checks each; only cancellation annotations exposed; historical parser diagnosis comes from preserved plan, not recovered original annotations; unexpected skip applicability; open PR checks; independent review/regression/successor proof for every class; refresh during integration.
'''
(O/'inventory-summary.md').write_text(summary)
for f in sorted(O.iterdir()):print(f.name,f.stat().st_size)
