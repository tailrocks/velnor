"""Read-only retained CI sweep. Requires a parent-allocated request ceiling.
Never retries quota failures or trusts /rate_limit. Every HTTP page counts.
"""
import argparse, concurrent.futures, datetime, json, pathlib, re, subprocess, threading
P = pathlib.Path('/tmp/velnor-failures')
args_parser = argparse.ArgumentParser()
args_parser.add_argument('--max-requests', type=int, required=True)
args_parser.add_argument('--allocation-id', required=True)
args_parser.add_argument('--workers', type=int, default=2, choices=[1, 2, 3])
args_parser.add_argument('--census-only', action='store_true', help='finish run job pagination before collecting more failure logs')
args = args_parser.parse_args()
if not 1 <= args.max_requests <= 2000:
    args_parser.error('parent allocation must be between 1 and 2000 requests; allocate another bounded slice explicitly')
state_path = P / f'api-budget-{args.allocation_id}.json'
if state_path.exists():
    args_parser.error('allocation ID already used; refuse implicit budget reset')
lock = threading.Lock()
stop = threading.Event()
state = {'allocation_id': args.allocation_id, 'limit': args.max_requests, 'reserved': 0, 'status': 'running', 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'last_response_headers': []}
def save_state():
    temporary = state_path.with_suffix('.tmp')
    temporary.write_text(json.dumps(state, indent=2))
    temporary.replace(state_path)
def stop_with(reason):
    with lock:
        state['status'] = reason
        save_state()
    stop.set()
def split_response(data):
    headers = []
    while data.startswith(b'HTTP/'):
        pieces = re.split(rb'\r?\n\r?\n', data, maxsplit=1)
        if len(pieces) != 2:
            raise ValueError('response has incomplete HTTP headers')
        block, data = pieces
        headers.extend(line.decode(errors='replace') for line in block.splitlines() if line.lower().startswith((b'http/', b'x-ratelimit-', b'retry-after:', b'date:')))
    return headers, data
class Deferred(Exception):
    pass
class ApiFailure(Exception):
    def __init__(self, error):
        self.error = error

def api(endpoint):
    for attempt in range(2):
        with lock:
            if stop.is_set() or state['reserved'] >= state['limit']:
                if not stop.is_set():
                    state['status'] = 'allocation-exhausted'
                    save_state()
                    stop.set()
                raise Deferred()
            state['reserved'] += 1
            state['last_endpoint'] = endpoint
            save_state()
        try:
            q = subprocess.run(['gh', 'api', '--include', endpoint, '--allow-escape-sequences'], capture_output=True, timeout=120)
        except subprocess.TimeoutExpired:
            stop_with('endpoint-timeout-review-required')
            raise Deferred()
        headers, data = split_response(q.stdout)
        with lock:
            state['last_response_headers'] = headers
            save_state()
        error = q.stderr.decode(errors='replace')
        quota = q.returncode and ('rate limit exceeded' in error.lower() or '(HTTP 429)' in error)
        if quota:
            stop_with('quota-response-stop')
            (P / f'quota-stop-{args.allocation_id}.json').write_text(json.dumps({'endpoint': endpoint, 'headers': headers, 'error': error}, indent=2))
            raise Deferred()
        remaining = next((int(line.split(':', 1)[1].strip()) for line in reversed(headers) if line.lower().startswith('x-ratelimit-remaining:')), None)
        if remaining is not None and remaining < 1500:
            stop_with('actual-response-reserve-stop')
        if q.returncode:
            if attempt == 0 and '(HTTP 502)' in error and not stop.is_set():
                continue
            raise ApiFailure(error)
        return data
    raise AssertionError('unreachable')

def recover_error(path):
    if path.exists():
        archive = P / 'recovered-errors'
        archive.mkdir(exist_ok=True)
        path.replace(archive / f'{path.name}.{args.allocation_id}')
def log_needed(job):
    if job.get('conclusion') not in ['failure', 'timed_out', 'startup_failure', 'action_required']:
        return False
    log = P / 'logs' / f"{job['id']}.log"
    error = log.with_suffix('.err')
    if log.exists():
        return False
    if not error.exists():
        return True
    previous = error.read_text(errors='replace').lower()
    return 'rate limit exceeded' in previous or 'http 429' in previous or 'http 502' in previous

def get_log(job):
    if not log_needed(job):
        return
    log = P / 'logs' / f"{job['id']}.log"
    error = log.with_suffix('.err')
    try:
        data = api(f"repos/tailrocks/velnor/actions/jobs/{job['id']}/logs")
        log.write_bytes(data)
        recover_error(error)
    except ApiFailure as failure:
        error.write_text(failure.error)

def get_run(run):
    destination = P / 'jobs' / f"{run['id']}.json"
    pages = []
    try:
        for page in range(1, 1000):
            data = api(f"repos/tailrocks/velnor/actions/runs/{run['id']}/jobs?per_page=100&filter=all&page={page}")
            current = json.loads(data)
            pages.append(current)
            if len(current['jobs']) < 100:
                break
        else:
            raise ValueError('unexpected1000page job list')
        temporary = destination.with_suffix('.tmp')
        temporary.write_text(json.dumps(pages, separators=(',', ':')))
        temporary.replace(destination)
        recover_error(destination.with_suffix('.err'))
        if not args.census_only:
            for page in pages:
                for job in page['jobs']:
                    get_log(job)
    except ApiFailure as failure:
        destination.with_suffix('.err').write_text(failure.error)
    except Deferred:
        if pages and not destination.exists():
            partial = P / 'jobs-partial'
            partial.mkdir(exist_ok=True)
            (partial / destination.name).write_text(json.dumps(pages))
        raise

def guarded(task):
    if stop.is_set():
        return
    kind, value = task
    try:
        get_run(value) if kind == 'run' else get_log(value)
    except Deferred:
        pass
    except Exception as error:
        stop_with('collector-exception-review-required')
        (P / f'collector-exception-{args.allocation_id}.txt').write_text(f'{type(error).__name__}: {error}')

save_state()
runs = json.loads((P / 'runs.json').read_text())
missing_runs = sorted((r for r in runs if (r['conclusion'] != 'success' or r.get('run_attempt', 1) > 1) and not (P / 'jobs' / f"{r['id']}.json").exists()), key=lambda r: r['created_at'], reverse=True)
missing_logs = {}
for path in (P / 'jobs').glob('*.json'):
    if not path.stem.isdigit():
        continue
    for page in json.loads(path.read_text()):
        for job in page['jobs']:
            if log_needed(job):
                missing_logs[job['id']] = job
tasks = [] if args.census_only else [('log', j) for j in sorted(missing_logs.values(), key=lambda j: j.get('started_at') or '', reverse=True)]
tasks += [('run', r) for r in missing_runs]
print(json.dumps({'allocation': state, 'missing_runs': len(missing_runs), 'missing_logs': len(missing_logs)}), flush=True)
# At most one wave in flight; quota stop cannot leave an unbounded queued pool.
for index in range(0, len(tasks), args.workers):
    if stop.is_set():
        break
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as executor:
        list(executor.map(guarded, tasks[index:index + args.workers]))
if not stop.is_set():
    stop_with('complete')
print(json.dumps(state), flush=True)
