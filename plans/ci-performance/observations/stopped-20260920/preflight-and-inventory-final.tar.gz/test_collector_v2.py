import pathlib, sys, tempfile, types, unittest
from unittest.mock import patch
SOURCE = pathlib.Path('/tmp/velnor-failures/collect_remaining_v2.py').read_text().split('\nsave_state()\nruns =')[0]
class CollectorGuardTests(unittest.TestCase):
    def env(self, limit=2000):
        temporary = tempfile.TemporaryDirectory(prefix='velnor-collector-proof-')
        self.addCleanup(temporary.cleanup)
        source = SOURCE.replace("P = pathlib.Path('/tmp/velnor-failures')", f'P = pathlib.Path({temporary.name!r})')
        with patch.object(sys, 'argv', ['collector', '--max-requests', str(limit), '--allocation-id', 'local-proof']):
            namespace = {}
            exec(compile(source, 'collector-under-test', 'exec'), namespace)
        return namespace
    def response(self, status=200, remaining=4000, error='', body=b'{}'):
        return types.SimpleNamespace(returncode=0 if status==200 else 1, stdout=f'HTTP/2.0 {status}\r\nX-Ratelimit-Remaining: {remaining}\r\nX-Ratelimit-Reset: 1789927843\r\n\r\n'.encode()+body, stderr=error.encode())
    def test_hard_2000_cumulative_ceiling_despite_false_remaining(self):
        e=self.env()
        with patch('subprocess.run', return_value=self.response(remaining=5000)) as execute:
            for _ in range(2000): self.assertEqual(e['api']('fixture'), b'{}')
            with self.assertRaises(e['Deferred']): e['api']('fixture')
            self.assertEqual(execute.call_count,2000)
        self.assertEqual(e['state']['status'],'allocation-exhausted')
    def test_first_quota_403_stops_and_preserves_endpoint_headers(self):
        e=self.env()
        with patch('subprocess.run',return_value=self.response(403,0,'gh: API rate limit exceeded (HTTP 403)')) as execute:
            for _ in range(2):
                with self.assertRaises(e['Deferred']): e['api']('fixture/failed/logs')
            self.assertEqual(execute.call_count,1)
        self.assertEqual(e['state']['status'],'quota-response-stop')
        self.assertTrue((e['P']/'quota-stop-local-proof.json').exists())
    def test_real_endpoint_floor_1500_stops_followups(self):
        e=self.env()
        with patch('subprocess.run',return_value=self.response(remaining=1499)) as execute:
            self.assertEqual(e['api']('fixture'),b'{}')
            with self.assertRaises(e['Deferred']): e['api']('fixture')
            self.assertEqual(execute.call_count,1)
        self.assertEqual(e['state']['status'],'actual-response-reserve-stop')
    def test_502_retry_consumes_budget(self):
        e=self.env(limit=1)
        with patch('subprocess.run',return_value=self.response(502,4000,'gh: Bad Gateway (HTTP 502)')) as execute:
            with self.assertRaises(e['Deferred']): e['api']('fixture')
            self.assertEqual(execute.call_count,1)
        self.assertEqual(e['state']['reserved'],1)
    def test_404_not_quota_or_retry(self):
        e=self.env()
        with patch('subprocess.run',return_value=self.response(404,4000,'gh: Not Found (HTTP 404)')) as execute:
            with self.assertRaises(e['ApiFailure']): e['api']('fixture')
            self.assertEqual(execute.call_count,1)
        self.assertFalse(e['stop'].is_set())
    def test_redirect_headers_preserve_all_quota_evidence_and_body(self):
        e=self.env()
        data=b'HTTP/2.0 302\r\nX-Ratelimit-Remaining: 1555\r\n\r\nHTTP/2.0 200\r\nDate: now\r\n\r\nlog bytes\n'
        headers,body=e['split_response'](data)
        self.assertIn('X-Ratelimit-Remaining: 1555',headers)
        self.assertEqual(body,b'log bytes\n')
    def test_partial_pages_outside_canonical_jobs(self):
        e=self.env()
        (e['P']/'jobs').mkdir()
        full={'jobs':[{'id':i} for i in range(100)]}
        import json
        sequence=iter([json.dumps(full).encode(), e['Deferred']()])
        def fake_api(endpoint):
            result=next(sequence)
            if isinstance(result,Exception): raise result
            return result
        e['api']=fake_api
        with self.assertRaises(e['Deferred']): e['get_run']({'id':123})
        self.assertFalse(list((e['P']/'jobs').glob('*.json')))
        self.assertTrue((e['P']/'jobs-partial'/'123.json').exists())
if __name__=='__main__': unittest.main(verbosity=2)
