# Deliberate release snapshot refresh

Four release.yml fixture hashes change in the typed-stage migration; preview.yml, maintenance.yml and signer hashes remain unchanged. Changes are restricted to generated verification jobs plus typed recipe identity derived from their command policy.

Release unit jobs now plan explicit full selection before admission (new in legacy; provider schema retains planning and explicitly sets CI_SCOPE_OVERRIDE=full). They publish validated per-index check identities and execute one named formatting/Clippy/nextest/doctest step per typed command, each guarded by success and admitted identity. Nonsecret selection metadata moves to job env; credentials and cache flags remain check-scoped. Timing end markers use always without masking earlier failure. Implicit mise installation is prohibited at the runtime subprocess boundary.

New `release_units_expose_each_typed_rust_check_after_full_admission` tests exercise real typed Cargo commands on hosted and local release providers in both schemas. They assert planning precedes admission, forced full scope, four named checks in order, exactly one command index per step, and success/admission guards. Focused release suite before hash refresh:214 passed/4 expected hash failures,1.97s. No unrelated release fixture hashes changed. Strict/full post-refresh validation follows.

- `primitives/release.rs` / `default_rows_render_the_legacy_release_surface`: `89030c878015a5b54423837f7b6ee99f5380f7e92d50cf94d8c3ce79b0b21832`
- `primitives/release.rs` / `identity_rows_render_the_pinned_native_surface`: `97fbb174159ca4c0d446ad21361bf987a987c3b437f0176305346a27681da11c`
- `s2/primitives/release.rs` / `default_rows_render_the_legacy_release_surface`: `f2fb99d377921d6c7b173c50e857896ffb469f07f676fb407619c5aefa77f948`
- `s2/primitives/release.rs` / `identity_rows_render_the_pinned_native_surface`: `0b41fbf35de7059df9e994139b320a75d9c5b51d18f7091ce270831f79a6c136`
